from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
import base64
from io import BytesIO
import xlsxwriter


class ServicioVeterinarioReport(models.TransientModel):
    _name = 'mz.servicio.veterinario.report'
    _description = 'Reporte de Atención Veterinaria'

    date_from = fields.Date(string='Fecha Desde', required=True, default=lambda self: fields.Date.context_today(self).replace(day=1))
    date_to = fields.Date(string='Fecha Hasta', required=True, default=lambda self: fields.Date.context_today(self))
    company_id = fields.Many2one('res.company', string='Compañía', required=True, default=lambda self: self.env.company)
    report_data = fields.Html(string='Datos del Reporte', compute='_compute_report_data', sanitize=False)

    @api.depends('date_from', 'date_to')
    def _compute_report_data(self):
        for record in self:
            # Obtener consultas FINALIZADAS en el rango de fechas (para mascotas atendidas)
            domain_finalizadas = [
                ('fecha', '>=', record.date_from),
                ('fecha', '<=', record.date_to),
                ('state', '=', 'finalizado')
            ]
            
            # Obtener ASISTENCIAS en el rango de fechas (para consultas realizadas)
            domain_asistencias = [
                ('fecha', '>=', record.date_from),
                ('fecha', '<=', record.date_to),
            ]
                
            # Obtener todos los registros
            consultas_finalizadas = self.env['mz.servicio.veterinario'].search(domain_finalizadas)
            asistencias = self.env['mz.asistencia_servicio'].search(domain_asistencias)
            
            # Encontrar el módulo de tipo "Convoy"
            modulo_convoy = self.env.ref('prefectura_base.modulo_4')
            
            # Asegurarse de incluir todos los programas que son convoy
            programas_consultas = consultas_finalizadas.mapped('programa_id').filtered(lambda p: p.modulo_id.id == modulo_convoy.id)
            programas_asistencias = asistencias.mapped('programa_id').filtered(lambda p: p.modulo_id.id == modulo_convoy.id)
            programas = programas_consultas | programas_asistencias
            
            # Inicializar estructura de resultado
            result = {}
            for programa in programas:
                # Buscar el convoy relacionado con este programa
                convoy = self.env['mz.convoy'].search([('programa_id', '=', programa.id)], limit=1)
                
                # Obtener fecha_inicio_evento y tipo_zona del convoy
                fecha_convoy = convoy.fecha_inicio_evento if convoy and convoy.fecha_inicio_evento else ''
                
                # Determinar zona basado en tipo_zona
                if convoy and convoy.tipo_zona:
                    zona_valor = 'URBANA' if convoy.tipo_zona == 'urbano' else 'RURAL'
                else:
                    zona_valor = 'URBANA'  # Valor por defecto
                
                result[programa.id] = {
                    'nombre': programa.name,
                    'provincia': programa.provincia_id.name if programa.provincia_id else '',
                    'canton': programa.ciudad_id.name if programa.ciudad_id else '',
                    'parroquia': programa.parroquia_id.name if programa.parroquia_id else '',
                    'sector': programa.sector_id.name if programa.sector_id else '',
                    'fecha': fecha_convoy,  # Usar fecha_inicio_evento del convoy
                    'zona': zona_valor,     # Usar tipo_zona del convoy
                    'mascotas_atendidas': {
                        'caninos': {'macho': 0, 'hembra': 0},
                        'felinos': {'macho': 0, 'hembra': 0}
                    },
                    'consultas_realizadas': {
                        'caninos': {'macho': 0, 'hembra': 0},
                        'felinos': {'macho': 0, 'hembra': 0}
                    },
                    'beneficiarios': 0,
                    'tipo_servicio': {}  # Contador por tipo de servicio
                }
                
            
            # Sets para rastrear mascotas y beneficiarios únicos
            mascotas_unicas = set()
            beneficiarios_unicos = set()
            
            # Procesamiento para MASCOTAS ATENDIDAS (solo finalizadas)
            for servicio in consultas_finalizadas:
                programa_id = servicio.programa_id.id
                
                # Verificar que el programa sea un convoy
                programa = servicio.programa_id
                if not programa or programa.modulo_id.id != modulo_convoy.id:
                    continue
                
                # Si el programa no está en resultados, lo ignoramos
                if programa_id not in result:
                    continue
                
                # Si la fecha está vacía, usar la del primer servicio encontrado
                if not result[programa_id]['fecha']:
                    result[programa_id]['fecha'] = servicio.fecha
                
                # Determinar tipo de mascota (canino/felino)
                especie = 'caninos'  # Por defecto caninos
                perro_ref = self.env.ref('prefectura_base.item_perro')
                gato_ref = self.env.ref('prefectura_base.item_gato')
                
                if servicio.mascota_id.especie_id.id == gato_ref.id:
                    especie = 'felinos'
                
                # Determinar sexo de la mascota
                sexo = servicio.mascota_id.sexo
                
                # Incrementar contadores de mascotas atendidas (contar una vez por mascota)
                mascota_id = servicio.mascota_id.id
                mascota_key = f"{programa_id}_{mascota_id}"
                if mascota_key not in mascotas_unicas:
                    result[programa_id]['mascotas_atendidas'][especie][sexo] += 1
                    mascotas_unicas.add(mascota_key)
                
                # Incrementar contador de beneficiarios (propietarios únicos)
                
                    
                # Incrementar contador por tipo de servicio
                tipo_servicio = servicio.tipo_servicio_id.name
                if tipo_servicio not in result[programa_id]['tipo_servicio']:
                    result[programa_id]['tipo_servicio'][tipo_servicio] = 0
                result[programa_id]['tipo_servicio'][tipo_servicio] += 1
            
            # Procesamiento para CONSULTAS REALIZADAS (todas las asistencias)
            for asistencia in asistencias:
                programa_id = asistencia.programa_id.id
                
                # Verificar que el programa sea un convoy
                programa = asistencia.programa_id
                if not programa or programa.modulo_id.id != modulo_convoy.id:
                    continue
                
                # Si el programa no está en el resultado, lo ignoramos
                if programa_id not in result:
                    continue

                if asistencia.beneficiario_id:
                    beneficiario_id = asistencia.beneficiario_id.id
                    beneficiario_key = f"{programa_id}_{beneficiario_id}"
                    if beneficiario_key not in beneficiarios_unicos:
                        result[programa_id]['beneficiarios'] += 1
                        beneficiarios_unicos.add(beneficiario_key)
                
                # Determinar tipo de mascota (canino/felino) y sexo
                if asistencia.mascota_id:
                    especie = 'caninos'  # Por defecto caninos
                    perro_ref = self.env.ref('prefectura_base.item_perro')
                    gato_ref = self.env.ref('prefectura_base.item_gato')
                    
                    if asistencia.mascota_id.especie_id.id == gato_ref.id:
                        especie = 'felinos'
                    
                    sexo = asistencia.mascota_id.sexo
                    
                    # Incrementar contador de consultas realizadas (todas las asistencias)
                    result[programa_id]['consultas_realizadas'][especie][sexo] += 1
            
            # Renderizar tabla HTML
            html = """
            <div class="table-responsive" style="max-height: 500px; max-width: 100%; overflow: auto;">
                <table class="table table-bordered table-striped" style="width: 1500px; min-width: 100%;">
                    <thead class="thead-light sticky-top" style="position: sticky; top: 0; z-index: 1; background-color: white;">
                        <tr>
                            <th colspan="5"></th>
                            <th colspan="4" class="text-center" style="background-color: #FFD700;">TOTAL DE MASCOTAS ATENDIDAS</th>
                            <th colspan="4" class="text-center" style="background-color: #6B8E23;">TOTAL DE CONSULTAS REALIZADAS</th>
                            <th colspan="1"></th>
                        </tr>
                        <tr>
                            <th class="text-center" style="background-color: #f8f9fa; min-width: 100px;">FECHA</th>
                            <th class="text-center" style="background-color: #f8f9fa; min-width: 150px;">CANTÓN</th>
                            <th class="text-center" style="background-color: #f8f9fa; min-width: 150px;">LUGAR</th>
                            <th class="text-center" style="background-color: #f8f9fa; min-width: 80px;">ZONA</th>
                            <th class="text-center" style="background-color: #f8f9fa; min-width: 80px;">BENEF.</th>
                            <th colspan="2" class="text-center" style="background-color: #FFD700;">CANINOS</th>
                            <th colspan="2" class="text-center" style="background-color: #FFD700;">FELINOS</th>
                            <th colspan="2" class="text-center" style="background-color: #6B8E23;">CANINOS</th>
                            <th colspan="2" class="text-center" style="background-color: #6B8E23;">FELINOS</th>
                            <th class="text-center" style="background-color: #f8f9fa; min-width: 700px;">CONVOY</th>
                        </tr>
                        <tr>
                            <th colspan="5"></th>
                            <th class="text-center" style="background-color: #FFD700; min-width: 80px;">MACHO</th>
                            <th class="text-center" style="background-color: #FFD700; min-width: 100px;">HEMBRA</th>
                            <th class="text-center" style="background-color: #FFD700; min-width: 80px;">MACHO</th>
                            <th class="text-center" style="background-color: #FFD700; min-width: 100px;">HEMBRA</th>
                            <th class="text-center" style="background-color: #6B8E23; min-width: 80px;">MACHO</th>
                            <th class="text-center" style="background-color: #6B8E23; min-width: 100px;">HEMBRA</th>
                            <th class="text-center" style="background-color: #6B8E23; min-width: 80px;">MACHO</th>
                            <th class="text-center" style="background-color: #6B8E23; min-width: 100px;">HEMBRA</th>
                            <th colspan="2"></th>
                        </tr>
                    </thead>
                    <tbody>
            """
            
            # Agregar filas por programa
            for programa_id, data in result.items():
                # Determinar el tipo de servicio más común
                tipo_servicio_principal = max(data['tipo_servicio'].items(), key=lambda x: x[1])[0] if data['tipo_servicio'] else ''
                # raise UserError(data['canton'])
                html += f"""
                    <tr>
                        <td style="text-align: center;">{data['fecha']}</td>
                        <td style="text-align: center;">{data['canton']}</td>
                        <td style="text-align: center;">{data['parroquia']}</td>
                        <td style="text-align: center;">{data['zona']}</td>
                        <td style="text-align: center;">{data['beneficiarios']}</td>
                        <td style="text-align: center;">{data['mascotas_atendidas']['caninos']['macho']}</td>
                        <td style="text-align: center;">{data['mascotas_atendidas']['caninos']['hembra']}</td>
                        <td style="text-align: center;">{data['mascotas_atendidas']['felinos']['macho']}</td>
                        <td style="text-align: center;">{data['mascotas_atendidas']['felinos']['hembra']}</td>
                        <td style="text-align: center;">{data['consultas_realizadas']['caninos']['macho']}</td>
                        <td style="text-align: center;">{data['consultas_realizadas']['caninos']['hembra']}</td>
                        <td style="text-align: center;">{data['consultas_realizadas']['felinos']['macho']}</td>
                        <td style="text-align: center;">{data['consultas_realizadas']['felinos']['hembra']}</td>
                        <td style="text-align: center;">{data['nombre']}</td>
                    </tr>
                """
            
            # Calcular totales
            total_mascotas_caninos_macho = sum(data['mascotas_atendidas']['caninos']['macho'] for data in result.values())
            total_mascotas_caninos_hembra = sum(data['mascotas_atendidas']['caninos']['hembra'] for data in result.values())
            total_mascotas_felinos_macho = sum(data['mascotas_atendidas']['felinos']['macho'] for data in result.values())
            total_mascotas_felinos_hembra = sum(data['mascotas_atendidas']['felinos']['hembra'] for data in result.values())
            
            total_consultas_caninos_macho = sum(data['consultas_realizadas']['caninos']['macho'] for data in result.values())
            total_consultas_caninos_hembra = sum(data['consultas_realizadas']['caninos']['hembra'] for data in result.values())
            total_consultas_felinos_macho = sum(data['consultas_realizadas']['felinos']['macho'] for data in result.values())
            total_consultas_felinos_hembra = sum(data['consultas_realizadas']['felinos']['hembra'] for data in result.values())
            
            total_beneficiarios = sum(data['beneficiarios'] for data in result.values())
            
            # Agregar totales
            html += f"""
                    <tr style="background-color: #f8f9fa; font-weight: bold;">
                        <td colspan="4" style="text-align: center;">TOTALES</td>
                        <td style="text-align: center;">{total_beneficiarios}</td>
                        <td style="text-align: center;">{total_mascotas_caninos_macho}</td>
                        <td style="text-align: center;">{total_mascotas_caninos_hembra}</td>
                        <td style="text-align: center;">{total_mascotas_felinos_macho}</td>
                        <td style="text-align: center;">{total_mascotas_felinos_hembra}</td>
                        <td style="text-align: center;">{total_consultas_caninos_macho}</td>
                        <td style="text-align: center;">{total_consultas_caninos_hembra}</td>
                        <td style="text-align: center;">{total_consultas_felinos_macho}</td>
                        <td style="text-align: center;">{total_consultas_felinos_hembra}</td>
                        <td colspan="1"></td>
                    </tr>
                </tbody>
            </table>
            </div>
            """
            
            record.report_data = html

    def export_excel(self):
        """Exportar datos del reporte a Excel"""
        self.ensure_one()
        
        # Obtener consultas FINALIZADAS en el rango de fechas (para mascotas atendidas)
        domain_finalizadas = [
            ('fecha', '>=', self.date_from),
            ('fecha', '<=', self.date_to),
            ('state', '=', 'finalizado')
        ]
        
        # Obtener ASISTENCIAS en el rango de fechas (para consultas realizadas)
        domain_asistencias = [
            ('fecha', '>=', self.date_from),
            ('fecha', '<=', self.date_to),
        ]
            
        # Obtener todos los registros
        consultas_finalizadas = self.env['mz.servicio.veterinario'].search(domain_finalizadas)
        asistencias = self.env['mz.asistencia_servicio'].search(domain_asistencias)
            
        # Encontrar el módulo de tipo "Convoy"
        modulo_convoy = self.env.ref('prefectura_base.modulo_4')
            
        # Asegurarse de incluir todos los programas que son convoy
        programas_consultas = consultas_finalizadas.mapped('programa_id').filtered(lambda p: p.modulo_id.id == modulo_convoy.id)
        programas_asistencias = asistencias.mapped('programa_id').filtered(lambda p: p.modulo_id.id == modulo_convoy.id)
        programas = programas_consultas | programas_asistencias
        
        # Inicializar estructura de resultado
        result = {}
        for programa in programas:
            # Buscar el convoy relacionado con este programa
            convoy = self.env['mz.convoy'].search([('programa_id', '=', programa.id)], limit=1)
            
            # Obtener fecha_inicio y tipo_zona del convoy
            fecha_convoy = convoy.fecha_inicio_evento if convoy and convoy.fecha_inicio_evento else ''
            
            # Determinar zona basado en tipo_zona
            if convoy and convoy.tipo_zona:
                zona_valor = 'URBANA' if convoy.tipo_zona == 'urbano' else 'RURAL'
            else:
                zona_valor = 'URBANA'  # Valor por defecto
                
            result[programa.id] = {
                'nombre': programa.name,
                'provincia': programa.provincia_id.name if programa.provincia_id else '',
                'canton': programa.ciudad_id.name if programa.ciudad_id else '',
                'parroquia': programa.parroquia_id.name if programa.parroquia_id else '',
                'sector': programa.sector_id.name if programa.sector_id else '',
                'fecha': fecha_convoy,  # Usar fecha_inicio del convoy
                'zona': zona_valor,     # Usar tipo_zona del convoy
                'mascotas_atendidas': {
                    'caninos': {'macho': 0, 'hembra': 0},
                    'felinos': {'macho': 0, 'hembra': 0}
                },
                'consultas_realizadas': {
                    'caninos': {'macho': 0, 'hembra': 0},
                    'felinos': {'macho': 0, 'hembra': 0}
                },
                'beneficiarios': 0,
                'tipo_servicio': {}  # Contador por tipo de servicio
            }
        
        # Sets para rastrear mascotas y beneficiarios únicos
        mascotas_unicas = set()
        beneficiarios_unicos = set()
        
        # Procesamiento para MASCOTAS ATENDIDAS (solo finalizadas)
        for servicio in consultas_finalizadas:
            programa_id = servicio.programa_id.id
            
            # Verificar que el programa sea un convoy
            programa = servicio.programa_id
            if not programa or programa.modulo_id.id != modulo_convoy.id:
                continue
            
            # Si el programa no está en resultados, lo ignoramos
            if programa_id not in result:
                continue
            
            # Si la fecha está vacía, usar la del primer servicio encontrado
            if not result[programa_id]['fecha']:
                result[programa_id]['fecha'] = servicio.fecha
            
            # Determinar tipo de mascota (canino/felino)
            especie = 'caninos'  # Por defecto caninos
            perro_ref = self.env.ref('prefectura_base.item_perro')
            gato_ref = self.env.ref('prefectura_base.item_gato')
            
            if servicio.mascota_id.especie_id.id == gato_ref.id:
                especie = 'felinos'
            
            # Determinar sexo de la mascota
            sexo = servicio.mascota_id.sexo
            
            # Incrementar contadores de mascotas atendidas (contar una vez por mascota)
            mascota_id = servicio.mascota_id.id
            mascota_key = f"{programa_id}_{mascota_id}"
            if mascota_key not in mascotas_unicas:
                result[programa_id]['mascotas_atendidas'][especie][sexo] += 1
                mascotas_unicas.add(mascota_key)
                
            # Incrementar contador por tipo de servicio
            tipo_servicio = servicio.tipo_servicio_id.name
            if tipo_servicio not in result[programa_id]['tipo_servicio']:
                result[programa_id]['tipo_servicio'][tipo_servicio] = 0
            result[programa_id]['tipo_servicio'][tipo_servicio] += 1
        
        # Procesamiento para CONSULTAS REALIZADAS (todas las asistencias)
        for asistencia in asistencias:
            programa_id = asistencia.programa_id.id
            
            # Verificar que el programa sea un convoy
            programa = asistencia.programa_id
            if not programa or programa.modulo_id.id != modulo_convoy.id:
                continue
            
            # Si el programa no está en el resultado, lo ignoramos
            if programa_id not in result:
                continue
                
            # Contar beneficiarios únicos de las asistencias
            if asistencia.beneficiario_id:
                beneficiario_id = asistencia.beneficiario_id.id
                beneficiario_key = f"{programa_id}_{beneficiario_id}"
                if beneficiario_key not in beneficiarios_unicos:
                    result[programa_id]['beneficiarios'] += 1
                    beneficiarios_unicos.add(beneficiario_key)
            
            # Determinar tipo de mascota (canino/felino) y sexo
            if asistencia.mascota_id:
                especie = 'caninos'  # Por defecto caninos
                perro_ref = self.env.ref('prefectura_base.item_perro')
                gato_ref = self.env.ref('prefectura_base.item_gato')
                
                if asistencia.mascota_id.especie_id.id == gato_ref.id:
                    especie = 'felinos'
                
                sexo = asistencia.mascota_id.sexo
                
                # Incrementar contador de consultas realizadas (todas las asistencias)
                result[programa_id]['consultas_realizadas'][especie][sexo] += 1
        
        # Crear archivo Excel
        output = BytesIO()
        workbook = xlsxwriter.Workbook(output)
        worksheet = workbook.add_worksheet('Reporte Atención Veterinaria')
        
        # Estilos
        title_format = workbook.add_format({
            'bold': True, 
            'font_size': 14, 
            'align': 'center', 
            'valign': 'vcenter'
        })
        header_format = workbook.add_format({
            'bold': True, 
            'bg_color': '#DDDDDD', 
            'align': 'center', 
            'border': 1
        })
        mascotas_header_format = workbook.add_format({
            'bold': True, 
            'bg_color': '#FFD700', 
            'align': 'center', 
            'border': 1
        })
        consultas_header_format = workbook.add_format({
            'bold': True, 
            'bg_color': '#6B8E23', 
            'align': 'center', 
            'border': 1,
            'color': 'white'  # Texto en blanco para mejor contraste
        })
        cell_format = workbook.add_format({
            'align': 'center', 
            'border': 1
        })
        total_format = workbook.add_format({
            'bold': True, 
            'align': 'center', 
            'border': 1,
            'bg_color': '#F0F0F0'
        })
        # Formato especial para la celda de tipo atención que permite ajuste de texto
        wrap_format = workbook.add_format({
            'align': 'center',
            'valign': 'vcenter',
            'border': 1,
            'text_wrap': True  # Esto permite que el texto se ajuste dentro de la celda
        })
        
        # Título
        worksheet.merge_range('A1:N1', 'Reporte de Atención Veterinaria', title_format)
        worksheet.write('A2', f'Desde: {self.date_from.strftime("%d/%m/%Y")}', workbook.add_format({'bold': True}))
        worksheet.write('C2', f'Hasta: {self.date_to.strftime("%d/%m/%Y")}', workbook.add_format({'bold': True}))
        
        # Encabezados
        # Primera fila de encabezados
        worksheet.merge_range('A4:E4', '', header_format)
        worksheet.merge_range('F4:I4', 'TOTAL DE MASCOTAS ATENDIDAS', mascotas_header_format)
        worksheet.merge_range('J4:M4', 'TOTAL DE CONSULTAS REALIZADAS', consultas_header_format)
        
        # Centrar TIPO ATENCIÓN sobre la columna completa
        worksheet.merge_range('N4:N5', 'CONVOY', header_format)
        
        # Segunda fila de encabezados
        worksheet.write('A5', 'FECHA', header_format)
        worksheet.write('B5', 'CANTÓN', header_format)
        worksheet.write('C5', 'LUGAR', header_format)
        worksheet.write('D5', 'ZONA', header_format)
        worksheet.write('E5', 'BENEF.', header_format)
        
        worksheet.merge_range('F5:G5', 'CANINOS', mascotas_header_format)
        worksheet.merge_range('H5:I5', 'FELINOS', mascotas_header_format)
        worksheet.merge_range('J5:K5', 'CANINOS', consultas_header_format)
        worksheet.merge_range('L5:M5', 'FELINOS', consultas_header_format)
        
        # Tercera fila de encabezados
        worksheet.write('F6', 'MACHO', mascotas_header_format)
        worksheet.write('G6', 'HEMBRA', mascotas_header_format)
        worksheet.write('H6', 'MACHO', mascotas_header_format)
        worksheet.write('I6', 'HEMBRA', mascotas_header_format)
        worksheet.write('J6', 'MACHO', consultas_header_format)
        worksheet.write('K6', 'HEMBRA', consultas_header_format)
        worksheet.write('L6', 'MACHO', consultas_header_format)
        worksheet.write('M6', 'HEMBRA', consultas_header_format)
        
        # Establecer anchos de columna
        worksheet.set_column('A:A', 12)  # Fecha
        worksheet.set_column('B:C', 15)  # Cantón, Lugar
        worksheet.set_column('D:D', 12)  # Zona
        worksheet.set_column('E:E', 12)  # Beneficiarios
        worksheet.set_column('F:M', 10)  # Datos numéricos
        worksheet.set_column('N:N', 45)  # Tipo atención
        
        # Datos
        row = 6
        for programa_id, data in result.items():
            row += 1
            
            # Determinar el tipo de servicio más común
            tipo_servicio_principal = max(data['tipo_servicio'].items(), key=lambda x: x[1])[0] if data['tipo_servicio'] else ''
            
            worksheet.write(row, 0, data['fecha'].strftime('%d/%m/%Y') if data['fecha'] else '', cell_format)
            worksheet.write(row, 1, data['canton'], cell_format)
            worksheet.write(row, 2, data['parroquia'], cell_format)
            worksheet.write(row, 3, data['zona'], cell_format)
            worksheet.write(row, 4, data['beneficiarios'], cell_format)
            
            worksheet.write(row, 5, data['mascotas_atendidas']['caninos']['macho'], cell_format)
            worksheet.write(row, 6, data['mascotas_atendidas']['caninos']['hembra'], cell_format)
            worksheet.write(row, 7, data['mascotas_atendidas']['felinos']['macho'], cell_format)
            worksheet.write(row, 8, data['mascotas_atendidas']['felinos']['hembra'], cell_format)
            
            worksheet.write(row, 9, data['consultas_realizadas']['caninos']['macho'], cell_format)
            worksheet.write(row, 10, data['consultas_realizadas']['caninos']['hembra'], cell_format)
            worksheet.write(row, 11, data['consultas_realizadas']['felinos']['macho'], cell_format)
            worksheet.write(row, 12, data['consultas_realizadas']['felinos']['hembra'], cell_format)
            
            worksheet.write(row, 13, data['nombre'], wrap_format)
        
        # Calcular totales
        total_mascotas_caninos_macho = sum(data['mascotas_atendidas']['caninos']['macho'] for data in result.values())
        total_mascotas_caninos_hembra = sum(data['mascotas_atendidas']['caninos']['hembra'] for data in result.values())
        total_mascotas_felinos_macho = sum(data['mascotas_atendidas']['felinos']['macho'] for data in result.values())
        total_mascotas_felinos_hembra = sum(data['mascotas_atendidas']['felinos']['hembra'] for data in result.values())
        
        total_consultas_caninos_macho = sum(data['consultas_realizadas']['caninos']['macho'] for data in result.values())
        total_consultas_caninos_hembra = sum(data['consultas_realizadas']['caninos']['hembra'] for data in result.values())
        total_consultas_felinos_macho = sum(data['consultas_realizadas']['felinos']['macho'] for data in result.values())
        total_consultas_felinos_hembra = sum(data['consultas_realizadas']['felinos']['hembra'] for data in result.values())
        
        total_beneficiarios = sum(data['beneficiarios'] for data in result.values())
        
        # Agregar fila de totales
        row += 1
        worksheet.merge_range(row, 0, row, 3, 'TOTALES', total_format)
        worksheet.write(row, 4, total_beneficiarios, total_format)
        worksheet.write(row, 5, total_mascotas_caninos_macho, total_format)
        worksheet.write(row, 6, total_mascotas_caninos_hembra, total_format)
        worksheet.write(row, 7, total_mascotas_felinos_macho, total_format)
        worksheet.write(row, 8, total_mascotas_felinos_hembra, total_format)
        worksheet.write(row, 9, total_consultas_caninos_macho, total_format)
        worksheet.write(row, 10, total_consultas_caninos_hembra, total_format)
        worksheet.write(row, 11, total_consultas_felinos_macho, total_format)
        worksheet.write(row, 12, total_consultas_felinos_hembra, total_format)
        
        workbook.close()
        
        # Crear el adjunto
        filename = f"Reporte_Atencion_Veterinaria_{self.date_from.strftime('%Y%m%d')}_{self.date_to.strftime('%Y%m%d')}.xlsx"
        excel_data = base64.b64encode(output.getvalue())
        
        attachment = self.env['ir.attachment'].create({
            'name': filename,
            'datas': excel_data,
            'type': 'binary',
            'res_model': self._name,
            'res_id': self.id,
        })
        
        # Devolver la acción para descargar el archivo
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'self',
        }
   
class ServicioVeterinarioReportWizard(models.TransientModel):
    _name = 'mz.servicio.veterinario.report.wizard'
    _description = 'Asistente de Reporte de Atención Veterinaria'

    date_from = fields.Date(string='Fecha Desde', required=True, default=lambda self: fields.Date.context_today(self).replace(day=1))
    date_to = fields.Date(string='Fecha Hasta', required=True, default=lambda self: fields.Date.context_today(self))
    
    def action_generate_report(self):
        self.ensure_one()
        
        report = self.env['mz.servicio.veterinario.report'].create({
            'date_from': self.date_from,
            'date_to': self.date_to,
        })
        
        return {
            'name': _('Reporte de Atención Veterinaria'),
            'type': 'ir.actions.act_window',
            'res_model': 'mz.servicio.veterinario.report',
            'view_mode': 'form',
            'res_id': report.id,
            'target': 'new',
        }