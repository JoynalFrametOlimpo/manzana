from odoo import models, fields,api

class MZConvoySuspender(models.TransientModel):
    _name = 'mz.suspender_convoy'
    _description = 'Control de Asistencia Wizard'


    observacion = fields.Text(string='Observación', required=True)
    documento_suspencion = fields.Binary(string="Documento Suspención", attachment=True)
    documento_suspencion_name = fields.Char(string="Nombre Documento Suspención", tracking=True)

    def action_suspender(self):
        active_id = self._context.get('active_id') 
        convoy = self.env['mz.convoy']
        if active_id:
            convoy = convoy.browse(self._context.get('active_id'))
            convoy.write({  'observacion': self.observacion,
                            'documento_suspencion': self.documento_suspencion,   
                            'documento_suspencion_name': self.documento_suspencion_name,    
                                })
            convoy.action_suspender()
        # Lógica personalizada para manejar la confirmación
        return {'type': 'ir.actions.act_window_close'}

