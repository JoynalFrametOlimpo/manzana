from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
from datetime import date
from odoo.addons.manzana_de_cuidados import utils
from odoo.exceptions import UserError,ValidationError
import logging
_logger = logging.getLogger(__name__)

class ConvoyBeneficiarioWizardDependiente(models.TransientModel):
    _name = 'mz_convoy.dependiente_wizard'
    _description = 'Dependiente en Wizard de Beneficiario'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'dinardap.mixin']

    # Relación con el wizard principal
    wizard_id = fields.Many2one('mz_convoy.beneficiario_wizard', string='Wizard')
    programa_id = fields.Many2one('pf.programas', string="Programas", related='wizard_id.programa_id', readonly=True, store=True)
    beneficiario_id = fields.Many2one('mz.beneficiario', string='Beneficiario')
    
    dependiente_id = fields.Many2one('mz.dependiente', string='Dependiente')
    dependiente_busqueda_domain = fields.Char( compute="_compute_dependiente_busqueda_domain", readonly=True, store=False)
    dependiente_busqueda_id = fields.Many2one('mz.dependiente', string='Buscar Dependiente',
        domain="[('beneficiario_id', '=', beneficiario_id)]")
    is_new_dependiente = fields.Boolean('Es nuevo dependiente', default=True)

    # Campos básicos del dependiente
    name = fields.Char(string='Nombre Completo', compute='_compute_name', store=True)
    tipo_dependiente = fields.Many2one('pf.items', string="Tipo de Dependiente", required=True,
        domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.tipo_dependiente').id)])
    primer_apellido = fields.Char(string='Primer Apellido', required=True)
    segundo_apellido = fields.Char(string='Segundo Apellido')
    primer_nombre = fields.Char(string='Primer Nombre', required=True)
    segundo_nombre = fields.Char(string='Segundo Nombre')
    fecha_nacimiento = fields.Date(string='Fecha de Nacimiento')
    tipo_documento = fields.Selection([
        ('dni', 'Cédula'), 
        ('pasaporte', 'Pasaporte'), 
        ('carnet_extranjeria', 'Carnet de Extranjería')
    ], string='Tipo de Documento', required=True)
    numero_documento = fields.Char(string='Número de Documento', required=True)
    edad = fields.Char(string="Edad", compute="_compute_edad", store=True)
    servicio_ids = fields.Many2many('mz.asignacion.servicio', 'mz_convoy_dependiente_servicio_rel', 'dependiente_wizard_id', 'servicio_id', 
                                   string='Servicios a Recibir', domain="[('programa_id', '=', programa_id),('servicio_id.tipo_servicio', '!=', 'mascota')]")
    
    dinardap_estado = fields.Selection([
    ('local', 'Local'),
    ('no_consultado', 'No Consultado'),
    ('consultando', 'Consultando...'),
    ('consultado', 'Consultado'),
    ('no_encontrado', 'No Encontrado'),
    ('error', 'Error'),
    ('no_aplica', 'No Aplica'),
    ('local', 'Datos Locales')
    ], string='Estado DINARDAP', default='no_consultado', readonly=True)

    dinardap_mensaje = fields.Text(string='Mensaje DINARDAP', readonly=True)
    dinardap_consultado = fields.Boolean(string='Ya Consultado', default=False)
    dinardap_ultimo_documento_consultado = fields.Char(string='Último Documento Consultado')

    @api.onchange('tipo_documento', 'numero_documento')
    def _onchange_documento_dependiente(self):
        """OnChange para dependientes: Solo DINARDAP si es nuevo dependiente"""
        
        # =============== VERIFICACIÓN CRÍTICA AL INICIO ===============
        # Si dependiente_busqueda_id tiene valor, significa que seleccionó uno existente
        # En ese caso NO hacer NADA - el onchange de búsqueda ya manejó todo
        if self.dependiente_busqueda_id:
            # Asegurar que mantenga el estado local
            if self.dinardap_estado != 'local':
                self.dinardap_estado = 'local'
                self.dinardap_mensaje = 'Dependiente cargado desde selección existente'
            return
        
        # =============== SOLO PROCEDER SI ES DEPENDIENTE NUEVO ===============
        
        # Reset del estado DINARDAP al cambiar cualquier campo
        self.dinardap_estado = 'no_consultado'
        self.dinardap_mensaje = False
        
        # =============== LIMPIAR CAMPOS CUANDO CAMBIA EL DOCUMENTO ===============
        # Si hay cambio en tipo o número de documento, limpiar campos de datos personales
        self._limpiar_campos_datos_personales()
        
        # Limpiar el número de documento si existe
        if self.numero_documento:
            self.numero_documento = str(self.numero_documento).strip()
        
        # Si no hay número de documento, mantener campos limpios y salir
        if not self.numero_documento:
            return
        
        # Si no hay tipo de documento seleccionado, mantener campos limpios y salir
        if not self.tipo_documento:
            return
        
        # =============== ES UN DEPENDIENTE NUEVO - VALIDAR Y CONSULTAR ===============
        
        # Solo validar y consultar DINARDAP si es un dependiente nuevo
        resultado_validacion = self._validar_documento_dependiente()
        if resultado_validacion:  # Si hay error en validación
            return resultado_validacion
        
        # Si es cédula, consultar DINARDAP
        if self.tipo_documento == 'dni':
            return self._consultar_dinardap_automatico()
        else:
            # Para otros tipos de documento, marcar como no aplica
            self.dinardap_estado = 'no_aplica'
            self.dinardap_mensaje = f'DINARDAP no aplica para {self.tipo_documento}'
    
    def _validar_documento_dependiente(self):
        """Validaciones específicas por tipo de documento para dependientes"""
        
        if self.tipo_documento == 'dni':
            # Validar longitud de cédula
            if len(self.numero_documento) != 10:
                self.dinardap_estado = 'error'
                self.dinardap_mensaje = f'Cédula debe tener 10 dígitos (actual: {len(self.numero_documento)})'
                return {'warning': {
                    'title': _('❌ Cédula Incompleta'),
                    'message': _('La cédula debe tener exactamente 10 dígitos.\n\nDigitado: %s dígitos') % len(self.numero_documento)
                }}
            
            # Validar que sean solo números
            if not self.numero_documento.isdigit():
                self.dinardap_estado = 'error'
                self.dinardap_mensaje = 'Cédula debe contener solo números'
                return {'warning': {
                    'title': _('❌ Formato Inválido'),
                    'message': _('La cédula solo debe contener números.\n\nCaracteres inválidos detectados.')
                }}
            
            # Validar usando algoritmo ecuatoriano
            if not utils.validar_cedula(self.numero_documento):
                self.numero_documento = False
                self.dinardap_estado = 'error'
                self.dinardap_mensaje = 'Cédula inválida según algoritmo ecuatoriano'
                return {'warning': {
                    'title': _('❌ Cédula Inválida'),
                    'message': _('El número de cédula ingresado no es válido según el algoritmo de verificación ecuatoriano.\n\nPor favor verifique los dígitos.')
                }}
        
        elif self.tipo_documento == 'pasaporte':
            if len(self.numero_documento) < 6 or len(self.numero_documento) > 15:
                return {'warning': {
                    'title': _('❌ Pasaporte Inválido'),
                    'message': _('El número de pasaporte debe tener entre 6 y 15 caracteres.')
                }}
        
        elif self.tipo_documento == 'carnet_extranjeria':
            if len(self.numero_documento) < 6 or len(self.numero_documento) > 20:
                return {'warning': {
                    'title': _('❌ Carnet Inválido'),
                    'message': _('El número de carnet debe tener entre 6 y 20 caracteres.')
                }}
        
        return None  # Sin errores

    def _limpiar_campos_datos_personales(self):
        """Limpiar solo los campos de datos personales cuando cambia el documento"""
        # NO limpiar si hay un dependiente seleccionado
        if self.dependiente_busqueda_id:
            return
            
        self.update({
            'primer_apellido': False,
            'segundo_apellido': False,
            'primer_nombre': False,
            'segundo_nombre': False,
            'fecha_nacimiento': False,
            # NO limpiar tipo_dependiente ni servicios ya que son configuración del usuario
        })
        
        # También limpiar la referencia al dependiente existente
        self.dependiente_id = False
        self.is_new_dependiente = True
   
    def _get_dinardap_field_mapping(self):
        """Mapeo específico de campos DINARDAP para dependientes"""
        return {
            'primer_nombre': 'primer_nombre',
            'segundo_nombre': 'segundo_nombre',
            'apellido_paterno': 'primer_apellido',      # 🔄 Mapeo diferente
            'apellido_materno': 'segundo_apellido',     # 🔄 Mapeo diferente
            'numero_documento': 'numero_documento',
            'fecha_nacimiento': 'fecha_nacimiento',
            # Campos que no se usan en dependientes
            'direccion': None,                          # ❌ No aplica
            'provincia_nombre': None,                   # ❌ No aplica
            'ciudad_nombre': None,                      # ❌ No aplica
        }

    def _aplicar_datos_dinardap(self, datos):
        """Aplicar datos de DINARDAP específicamente para dependientes"""
        mapeo = self._get_dinardap_field_mapping()
        
        # Aplicar solo los campos relevantes para dependientes
        valores_actualizar = {}
        
        for campo_dinardap, campo_local in mapeo.items():
            if campo_local and campo_dinardap in datos and datos[campo_dinardap]:
                valores_actualizar[campo_local] = datos[campo_dinardap]
        
        # Aplicar los valores
        if valores_actualizar:
            self.update(valores_actualizar)
        
        # Actualizar estado DINARDAP
        self.dinardap_estado = 'consultado'
        self.dinardap_consultado = True
        self.dinardap_mensaje = f'Datos cargados desde DINARDAP: {", ".join(valores_actualizar.keys())}'
        
        # Asegurar que tipo_documento sea cédula si vino de DINARDAP
        if not self.tipo_documento and self.numero_documento:
            self.tipo_documento = 'dni'

    def _get_dinardap_service(self):
        """Obtener el servicio DINARDAP"""
        return self.env['dinardap.service']

    def _consultar_dinardap_automatico(self):
        """Método separado para la consulta automática DINARDAP en dependientes"""
        
        # Solo consultar si no se ha consultado antes para esta cédula
        numero_limpio = str(self.numero_documento).strip()
        
        # Verificar si ya se consultó este documento
        if (self.dinardap_consultado and 
            self.dinardap_ultimo_documento_consultado == numero_limpio):
            # Ya se consultó este documento, no hacer nada
            return
        
        try:
            dinardap_service = self._get_dinardap_service()
            
            # Verificar si el servicio está habilitado
            if not dinardap_service._is_service_enabled():
                self.dinardap_estado = 'no_aplica'
                self.dinardap_mensaje = 'Servicio DINARDAP deshabilitado'
                return {
                    'warning': {
                        'title': _('ℹ️ Servicio No Disponible'),
                        'message': _('El servicio DINARDAP está deshabilitado.\n\nLos datos deben ingresarse manualmente.')
                    }
                }
            
            # Intentar consulta
            datos = dinardap_service.consultar_ciudadano(numero_limpio)
            
            if datos:
                self._aplicar_datos_dinardap(datos)
                # Guardar referencia para evitar consultas duplicadas
                self.dinardap_ultimo_documento_consultado = numero_limpio                
            
                return {
                    'warning': {
                        'title': _('✅ Dependiente Encontrado'),
                        'message': _('Se han cargado los datos del dependiente desde DINARDAP.\nDatos cargados automáticamente.')
                    }
                }
            else:
                self.dinardap_estado = 'no_encontrado'
                self.dinardap_mensaje = f'No se encontraron datos para cédula {numero_limpio}'
                self.dinardap_ultimo_documento_consultado = numero_limpio
                return {
                    'warning': {
                        'title': _('❌ Sin Resultados en DINARDAP'),
                        'message': _('No se encontraron datos para la cédula: %s\n\n• Verifique que la cédula sea correcta\n• La persona debe estar registrada en el sistema\n• Complete los datos manualmente') % numero_limpio
                    }
                }
                
        except ValidationError as e:
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error de validación: {str(e)}'
            return {
                'warning': {
                    'title': _('⚠️ Error de Validación'),
                    'message': str(e)
                }
            }
            
        except UserError as e:
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error de servicio: {str(e)}'
            return {
                'warning': {
                    'title': _('⚠️ Error de Servicio DINARDAP'),
                    'message': _('No se pudo consultar DINARDAP: %s\n\nPor favor complete los datos manualmente.') % str(e)[:100]
                }
            }
            
        except Exception as e:
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error inesperado: {str(e)[:100]}'
            _logger.warning(f"Error inesperado en consulta automática DINARDAP dependiente: {str(e)}")
            return {
                'warning': {
                    'title': _('⚠️ Error de Conexión'),
                    'message': _('No se pudo conectar con DINARDAP:\n\n%s\n\nPor favor complete los datos manualmente.') % str(e)[:100]
                }
            }
    

    @api.depends('wizard_id.dependientes_ids', 'beneficiario_id')
    def _compute_dependiente_busqueda_domain(self):
        for record in self:
            # Buscar todos los dependientes del beneficiario
            if record.beneficiario_id:
                # Obtener los IDs de dependientes ya agregados al wiza
                dependientes_wizard = record.wizard_id.dependientes_ids.mapped('dependiente_id').ids
                
                if dependientes_wizard:
                    # Si hay dependientes en el wizard, mostrar solo los que no están agregados
                    record.dependiente_busqueda_domain = f"[('beneficiario_id', '=', {record.beneficiario_id.id}), ('id', 'not in', {dependientes_wizard})]"
                else:
                    # Si no hay dependientes en el wizard, mostrar todos los del beneficiario
                    record.dependiente_busqueda_domain = f"[('beneficiario_id', '=', {record.beneficiario_id.id})]"
            else:
                record.dependiente_busqueda_domain = "[('id', 'in', [])]"

    @api.depends('fecha_nacimiento')
    def _compute_edad(self):
        for record in self:
            if record.fecha_nacimiento:
                hoy = date.today()
                diferencia = relativedelta(hoy, record.fecha_nacimiento)
                record.edad = f"{diferencia.years} años, {diferencia.months} meses, {diferencia.days} días"
            else:
                record.edad = "Sin fecha de nacimiento"

    @api.depends('primer_apellido', 'segundo_apellido', 'primer_nombre', 'segundo_nombre')
    def _compute_name(self):
        for record in self:
            parts = []
            if record.primer_apellido:
                parts.append(record.primer_apellido)
            if record.segundo_apellido:
                parts.append(record.segundo_apellido)
            if record.primer_nombre:
                parts.append(record.primer_nombre)
            if record.segundo_nombre:
                parts.append(record.segundo_nombre)
            record.name = ' '.join(parts)

    @api.onchange('dependiente_busqueda_id')
    def _onchange_dependiente_busqueda(self):
        """Cambio en búsqueda de dependiente existente - PRIORIDAD MÁXIMA"""
        if self.dependiente_busqueda_id:
            self.is_new_dependiente = False
            # Marcar como local ANTES de cargar para evitar interferencias
            self.dinardap_estado = 'local'
            self.dinardap_mensaje = 'Dependiente cargado desde selección existente'
            self._cargar_dependiente(self.dependiente_busqueda_id)
        else:
            self.is_new_dependiente = True
            # Limpiar estado DINARDAP cuando se deselecciona
            self.dinardap_estado = 'no_consultado'
            self.dinardap_mensaje = False
            self._limpiar_campos()

    def _limpiar_campos(self):
        """Limpia todos los campos del dependiente"""
        self.update({
            'dependiente_id': False,
            'tipo_dependiente': False,
            'primer_apellido': False,
            'segundo_apellido': False,
            'primer_nombre': False,
            'segundo_nombre': False,
            'fecha_nacimiento': False,
            'tipo_documento': False,
            'numero_documento': False,
            'servicio_ids': [(5, 0, 0)]  # Limpia los servicios seleccionados
        })

    def _cargar_dependiente(self, dependiente):
        """Carga los datos del dependiente encontrado"""
        self.update({
            'dependiente_id': dependiente.id,
            'tipo_dependiente': dependiente.tipo_dependiente.id,
            'primer_apellido': dependiente.primer_apellido,
            'segundo_apellido': dependiente.segundo_apellido,
            'primer_nombre': dependiente.primer_nombre,
            'segundo_nombre': dependiente.segundo_nombre,
            'fecha_nacimiento': dependiente.fecha_nacimiento,
            'tipo_documento': dependiente.tipo_documento,
            'numero_documento': dependiente.numero_documento,
            'servicio_ids': [(5, 0, 0)]  # Limpia los servicios al cargar nuevo dependiente
        })

    def _prepare_dependiente_values(self):
        """Prepara los valores para crear/actualizar el dependiente"""
        return {
            'tipo_dependiente': self.tipo_dependiente.id,
            'primer_apellido': self.primer_apellido,
            'segundo_apellido': self.segundo_apellido,
            'primer_nombre': self.primer_nombre,
            'segundo_nombre': self.segundo_nombre,
            'fecha_nacimiento': self.fecha_nacimiento,
            'tipo_documento': self.tipo_documento,
            'numero_documento': self.numero_documento,
            'beneficiario_id': self.wizard_id.beneficiario_id.id,
        }