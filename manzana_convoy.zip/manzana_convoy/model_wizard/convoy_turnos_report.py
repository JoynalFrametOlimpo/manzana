from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
import base64
from io import BytesIO
import xlsxwriter


class ConvoyTurnosReport(models.TransientModel):
    _name = 'mz.convoy.turnos.report'
    _description = 'Reporte de Turnos de Convoy'
    # Removimos la herencia de report.report_xlsx.abstract

    date_from = fields.Date(string='Fecha Inicio', required=True, default=lambda self: fields.Date.context_today(self).replace(day=1))
    convoy_id = fields.Many2one('mz.convoy', string='Convoy', required=False)
    company_id = fields.Many2one('res.company', string='Compañía', required=True, default=lambda self: self.env.company)
    report_data = fields.Html(string='Datos del Reporte', compute='_compute_report_data', sanitize=False)

    @api.depends('date_from', 'convoy_id')
    def _compute_report_data(self):
        for record in self:
            # Obtener datos de servicios
            domain = []   
            if record.convoy_id:                
                domain= [('fecha_solicitud', '=', record.date_from),('convoy_id', '=', record.convoy_id.id)]
                
            # Obtener todos los registros de agendar_servicio en el rango de fechas
            turnos = self.env['mz.agendar_servicio'].search(domain)
            
            # Obtener servicios para agrupar
            servicios = turnos.mapped('servicio_base_id')
            # raise UserError(turnos)
            
            # Inicializar estructura de resultado
            result = {}
            for servicio in servicios:
                result[servicio.id] = {
                    'nombre': servicio.name,
                    'asignados': {
                        'beneficiarios': 0,
                        'dependientes': 0,
                        'mascotas': 0,
                    },
                    'ejecutados': {
                        'beneficiarios': 0,
                        'dependientes': 0,
                        'mascotas': 0,
                    }
                }
            
            # Contar turnos por tipo de servicio
            for turno in turnos:
                servicio_id = turno.servicio_base_id.id
                
                # Omitir si no se encuentra el servicio
                if servicio_id not in result:
                    continue
                
                # Determinar si es beneficiario, dependiente o mascota
                categoria = None
                if turno.mascota_id:
                    categoria = 'mascotas'
                elif turno.tipo_beneficiario == 'dependiente' and turno.dependiente_id:
                    categoria = 'dependientes'
                else:
                    categoria = 'beneficiarios'
                
                # Agregar a conteos asignados
                result[servicio_id]['asignados'][categoria] += 1
                
                # Agregar a conteos ejecutados si el turno fue atendido
                if turno.state == 'atendido':
                    result[servicio_id]['ejecutados'][categoria] += 1
            
            # Calcular totales
            total_asignados = {
                'beneficiarios': sum(item['asignados']['beneficiarios'] for item in result.values()),
                'dependientes': sum(item['asignados']['dependientes'] for item in result.values()),
                'mascotas': sum(item['asignados']['mascotas'] for item in result.values()),
            }
            
            total_ejecutados = {
                'beneficiarios': sum(item['ejecutados']['beneficiarios'] for item in result.values()),
                'dependientes': sum(item['ejecutados']['dependientes'] for item in result.values()),
                'mascotas': sum(item['ejecutados']['mascotas'] for item in result.values()),
            }
            
            # Renderizar tabla HTML
            html = """
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th rowspan="2">Servicio</th>
                            <th colspan="3" class="text-center" style="background-color: #FFD700;">Turnos Asignados</th>
                            <th colspan="3" class="text-center" style="background-color: #6B8E23;">Turnos Ejecutados</th>
                        </tr>
                        <tr>
                            <th style="background-color: #FFD700;">Beneficiarios</th>
                            <th style="background-color: #FFD700;">Dependientes</th>
                            <th style="background-color: #FFD700;">Mascotas</th>
                            <th style="background-color: #6B8E23;">Beneficiarios</th>
                            <th style="background-color: #6B8E23;">Dependientes</th>
                            <th style="background-color: #6B8E23;">Mascotas</th>
                        </tr>
                    </thead>
                    <tbody>
            """
            
            # Agregar datos de servicios
            for servicio_id, data in result.items():
                html += f"""
                    <tr>
                        <td>{data['nombre']}</td>
                        <td style="text-align: center;">{data['asignados']['beneficiarios']}</td>
                        <td style="text-align: center;">{data['asignados']['dependientes']}</td>
                        <td style="text-align: center;">{data['asignados']['mascotas']}</td>
                        <td style="text-align: center;">{data['ejecutados']['beneficiarios']}</td>
                        <td style="text-align: center;">{data['ejecutados']['dependientes']}</td>
                        <td style="text-align: center;">{data['ejecutados']['mascotas']}</td>
                    </tr>
                """
            
            # Agregar subtotales
            html += f"""
                    <tr style="background-color: #FFD700;">
                        <td>Subtotal turnos</td>
                        <td style="text-align: center;"><strong>{total_asignados['beneficiarios']}</strong></td>
                        <td style="text-align: center;"><strong>{total_asignados['dependientes']}</strong></td>
                        <td style="text-align: center;"><strong>{total_asignados['mascotas']}</strong></td>
                        <td style="text-align: center; background-color: #6B8E23;"><strong>{total_ejecutados['beneficiarios']}</strong></td>
                        <td style="text-align: center; background-color: #6B8E23;"><strong>{total_ejecutados['dependientes']}</strong></td>
                        <td style="text-align: center; background-color: #6B8E23;"><strong>{total_ejecutados['mascotas']}</strong></td>
                    </tr>
                    <tr>
                        <td>Total Turnos</td>
                        <td colspan="3" style="text-align: center;"><strong>{total_asignados['beneficiarios'] + total_asignados['dependientes'] + total_asignados['mascotas']}</strong></td>
                        <td colspan="3" style="text-align: center;"><strong>{total_ejecutados['beneficiarios'] + total_ejecutados['dependientes'] + total_ejecutados['mascotas']}</strong></td>
                    </tr>
                </tbody>
            </table>
            </div>
            """
            
            record.report_data = html

    def print_report(self):
        """Imprimir reporte PDF"""
        self.ensure_one()
        return self.env.ref('manzana_convoy.action_report_convoy_turnos').report_action(self)

    def export_excel(self):
        """Exportar datos del reporte a Excel"""
        self.ensure_one()
        
        # Obtener los datos
        domain = [
            ('fecha_solicitud', '=', self.date_from),
        ]
        
        if self.convoy_id:
            domain.append(('convoy_id', '=', self.convoy_id.id))
            
        # Obtener todos los registros de agendar_servicio en el rango de fechas
        turnos = self.env['mz.agendar_servicio'].search(domain)
        
        # Obtener servicios para agrupar
        servicios = turnos.mapped('servicio_base_id')
        
        # Inicializar estructura de resultado
        result = {}
        for servicio in servicios:
            result[servicio.id] = {
                'nombre': servicio.name,
                'asignados': {
                    'beneficiarios': 0,
                    'dependientes': 0,
                    'mascotas': 0,
                },
                'ejecutados': {
                    'beneficiarios': 0,
                    'dependientes': 0,
                    'mascotas': 0,
                }
            }
        
        # Contar turnos por tipo de servicio
        for turno in turnos:
            servicio_id = turno.servicio_base_id.id
            
            # Omitir si no se encuentra el servicio
            if servicio_id not in result:
                continue
            
            # Determinar si es beneficiario, dependiente o mascota
            categoria = None
            if turno.mascota_id:
                categoria = 'mascotas'
            elif turno.tipo_beneficiario == 'dependiente' and turno.dependiente_id:
                categoria = 'dependientes'
            else:
                categoria = 'beneficiarios'
            
            # Agregar a conteos asignados
            result[servicio_id]['asignados'][categoria] += 1
            
            # Agregar a conteos ejecutados si el turno fue atendido
            if turno.state == 'atendido':
                result[servicio_id]['ejecutados'][categoria] += 1
        
        # Calcular totales
        total_asignados = {
            'beneficiarios': sum(item['asignados']['beneficiarios'] for item in result.values()),
            'dependientes': sum(item['asignados']['dependientes'] for item in result.values()),
            'mascotas': sum(item['asignados']['mascotas'] for item in result.values()),
        }
        
        total_ejecutados = {
            'beneficiarios': sum(item['ejecutados']['beneficiarios'] for item in result.values()),
            'dependientes': sum(item['ejecutados']['dependientes'] for item in result.values()),
            'mascotas': sum(item['ejecutados']['mascotas'] for item in result.values()),
        }
        
        # Calcular sumas totales
        suma_asignados = total_asignados['beneficiarios'] + total_asignados['dependientes'] + total_asignados['mascotas']
        suma_ejecutados = total_ejecutados['beneficiarios'] + total_ejecutados['dependientes'] + total_ejecutados['mascotas']
        
        # Crear archivo Excel
        output = BytesIO()
        workbook = xlsxwriter.Workbook(output)
        worksheet = workbook.add_worksheet('Reporte de Turnos')
        
        # Estilos
        title_format = workbook.add_format({
            'bold': True, 
            'font_size': 14, 
            'align': 'center', 
            'valign': 'vcenter'
        })
        header_format = workbook.add_format({
            'bold': True, 
            'bg_color': '#DDDDDD', 
            'align': 'center', 
            'border': 1
        })
        yellow_format = workbook.add_format({
            'bg_color': '#FFD700', 
            'align': 'center', 
            'border': 1
        })
        green_format = workbook.add_format({
            'bg_color': '#6B8E23', 
            'align': 'center', 
            'border': 1
        })
        cell_format = workbook.add_format({
            'align': 'center', 
            'border': 1
        })
        total_format = workbook.add_format({
            'bold': True, 
            'align': 'center', 
            'border': 1
        })
        bold_yellow_format = workbook.add_format({
            'bold': True,
            'bg_color': '#FFD700', 
            'align': 'center', 
            'border': 1
        })
        bold_green_format = workbook.add_format({
            'bold': True,
            'bg_color': '#6B8E23', 
            'align': 'center', 
            'border': 1
        })
        
        # Título
        worksheet.merge_range('A1:G1', 'Reporte de Turnos de Convoy', title_format)
        worksheet.write('A2', f'Desde: {self.date_from.strftime("%d/%m/%Y")}', workbook.add_format({'bold': True}))        
        if self.convoy_id:
            worksheet.write('E2', f'Convoy: {self.convoy_id.name}', workbook.add_format({'bold': True}))
        
        # Encabezados
        worksheet.merge_range('A4:A5', 'Servicio', header_format)
        worksheet.merge_range('B4:D4', 'Turnos Asignados', yellow_format)
        worksheet.merge_range('E4:G4', 'Turnos Ejecutados', green_format)
        
        worksheet.write('B5', 'Beneficiarios', yellow_format)
        worksheet.write('C5', 'Dependientes', yellow_format)
        worksheet.write('D5', 'Mascotas', yellow_format)
        worksheet.write('E5', 'Beneficiarios', green_format)
        worksheet.write('F5', 'Dependientes', green_format)
        worksheet.write('G5', 'Mascotas', green_format)
        
        # Establecer anchos de columna
        worksheet.set_column('A:A', 20)
        worksheet.set_column('B:G', 15)
        
        # Datos
        row = 5
        for servicio_id, data in result.items():
            row += 1
            worksheet.write(row, 0, data['nombre'], cell_format)
            worksheet.write(row, 1, data['asignados']['beneficiarios'], cell_format)
            worksheet.write(row, 2, data['asignados']['dependientes'], cell_format)
            worksheet.write(row, 3, data['asignados']['mascotas'], cell_format)
            worksheet.write(row, 4, data['ejecutados']['beneficiarios'], cell_format)
            worksheet.write(row, 5, data['ejecutados']['dependientes'], cell_format)
            worksheet.write(row, 6, data['ejecutados']['mascotas'], cell_format)
        
        # Subtotales - Escribir directamente los valores calculados
        row += 1
        worksheet.write(row, 0, 'Subtotal turnos', total_format)
        worksheet.write(row, 1, total_asignados['beneficiarios'], bold_yellow_format)
        worksheet.write(row, 2, total_asignados['dependientes'], bold_yellow_format)
        worksheet.write(row, 3, total_asignados['mascotas'], bold_yellow_format)
        worksheet.write(row, 4, total_ejecutados['beneficiarios'], bold_green_format)
        worksheet.write(row, 5, total_ejecutados['dependientes'], bold_green_format)
        worksheet.write(row, 6, total_ejecutados['mascotas'], bold_green_format)
        
        # Total Turnos - Escribir directamente las sumas calculadas
        row += 1
        worksheet.write(row, 0, 'Total Turnos', total_format)
        
        # Usar merge_range y luego write para los totales
        worksheet.merge_range(row, 1, row, 3, '', total_format)
        worksheet.write(row, 1, suma_asignados, total_format)
        
        worksheet.merge_range(row, 4, row, 6, '', total_format)
        worksheet.write(row, 4, suma_ejecutados, total_format)
        
        workbook.close()
        
        # Crear el adjunto
        filename = f"Reporte_Turnos_{self.date_from.strftime('%d_%m_%Y')}"
        if self.convoy_id:
            filename += f"_{self.convoy_id.name}"
        filename += ".xlsx"
        
        excel_data = base64.b64encode(output.getvalue())
        
        attachment = self.env['ir.attachment'].create({
            'name': filename,
            'datas': excel_data,
            'type': 'binary',
            'res_model': self._name,
            'res_id': self.id,
        })
        
        # Devolver la acción para descargar el archivo
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/{attachment.id}?download=true',
            'target': 'self',
        }

class ConvoyTurnosReportWizard(models.TransientModel):
    _name = 'mz.convoy.turnos.report.wizard'
    _description = 'Asistente de Reporte de Turnos de Convoy'

    date_from = fields.Date(string='Fecha Inicio', required=True, default=lambda self: fields.Date.context_today(self).replace(day=1))
    convoy_id = fields.Many2one('mz.convoy', string='Convoy', required=False, domain="[('fecha_inicio_evento', '=', date_from)]")


    
    def action_generate_report(self):
        self.ensure_one()
        
        report = self.env['mz.convoy.turnos.report'].create({
            'date_from': self.date_from,
            'convoy_id': self.convoy_id.id if self.convoy_id else False,
        })
        
        return {
            'name': _('Reporte de Turnos de Convoy'),
            'type': 'ir.actions.act_window',
            'res_model': 'mz.convoy.turnos.report',
            'view_mode': 'form',
            'res_id': report.id,
            'target': 'new',
        }