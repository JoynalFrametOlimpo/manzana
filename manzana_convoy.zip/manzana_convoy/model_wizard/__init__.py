# -*- coding: utf-8 -*-

from . import convoy_beneficiario_wizard
from . import convoy_dependiente_wizard
from . import convoy_mascota_wizard
from . import convoy_suspender_wizard
from . import convoy_turnos_report
from . import convoy_veterinaria_turnos_report

