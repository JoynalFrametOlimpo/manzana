# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo.addons.manzana_de_cuidados import utils
import logging
_logger = logging.getLogger(__name__)


class ConvoyBeneficiarioWizard(models.TransientModel):
    _name = 'mz_convoy.beneficiario_wizard'
    _description = 'Wizard para registro de beneficiarios de Convoy'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'dinardap.mixin']

    # Campos de control
    convoy_id = fields.Many2one('mz.convoy', string='Convoy', required=True)
    beneficiario_id = fields.Many2one('mz.beneficiario', string='Beneficiario')
    tipo_registro = fields.Selection([('masivo', 'Registro Masivo'),('asistencia', 'Registro por Asistencia'), ('socioeconomico', 'Registro Socioeconómico')],
                                      string='Tipo de Registro', required=True, default='masivo')    
    # Campos comunes
    programa_id = fields.Many2one('pf.programas', related='convoy_id.programa_id', readonly=True)
    tipo_documento = fields.Selection([('dni', 'Cédula'), ('pasaporte', 'Pasaporte'), ('carnet_extranjeria', 'Carnet de Extranjería')],
                                       string='Tipo de Documento', required=True, tracking=True)
    numero_documento = fields.Char('Número de Documento', required=True)
    apellido_paterno = fields.Char(string='Apellido Paterno')
    apellido_materno = fields.Char(string='Apellido Materno')
    primer_nombre = fields.Char(string='Primer Nombre')
    segundo_nombre = fields.Char(string='Segundo Nombre')   
    es_extranjero = fields.Boolean('¿Es Migrante Extranjero?')
    pais_id = fields.Many2one('res.country', string='País', ondelete='restrict')
    celular = fields.Char('Celular')
    operadora_id = fields.Many2one('pf.items', domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.catalogo_operadoras').id)], string='Operadora')

    # Campos de asistencia y socioeconómicos
    fecha_nacimiento = fields.Date('Fecha de Nacimiento')
    edad = fields.Char(string="Edad", compute="_compute_edad") 
    estado_civil_id = fields.Many2one('pf.items', string='Estado Civil', domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.estado_civil').id)])
    genero_id = fields.Many2one('pf.items', string='Género', domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.genero').id)])
    provincia_id = fields.Many2one("res.country.state", string='Provincia', ondelete='restrict', domain="[('country_id', '=?', pais_id)]")
    ciudad_id = fields.Many2one('res.country.ciudad', string='Ciudad' , ondelete='restrict', domain="[('state_id', '=?', provincia_id)]")
    direccion = fields.Char('Dirección de domicilio')
    email = fields.Char('Correo Electrónico')
    tiene_discapacidad = fields.Boolean('¿Tiene usted alguna discapacidad?')
    recibe_bono = fields.Boolean('¿Recibe algún tipo de bono?')
    tipo_discapacidad_id = fields.Many2one('pf.items', string='Tipo de Discapacidad', 
                                           domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.tipos_discapacidad').id)])
    nivel_instruccion_id = fields.Many2one('pf.items', string='Nivel de Instrucción',
                                           domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.catalogo_nivel_instruccion').id)])
    situacion_laboral_id = fields.Many2one('pf.items', string='Situación Laboral',
                                           domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.catalogo_situacion_laboral').id)])
    tipo_vivienda_id = fields.Many2one('pf.items', string='La vivienda donde habita es?', 
                                       domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.catalogo_tipo_vivienda').id)])
    
    # Campos de servicios básicos
    tiene_internet = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Su hogar cuenta con internet?')
    tiene_agua_potable = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿La vivienda donde habita tiene servicio de agua potable por tubería?')
    tiene_luz_electrica = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿La vivienda donde habita cuenta con luz eléctrica?')
    tiene_alcantarillado = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿La vivienda donde habita tiene servicio de alcantarillado?')
   
    # Campos socioeconómicos adicionales
    es_cuidador = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Es cuidador/a?')
    hora_tarea_domestica = fields.Integer(string='Horas a tareas domésticas')
    sostiene_hogar = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Usted sostiene económicamente su hogar?')
    enfermedad_catastrofica = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Padece alguna enfermedad catastrófica?')
    
    # Campos de composición familiar
    hombres_hogar = fields.Integer(string='¿Cuántos hombres viven en el hogar(contando niños)?')
    mujer_hogar = fields.Integer(string='¿Cuántos mujeres viven en el hogar(contando niñas)?')
    ninos_menores = fields.Integer(string='¿Cuántos niños menores de edad habitan en el hogar?')
    ninos_5_estudiando = fields.Integer(string='¿Cuántos niños mayores de 5 años que habitan en el hogar estan estudiando?')
    mujeres_embarazadas = fields.Integer(string='¿Cuántas mujeres embarazadas habitan en su hogar?', default=0)
    mujeres_embarazadas_chequeos = fields.Integer(string='¿Cuántas mujeres embarazadas que habitan en el hogar asisten a chequeos médicos?', default=0)
    mujeres_embarazadas_menores = fields.Integer(string='¿Cuántas de las mujeres embarazadas son menores de 18 años?', default=0)
    mayor_65 = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Hay mayores de 65 años viviendo en su hogar?')
    discapacidad_hogar = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Hay personas con discapacidad viviendo en su hogar?')
    tiene_discapacidad_hogar = fields.Selection([('si', 'SI'), ('no', 'NO')], string='¿Hay personas con discapacidad viviendo en su hogar?', default='no')
    tipo_discapacidad_hogar_id = fields.Many2one('pf.items', string='¿Qué tipo de discapacidad tiene?',
                                                 domain=lambda self: [('catalogo_id', '=', self.env.ref('prefectura_base.tipos_discapacidad').id)])    
    dependientes_ids = fields.One2many('mz_convoy.dependiente_wizard', 'wizard_id', string='Dependientes')
    mascota_ids = fields.One2many('mz_convoy.mascota_wizard', 'wizard_id', string='Mascotas',)
    domain="[('programa_id', '=', programa_id), ('servicio_id.tipo_servicio', '=', 'mascota')]"
    servicio_ids = fields.Many2many(string='Servicios a Recibir', comodel_name='mz.asignacion.servicio', relation='wz_beneficiario_servicio_rel', 
                                    domain="[('programa_id', '=', programa_id),('servicio_id.tipo_servicio', '!=', 'mascota')]", column1='wz_beneficiario_id', column2='sevicio_id',)
    atencion_medica_especial = fields.Boolean(string='Atención Médica Especial', tracking=True)
    tiene_servicio_medico = fields.Boolean(string='Tiene Servicio Médico', compute='_compute_tiene_servicio_medico')
    dinardap_estado = fields.Selection([
        ('local', 'Local'),
        ('no_consultado', 'No Consultado'),
        ('consultando', 'Consultando...'),
        ('encontrado', 'Datos Encontrados'),
        ('no_encontrado', 'No Encontrado'),
        ('error', 'Error en Consulta'),
        ('no_aplica', 'No Aplica')  # Para documentos que no son cédula
    ], string='Estado DINARDAP', default='no_consultado', readonly=True)
    dinardap_mensaje = fields.Text(string='Mensaje DINARDAP', readonly=True)
    # Campo para evitar consultas duplicadas
    dinardap_ultimo_documento_consultado = fields.Char(
        string='Último Documento Consultado', 
        readonly=True,
        help='Último número de documento consultado en DINARDAP para evitar consultas duplicadas'
    )

    @api.onchange('tipo_documento', 'numero_documento', 'tipo_registro')
    def _onchange_documento_unificado(self):
        """OnChange unificado: Búsqueda local PRIMERO + DINARDAP + validaciones"""
        if self.env.context.get('skip_onchange') or self.env.context.get('promover_registro'):
            return
        # Reset del estado DINARDAP al cambiar cualquier campo
        self.dinardap_estado = 'no_consultado'
        self.dinardap_mensaje = False
        
        # Limpiar el número de documento si existe
        if self.numero_documento:
            self.numero_documento = str(self.numero_documento).strip()
        
        # Si no hay número de documento, limpiar todos los campos
        if not self.numero_documento:
            self._limpiar_todos_los_campos()
            return
        
        # Si no hay tipo de documento seleccionado, limpiar campos y salir
        if not self.tipo_documento:
            self._limpiar_todos_los_campos()
            return
        
        # =============== VALIDACIÓN FORMATO vs TIPO DE DOCUMENTO ===============
        # Validar ANTES de buscar para evitar comportamientos inconsistentes
        resultado_validacion = self._validar_documento()
        if resultado_validacion:  # Si hay error en validación
            self._limpiar_todos_los_campos()  # Limpiar campos en caso de error
            return resultado_validacion
        
        # =============== PASO 1: BUSCAR EN BASE DE DATOS LOCAL ===============
        beneficiario_local = self._buscar_beneficiario_local()
        
        if beneficiario_local:
            # Si encontramos el beneficiario localmente, cargarlo
            self.dinardap_estado = 'local'
            self.dinardap_mensaje = f'Datos cargados desde base local (ID: {beneficiario_local.id})'
            self._cargar_beneficiario(beneficiario_local)
            return {
                'warning': {
                    'title': _('✅ Beneficiario Encontrado'),
                    'message': _('Beneficiario encontrado en la base de datos GPG.\nDatos cargados automáticamente.')
                }
            }
        
        # =============== PASO 2: NO EXISTE LOCALMENTE ===============
        
        # Si NO es cédula, limpiar campos y marcar como no aplica
        if self.tipo_documento != 'dni':
            self._limpiar_todos_los_campos()
            self.dinardap_estado = 'no_aplica'
            self.dinardap_mensaje = f'DINARDAP no aplica para {self.tipo_documento}'
            return
        
        # =============== PASO 3: ES CÉDULA Y NO EXISTE LOCALMENTE ===============
        # Consultar DINARDAP para cédulas válidas que no existen localmente
        return self._consultar_dinardap_si_no_existe()

    def _validar_documento(self):
        """Validaciones específicas por tipo de documento"""
        
        if self.tipo_documento == 'dni':            
            # Validar longitud de cédula
            if len(self.numero_documento) != 10:
                self.dinardap_estado = 'error'
                self.dinardap_mensaje = f'Cédula debe tener 10 dígitos (actual: {len(self.numero_documento)})'
                return {'warning': {
                    'title': _('❌ Cédula Incompleta'),
                    'message': _('La cédula debe tener exactamente 10 dígitos.\n\nDigitado: %s dígitos') % len(self.numero_documento)
                }}
            
            # Validar que sean solo números
            if not self.numero_documento.isdigit():
                self.dinardap_estado = 'error'
                self.dinardap_mensaje = 'Cédula debe contener solo números'
                return {'warning': {
                    'title': _('❌ Formato Inválido'),
                    'message': _('La cédula solo debe contener números.\n\nCaracteres inválidos detectados.')
                }}
            
            # Validar usando algoritmo ecuatoriano
            if not utils.validar_cedula(self.numero_documento):
                self.numero_documento = False
                self.dinardap_estado = 'error'
                self.dinardap_mensaje = 'Cédula inválida según algoritmo ecuatoriano'
                return {'warning': {
                    'title': _('❌ Cédula Inválida'),
                    'message': _('El número de cédula ingresado no es válido según el algoritmo de verificación ecuatoriano.\n\nPor favor verifique los dígitos.')
                }}
        
        elif self.tipo_documento == 'pasaporte':            
            if len(self.numero_documento) < 6 or len(self.numero_documento) > 15:
                return {'warning': {
                    'title': _('❌ Pasaporte Inválido'),
                    'message': _('El número de pasaporte debe tener entre 6 y 15 caracteres.')
                }}
        
        elif self.tipo_documento == 'carnet_extranjeria':
            if len(self.numero_documento) < 6 or len(self.numero_documento) > 20:
                return {'warning': {
                    'title': _('❌ Carnet Inválido'),
                    'message': _('El número de carnet debe tener entre 6 y 20 caracteres.')
                }}
        
        return None  # Sin errores

    def _buscar_beneficiario_local(self):
        """Buscar beneficiario en la base de datos GPG"""
        return self.env['mz.beneficiario'].search([
            ('numero_documento', '=', self.numero_documento),
            ('programa_id.modulo_id', '=', self.env.ref('prefectura_base.modulo_4').id)
        ], limit=1)

    def _consultar_dinardap_si_no_existe(self):
        """Consultar DINARDAP solo si no existe en base local"""
        self.dinardap_estado = 'consultando'
        self.dinardap_mensaje = 'Beneficiario no encontrado localmente. Consultando DINARDAP...'
        
        try:
            # Llamar al método del mixin para consulta DINARDAP
            result = self._consultar_dinardap_automatico()
            return result
            
        except Exception as e:
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error al consultar DINARDAP: {str(e)[:100]}'
            _logger.error(f"Error en consulta DINARDAP onchange: {str(e)}")
            
            # Si falla DINARDAP, limpiar campos
            self._limpiar_todos_los_campos()
            
            return {
                'warning': {
                    'title': _('⚠️ Error de Consulta'),
                    'message': _('Error al consultar DINARDAP: %s\n\nCampos limpiados para ingreso manual.') % str(e)[:100]
                }
            }

    def _limpiar_todos_los_campos(self):
        """Limpiar todos los campos cuando no hay datos"""
        
        # Campos básicos
        campos_basicos = {
            'apellido_paterno': False,
            'apellido_materno': False,
            'primer_nombre': False,
            'segundo_nombre': False,
            'es_extranjero': False,
            'pais_id': False,
            'celular': False,
            'operadora_id': False,
            'fecha_nacimiento': False,
            'estado_civil_id': False,
            'genero_id': False,
            'provincia_id': False,
            'ciudad_id': False,
            'direccion': False,
            'email': False,
            'tiene_discapacidad': False,
            'recibe_bono': False,
            'dependientes_ids': [(5, 0, 0)]
        }
        
        # Campos socioeconómicos
        campos_socioeconomicos = {
            'nivel_instruccion_id': False,
            'situacion_laboral_id': False,
            'tipo_vivienda_id': False,
            'tiene_internet': False,
            'tiene_agua_potable': False,
            'tiene_luz_electrica': False,
            'tiene_alcantarillado': False,
            'es_cuidador': False,
            'hora_tarea_domestica': False,
            'sostiene_hogar': False,
            'enfermedad_catastrofica': False,
            'hombres_hogar': False,
            'mujer_hogar': False,
            'ninos_menores': False,
            'ninos_5_estudiando': False,
            'mujeres_embarazadas': False,
            'mujeres_embarazadas_chequeos': False,
            'mujeres_embarazadas_menores': False,
            'mayor_65': False,
            'tiene_discapacidad_hogar': False,
            'tipo_discapacidad_hogar_id': False
        }
        
        # Actualizar campos básicos
        self.update(campos_basicos)
        
        # Actualizar campos socioeconómicos si existen
        if hasattr(self, 'nivel_instruccion_id'):
            self.update(campos_socioeconomicos)
    
    
 
    def _consultar_dinardap_automatico(self):
        """Método separado para la consulta automática DINARDAP"""
        
        # Solo consultar si no se ha consultado antes para esta cédula
        numero_limpio = str(self.numero_documento).strip()
        
        # Verificar si ya se consultó este documento
        if (self.dinardap_consultado and 
            self.dinardap_ultimo_documento_consultado == numero_limpio):
            # Ya se consultó este documento, no hacer nada
            return
        
        try:
            dinardap_service = self._get_dinardap_service()
            
            # Verificar si el servicio está habilitado
            if not dinardap_service._is_service_enabled():
                self.dinardap_estado = 'no_aplica'
                self.dinardap_mensaje = 'Servicio DINARDAP deshabilitado'
                return {
                    'warning': {
                        'title': _('ℹ️ Servicio No Disponible'),
                        'message': _('El servicio DINARDAP está deshabilitado.\n\nLos datos deben ingresarse manualmente.')
                    }
                }
            
            # Intentar consulta
            datos = dinardap_service.consultar_ciudadano(numero_limpio)
            
            if datos:
                self._aplicar_datos_dinardap(datos)
                # Guardar referencia para evitar consultas duplicadas
                self.dinardap_ultimo_documento_consultado = numero_limpio                
               
                return {
                    'warning': {
                        'title': _('✅ Beneficiario Encontrado'),
                        'message': _('Se han cargado los datos desde DINARDAP.\nDatos cargados automáticamente.')
                    }
                }
            else:
                self.dinardap_estado = 'no_encontrado'
                self.dinardap_mensaje = f'No se encontraron datos para cédula {numero_limpio}'
                self.dinardap_ultimo_documento_consultado = numero_limpio  # Marcar como consultado aunque no se encontraron datos
                return {
                    'warning': {
                        'title': _('❌ Sin Resultados en DINARDAP'),
                        'message': _('No se encontraron datos para la cédula: %s\n\n• Verifique que la cédula sea correcta\n• La persona debe estar registrada en el sistema\n• Complete los datos manualmente') % numero_limpio
                    }
                }
                
        except ValidationError as e:
            # Errores de validación (formato de cédula, etc.)
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error de validación: {str(e)}'
            return {
                'warning': {
                    'title': _('⚠️ Error de Validación'),
                    'message': str(e)
                }
            }
            
        except UserError as e:
            # Errores controlados (servicio no disponible, etc.)
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error de servicio: {str(e)}'
            return {
                'warning': {
                    'title': _('⚠️ Error de Servicio DINARDAP'),
                    'message': _('No se pudo consultar DINARDAP: %s\n\nPor favor complete los datos manualmente.') % str(e)[:100]
                }
            }
            
        except Exception as e:
            # Errores inesperados
            self.dinardap_estado = 'error'
            self.dinardap_mensaje = f'Error inesperado: {str(e)[:100]}'
            _logger.warning(f"Error inesperado en consulta automática DINARDAP: {str(e)}")
            return {
                'warning': {
                    'title': _('⚠️ Error de Conexión'),
                    'message': _('No se pudo conectar con DINARDAP:\n\n%s\n\nPor favor complete los datos manualmente.') % str(e)[:100]
                }
            }
        
    def _get_dinardap_field_mapping(self):
        """Sobrescribir mapeo específico para este modelo"""
        return {
            'primer_nombre': 'primer_nombre',
            'segundo_nombre': 'segundo_nombre',
            'apellido_paterno': 'apellido_paterno', 
            'apellido_materno': 'apellido_materno',
            'numero_documento': 'numero_documento',
            'fecha_nacimiento': 'fecha_nacimiento',
            'direccion': 'direccion',
            # Mapear campos específicos si los tienes
            'provincia_nombre': 'provincia_nombre_temp',  # Campo temporal
            'ciudad_nombre': 'ciudad_nombre_temp',        # Campo temporal
        }


    @api.depends('servicio_ids')
    def _compute_tiene_servicio_medico(self):
        """Determina si hay servicios médicos seleccionados"""
        for record in self:
            # Verificar si alguno de los servicios seleccionados es médico
            record.tiene_servicio_medico = any(servicio.servicio_id.if_consulta_medica for servicio in record.servicio_ids)

    @api.model
    def default_get(self, fields_list):
        """Sobrescribimos default_get para cargar datos cuando es promoción"""
        res = super().default_get(fields_list)
        
        if self._context.get('promover_registro') and self._context.get('default_numero_documento'):
            beneficiario = self.env['mz.beneficiario'].search([
                ('numero_documento', '=', self._context.get('default_numero_documento')),('programa_id.modulo_id', '=', self.env.ref('prefectura_base.modulo_4').id)
            ], limit=1)
            
            if beneficiario:
                valores = self._prepare_valores_promocion(beneficiario)
                res.update(valores)
        
        return res

    def _prepare_valores_promocion(self, beneficiario):
        """Prepara todos los valores del beneficiario para la promoción"""
        valores = {
            'beneficiario_id': beneficiario.id,
            'tipo_documento': beneficiario.tipo_documento,
            'numero_documento': beneficiario.numero_documento,
            'apellido_paterno': beneficiario.apellido_paterno,
            'apellido_materno': beneficiario.apellido_materno,
            'primer_nombre': beneficiario.primer_nombre,
            'segundo_nombre': beneficiario.segundo_nombre,
            'es_extranjero': beneficiario.es_extranjero,
            'pais_id': beneficiario.pais_id.id,
            'celular': beneficiario.celular,
            'operadora_id': beneficiario.operadora_id.id,
            'email': beneficiario.email if hasattr(beneficiario, 'email') else False,
        }

        # Cargar campos adicionales si existen
        if hasattr(beneficiario, 'fecha_nacimiento'):
            valores.update({
                'fecha_nacimiento': beneficiario.fecha_nacimiento,
                'estado_civil_id': beneficiario.estado_civil_id.id if beneficiario.estado_civil_id else False,
                'genero_id': beneficiario.genero_id.id if beneficiario.genero_id else False,
                'provincia_id': beneficiario.provincia_id.id if beneficiario.provincia_id else False,
                'ciudad_id': beneficiario.ciudad_id.id if beneficiario.ciudad_id else False,
                'direccion': beneficiario.direccion if hasattr(beneficiario, 'direccion') else False,               
                'tiene_discapacidad': beneficiario.tiene_discapacidad if hasattr(beneficiario, 'tiene_discapacidad') else False,
                'recibe_bono': beneficiario.recibe_bono if hasattr(beneficiario, 'recibe_bono') else False,
            })

        # Cargar campos socioeconómicos si están disponibles y el tipo es socioeconómico
        if self._context.get('default_tipo_registro') == 'socioeconomico':
            campos_socioeconomicos = {
                'nivel_instruccion_id': beneficiario.nivel_instruccion_id.id if beneficiario.nivel_instruccion_id else False,
                'situacion_laboral_id': beneficiario.situacion_laboral_id.id if beneficiario.situacion_laboral_id else False,
                'tipo_vivienda_id': beneficiario.tipo_vivienda_id.id if beneficiario.tipo_vivienda_id else False,
                'tiene_internet': beneficiario.tiene_internet if hasattr(beneficiario, 'tiene_internet') else False,
                'tiene_agua_potable': beneficiario.tiene_agua_potable if hasattr(beneficiario, 'tiene_agua_potable') else False,
                'tiene_luz_electrica': beneficiario.tiene_luz_electrica if hasattr(beneficiario, 'tiene_luz_electrica') else False,
                'tiene_alcantarillado': beneficiario.tiene_alcantarillado if hasattr(beneficiario, 'tiene_alcantarillado') else False,
                'es_cuidador': beneficiario.es_cuidador if hasattr(beneficiario, 'es_cuidador') else False,
                'hora_tarea_domestica': beneficiario.hora_tarea_domestica if hasattr(beneficiario, 'hora_tarea_domestica') else 0,
                'sostiene_hogar': beneficiario.sostiene_hogar if hasattr(beneficiario, 'sostiene_hogar') else False,
                'enfermedad_catastrofica': beneficiario.enfermedad_catastrofica if hasattr(beneficiario, 'enfermedad_catastrofica') else False,
                'hombres_hogar': beneficiario.hombres_hogar if hasattr(beneficiario, 'hombres_hogar') else 0,
                'mujer_hogar': beneficiario.mujer_hogar if hasattr(beneficiario, 'mujer_hogar') else 0,
                'ninos_menores': beneficiario.ninos_menores if hasattr(beneficiario, 'ninos_menores') else 0,
                'ninos_5_estudiando': beneficiario.ninos_5_estudiando if hasattr(beneficiario, 'ninos_5_estudiando') else 0,
                'mujeres_embarazadas': beneficiario.mujeres_embarazadas if hasattr(beneficiario, 'mujeres_embarazadas') else 0,
                'mujeres_embarazadas_chequeos': beneficiario.mujeres_embarazadas_chequeos if hasattr(beneficiario, 'mujeres_embarazadas_chequeos') else 0,
                'mujeres_embarazadas_menores': beneficiario.mujeres_embarazadas_menores if hasattr(beneficiario, 'mujeres_embarazadas_menores') else 0,
                'mayor_65': beneficiario.mayor_65 if hasattr(beneficiario, 'mayor_65') else False,
                'tiene_discapacidad_hogar': beneficiario.tiene_discapacidad_hogar if hasattr(beneficiario, 'tiene_discapacidad_hogar') else False,
                'tipo_discapacidad_hogar_id': beneficiario.tipo_discapacidad_hogar_id.id if beneficiario.tipo_discapacidad_hogar_id else False,
            }
            valores.update(campos_socioeconomicos)

        return valores

    
    @api.depends('fecha_nacimiento')
    def _compute_edad(self):
        for record in self:
            if record.fecha_nacimiento:
                hoy = date.today()
                diferencia = relativedelta(hoy, record.fecha_nacimiento)
                record.edad = f"{diferencia.years} años, {diferencia.months} meses, {diferencia.days} días"
            else:
                record.edad = "Sin fecha de nacimiento"

   
#VERIFICAR EL CORRECTO FUNCIONAMIENTO DE ESTA PANTALLA
  

    def _cargar_beneficiario(self, beneficiario):
        """Carga los datos del beneficiario encontrado incluyendo dependientes"""
        # Cargar los datos del beneficiario
        self.beneficiario_id = beneficiario.id       
        self.apellido_paterno = beneficiario.apellido_paterno
        self.apellido_materno = beneficiario.apellido_materno
        self.primer_nombre = beneficiario.primer_nombre
        self.segundo_nombre = beneficiario.segundo_nombre
        self.es_extranjero = beneficiario.es_extranjero
        self.pais_id = beneficiario.pais_id.id
        self.celular = beneficiario.celular
        self.operadora_id = beneficiario.operadora_id.id
        self.email = beneficiario.email
        # Cargar campos adicionales según el tipo de registro
        if self.tipo_registro in ['asistencia', 'socioeconomico']:
            self._cargar_campos_adicionales(beneficiario)
            
        # Limpiar dependientes existentes
        self.dependientes_ids = [(5, 0, 0)]
        
        # Buscar dependientes en mz_convoy.beneficiario
        dependientes_convoy = self.env['mz_convoy.beneficiario'].search([
            ('convoy_id', '=', self.convoy_id.id),
            ('beneficiario_id', '=', beneficiario.id),
            ('tipo_beneficiario', '=', 'dependiente')
        ])
        
        # Cargar los dependientes encontrados
        for dep_convoy in dependientes_convoy:
            if dep_convoy.dependiente_id:
                fecha_nacimiento = dep_convoy.fecha_nacimiento or dep_convoy.dependiente_id.fecha_nacimiento
                
                # Primero creamos el diccionario de valores completo
                vals_dependiente = {
                    'programa_id': self.programa_id.id,
                    'dependiente_id': dep_convoy.dependiente_id.id,
                    'tipo_dependiente': dep_convoy.dependiente_id.tipo_dependiente.id,
                    'primer_apellido': dep_convoy.dependiente_id.primer_apellido,
                    'segundo_apellido': dep_convoy.dependiente_id.segundo_apellido,
                    'primer_nombre': dep_convoy.dependiente_id.primer_nombre,
                    'segundo_nombre': dep_convoy.dependiente_id.segundo_nombre,
                    'fecha_nacimiento': fecha_nacimiento,  # Asignamos la fecha explícitamente
                    'tipo_documento': dep_convoy.dependiente_id.tipo_documento,
                    'numero_documento': dep_convoy.dependiente_id.numero_documento,
                }
                
               
                # Creamos el registro
                self.dependientes_ids = [(0, 0, vals_dependiente)]
                
               
        # Buscamos mascotas existentes en el convoy      
        mascotas_convoy = self.env['mz_convoy.beneficiario'].search([
            ('convoy_id', '=', self.convoy_id.id),
            ('beneficiario_id', '=', beneficiario.id),
            ('tipo_beneficiario', '=', 'titular'),
            ('mascota_id', '!=', False),
        ])

        # Limpiamos las mascotas actuales
        self.mascota_ids = [(5, 0, 0)]

        # Agregamos cada mascota encontrada
        for mascota_convoy in mascotas_convoy:
            if mascota_convoy.mascota_id:
                self.mascota_ids = [(0, 0, {
                    'programa_id': self.programa_id.id,
                    'mascota_busqueda_id': mascota_convoy.mascota_id.id,
                    'mascota_id': mascota_convoy.mascota_id.id,
                    'name': mascota_convoy.mascota_id.name,
                    'especie_id': mascota_convoy.mascota_id.especie_id.id,
                    'raza': mascota_convoy.mascota_id.raza,
                    'sexo': mascota_convoy.mascota_id.sexo,
                    'fecha_nacimiento': mascota_convoy.mascota_id.fecha_nacimiento,
                    'edad_aproximada': mascota_convoy.mascota_id.edad_aproximada,
                    'color': mascota_convoy.mascota_id.color,
                    'peso': mascota_convoy.mascota_id.peso,
                    'esterilizado': mascota_convoy.mascota_id.esterilizado,
                    'fecha_esterilizacion': mascota_convoy.mascota_id.fecha_esterilizacion,
                    'estado': mascota_convoy.mascota_id.estado,
                    'condicion_especial': mascota_convoy.mascota_id.condicion_especial,
                    'ultima_vacunacion': mascota_convoy.mascota_id.ultima_vacunacion,
                    'ultima_desparasitacion': mascota_convoy.mascota_id.ultima_desparasitacion,
                    'notas': mascota_convoy.mascota_id.notas,
                    'is_new_mascota': False
                })] 

    

    def _cargar_campos_adicionales(self, beneficiario):
        """Carga campos adicionales para registros de asistencia y socioeconómicos"""
        self.fecha_nacimiento = beneficiario.fecha_nacimiento
        self.estado_civil_id = beneficiario.estado_civil_id.id
        self.genero_id = beneficiario.genero_id.id
        self.provincia_id = beneficiario.provincia_id
        self.ciudad_id = beneficiario.ciudad_id
        self.direccion = beneficiario.direccion
        self.email = beneficiario.email        
        self.recibe_bono = beneficiario.recibe_bono
        self.tiene_discapacidad = beneficiario.tiene_discapacidad
        self.tipo_discapacidad_id = beneficiario.tipo_discapacidad_id.id
        
        if self.tipo_registro == 'socioeconomico':
            self.nivel_instruccion_id = beneficiario.nivel_instruccion_id.id
            self.situacion_laboral_id = beneficiario.situacion_laboral_id.id
            self.tipo_vivienda_id = beneficiario.tipo_vivienda_id.id
            self.tiene_internet = beneficiario.tiene_internet
            self.tiene_agua_potable = beneficiario.tiene_agua_potable
            self.tiene_luz_electrica = beneficiario.tiene_luz_electrica
            self.tiene_alcantarillado = beneficiario.tiene_alcantarillado
            self.es_cuidador = beneficiario.es_cuidador
            self.hora_tarea_domestica = beneficiario.hora_tarea_domestica
            self.sostiene_hogar = beneficiario.sostiene_hogar
            self.enfermedad_catastrofica = beneficiario.enfermedad_catastrofica
            self.hombres_hogar = beneficiario.hombres_hogar
            self.mujer_hogar = beneficiario.mujer_hogar
            self.ninos_menores = beneficiario.ninos_menores
            self.ninos_5_estudiando = beneficiario.ninos_5_estudiando
            self.mujeres_embarazadas = beneficiario.mujeres_embarazadas
            self.mujeres_embarazadas_chequeos = beneficiario.mujeres_embarazadas_chequeos
            self.mujeres_embarazadas_menores = beneficiario.mujeres_embarazadas_menores
            self.mayor_65 = beneficiario.mayor_65
            self.tiene_discapacidad_hogar = beneficiario.tiene_discapacidad_hogar
            self.tipo_discapacidad_hogar_id = beneficiario.tipo_discapacidad_hogar_id.id

    def _prepare_beneficiary_values(self):
        """Prepara los valores para crear/actualizar el beneficiario"""
        # Valores base que serán usados tanto para pf.beneficiario como para mz.beneficiario
        vals = {
            'programa_id': self.programa_id.id,
            'tipo_documento': self.tipo_documento,
            'numero_documento': self.numero_documento,
            'apellido_paterno': self.apellido_paterno,
            'apellido_materno': self.apellido_materno,
            'primer_nombre': self.primer_nombre,
            'segundo_nombre': self.segundo_nombre,
            'es_extranjero': self.es_extranjero,
            'pais_id': self.pais_id.id,
            'celular': self.celular,
            'operadora_id': self.operadora_id.id,
            'email': self.email,
        }
        
        if self.tipo_registro in ['asistencia', 'socioeconomico']:
            vals.update({
                'fecha_nacimiento': self.fecha_nacimiento,
                'estado_civil_id': self.estado_civil_id.id,
                'genero_id': self.genero_id.id,
                'provincia_id': self.provincia_id.id,
                'ciudad_id': self.ciudad_id.id,
                'direccion': self.direccion,                
                'tiene_discapacidad': self.tiene_discapacidad,
                'recibe_bono': self.recibe_bono,
                'tipo_discapacidad_id': self.tipo_discapacidad_id.id
            })
            
            if self.tipo_registro == 'socioeconomico':
                vals.update({
                    'nivel_instruccion_id': self.nivel_instruccion_id.id,
                    'situacion_laboral_id': self.situacion_laboral_id.id,
                    'tipo_vivienda_id': self.tipo_vivienda_id.id,
                    'tiene_internet': self.tiene_internet,
                    'tiene_agua_potable': self.tiene_agua_potable,
                    'tiene_luz_electrica': self.tiene_luz_electrica,
                    'tiene_alcantarillado': self.tiene_alcantarillado,
                    'es_cuidador': self.es_cuidador,
                    'hora_tarea_domestica': self.hora_tarea_domestica,
                    'sostiene_hogar': self.sostiene_hogar,
                    'enfermedad_catastrofica': self.enfermedad_catastrofica,
                    'hombres_hogar': self.hombres_hogar,
                    'mujer_hogar': self.mujer_hogar,
                    'ninos_menores': self.ninos_menores,
                    'ninos_5_estudiando': self.ninos_5_estudiando,
                    'mujeres_embarazadas': self.mujeres_embarazadas,
                    'mujeres_embarazadas_chequeos': self.mujeres_embarazadas_chequeos,
                    'mujeres_embarazadas_menores': self.mujeres_embarazadas_menores,
                    'mayor_65': self.mayor_65,
                    'tiene_discapacidad_hogar': self.tiene_discapacidad_hogar,
                    'tipo_discapacidad_hogar_id': self.tipo_discapacidad_hogar_id.id if self.tiene_discapacidad_hogar == 'si' else False,
                })
        
        return vals
    
    
    
    def action_register(self):
        #SOLO SE USA PARA PROMOVER
        if self._context.get('promover_registro', False) and self._context.get('registros_ids', []):
            registros_ids = self._context.get('registros_ids', [])
            registros = self.env['mz_convoy.beneficiario'].browse(registros_ids)            
            for registro in registros:
                registro.write({'tipo_registro': self.tipo_registro})       
                if registro.tipo_beneficiario == 'titular':
                    vals = self._prepare_beneficiary_values()  
                    registro.beneficiario_id.write(vals)

            return {
                'type': 'ir.actions.client',
                'tag': 'reload',
            }
        """Registra o actualiza el beneficiario en mz.beneficiario y lo añade al convoy."""
        # Preparar los valores para el beneficiario
        servicios_infantiles = self.servicio_ids.filtered(lambda s: s.servicio_id.tipo_servicio == 'cuidado_infantil')
        if servicios_infantiles:
            raise UserError("Los servicios de cuidado infantil solo pueden ser asignados a dependientes.")
        
        vals = self._prepare_beneficiary_values()
        
        # Buscar si existe el beneficiario
        existing_beneficiario = self.env['mz.beneficiario'].search([('numero_documento', '=', self.numero_documento),('programa_id.modulo_id', '=', self.env.ref('prefectura_base.modulo_4').id)], limit=1)
        if existing_beneficiario:
            existing_beneficiario.write(vals)
            beneficiario = existing_beneficiario
        else:
            beneficiario = self.env['mz.beneficiario'].create(vals)
        # IMPORTANTE: Asignamos el beneficiario_id al wizard para que esté disponible
        self.beneficiario_id = beneficiario.id

        # Actualizar o crear relación convoy-beneficiario
        rel_vals = {'tipo_registro': self.tipo_registro, 'fecha_registro': fields.Datetime.now(),}
        # Buscar si ya existe la relación
        existing_rel = self.env['mz_convoy.beneficiario'].search([('convoy_id', '=', self.convoy_id.id), ('beneficiario_id', '=', beneficiario.id)],
                                                                limit=1)
        if existing_rel:
            existing_rel.write(rel_vals)
        else:
            rel_vals.update({
                'convoy_id': self.convoy_id.id,
                'beneficiario_id': beneficiario.id,
                'tipo_beneficiario': 'titular'
            })
            self.env['mz_convoy.beneficiario'].create(rel_vals)

        # Procesar los dependientes actuales
        dependientes_actuales = self.env['mz_convoy.beneficiario'].search([('convoy_id', '=', self.convoy_id.id), ('beneficiario_id', '=', beneficiario.id), 
                                                                        ('tipo_beneficiario', '=', 'dependiente')])
        dependientes_wizard_ids = self.dependientes_ids.mapped('dependiente_id.id')
        for dep_actual in dependientes_actuales:
            if dep_actual.dependiente_id.id not in dependientes_wizard_ids:
                dep_actual.unlink()
        
        # Procesar los dependientes del wizard
        for dependiente_wizard in self.dependientes_ids:
            # Si existe un dependiente buscado, solo actualizamos
            if dependiente_wizard.dependiente_busqueda_id:
                dependiente_vals = dependiente_wizard._prepare_dependiente_values()
                dependiente_wizard.dependiente_busqueda_id.write(dependiente_vals)
                dependiente = dependiente_wizard.dependiente_busqueda_id
            else:
                # Buscar si ya existe un dependiente con el mismo documento
                existing_dependiente = self.env['mz.dependiente'].search([
                    ('tipo_documento', '=', dependiente_wizard.tipo_documento),
                    ('numero_documento', '=', dependiente_wizard.numero_documento)
                ], limit=1)
                if existing_dependiente:
                    # Si existe, actualizamos sus datos
                    dependiente_vals = dependiente_wizard._prepare_dependiente_values()                    
                    existing_dependiente.write(dependiente_vals)
                    dependiente = existing_dependiente
                else:
                    # Si no existe, creamos uno nuevo
                    dependiente_vals = dependiente_wizard._prepare_dependiente_values()
                    dependiente = self.env['mz.dependiente'].create(dependiente_vals)
                # Actualizamos el wizard con el dependiente
                dependiente_wizard.write({'dependiente_id': dependiente.id})

            # Crear relación convoy-dependiente si no existe
            convoy_dependiente = self.env['mz_convoy.beneficiario'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('beneficiario_id', '=', beneficiario.id),
                ('dependiente_id', '=', dependiente.id), 
                ('tipo_beneficiario', '=', 'dependiente')
            ], limit=1)

            if convoy_dependiente:
                convoy_dependiente.write({
                    'fecha_nacimiento': dependiente.fecha_nacimiento  # Añadir esta línea
                })
                
                if dependiente_wizard.servicio_ids:
                    convoy_dependiente.write({
                        'servicio_ids': [(4, servicio.servicio_id.id) for servicio in dependiente_wizard.servicio_ids]
                    })
            else:                
                # Si no existe, creamos con los servicios iniciales
                self.env['mz_convoy.beneficiario'].create({
                    'convoy_id': self.convoy_id.id,
                    'beneficiario_id': beneficiario.id,
                    'dependiente_id': dependiente.id,
                    'tipo_beneficiario': 'dependiente',
                    'tipo_registro': self.tipo_registro,
                    'fecha_nacimiento': dependiente.fecha_nacimiento,  # Cambiar self.tipo_registro por dependiente.fecha_nacimiento
                    'fecha_registro': fields.Datetime.now(),
                    'servicio_ids': [(6, 0, dependiente_wizard.servicio_ids.mapped('servicio_id').ids)]
                })

        for mascota_wizard in self.mascota_ids:
            # Si existe una mascota buscada o es una mascota existente, solo actualizamos
            if mascota_wizard.mascota_busqueda_id or mascota_wizard.mascota_id:
                # Si viene de búsqueda usamos esa, sino usamos la mascota existente
                mascota = mascota_wizard.mascota_busqueda_id or mascota_wizard.mascota_id
                mascota_vals = mascota_wizard._prepare_mascota_values()
                mascota.write(mascota_vals)
            else:
                # Solo creamos si es completamente nueva
                mascota_vals = mascota_wizard._prepare_mascota_values()
                mascota = self.env['mz.mascota'].create(mascota_vals)
                mascota_wizard.write({'mascota_id': mascota.id})

            # Crear relación convoy-mascota si no existe
            convoy_beneficiario = self.env['mz_convoy.beneficiario'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('beneficiario_id', '=', beneficiario.id),
                ('tipo_beneficiario', '=', 'titular'),
                ('mascota_id', '=', mascota.id)
            ], limit=1)

            if convoy_beneficiario:
                if mascota_wizard.servicio_ids:
                    convoy_beneficiario.write({
                        'servicio_ids': [(4, servicio.servicio_id.id) for servicio in mascota_wizard.servicio_ids]
                    })
            else:
                self.env['mz_convoy.beneficiario'].create({
                    'convoy_id': self.convoy_id.id,
                    'beneficiario_id': beneficiario.id,
                    'mascota_id': mascota.id,
                    'tipo_beneficiario': 'titular',
                    'tipo_registro': self.tipo_registro,
                    'fecha_registro': fields.Datetime.now(),
                    'servicio_ids': [(6, 0, mascota_wizard.servicio_ids.mapped('servicio_id').ids)]
                })
                
        agendas_creadas = self._crear_agendas_servicios()
        
        if agendas_creadas:
            # Limpiamos los servicios del titular
            self.servicio_ids = [(5, 0, 0)]            
            # Limpiamos los servicios de los dependientes
            for dependiente in self.dependientes_ids:
                dependiente.servicio_ids = [(5, 0, 0)]                
            # Limpiamos los servicios de las mascotas
            for mascota in self.mascota_ids:
                mascota.servicio_ids = [(5, 0, 0)]            
            action = self.env.ref('manzana_convoy.action_report_turnos')
            return action.with_context(active_ids=agendas_creadas.ids).report_action(agendas_creadas.ids)
        
        # Si no hay agendas, solo recargamos la vista
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
    
    def _crear_agendas_servicios(self):
        """Crea las agendas y turnos para cada servicio seleccionado"""
        import logging
        _logger = logging.getLogger(__name__)
        
        AgendarServicio = self.env['mz.agendar_servicio']
        AgendaServicioAsistencia = self.env['mz.asistencia_servicio']
        
        # Obtenemos el beneficiario recién creado/actualizado
        beneficiario = self.env['mz.beneficiario'].search([
            ('numero_documento', '=', self.numero_documento),('programa_id.modulo_id', '=', self.env.ref('prefectura_base.modulo_4').id)
        ], limit=1)
        
        if not beneficiario:
            raise UserError('No se encontró el beneficiario para crear las agendas')
        
        # Variable para rastrear el médico asignado al titular para servicios médicos
        titulares_medicos = {}  # Diccionario para guardar {servicio_id: medico_id}
        
        # Lista para almacenar los valores de todas las agendas a crear
        agendas_por_crear = []
        orden_esperado = []
        
        # Conjunto para rastrear combinaciones únicas y evitar duplicados
        # Formato: (beneficiario_id, tipo_beneficiario, servicio_id, dependiente_id/mascota_id)
        combinaciones_unicas = set()
        
        # Obtenemos al beneficiario titular para usar en todas las secciones
        convoy_beneficiario_titular = self.env['mz_convoy.beneficiario'].search([
            ('convoy_id', '=', self.convoy_id.id),
            ('beneficiario_id', '=', beneficiario.id),
            ('tipo_beneficiario', '=', 'titular')
        ], limit=1)
        
        if not convoy_beneficiario_titular:
            raise UserError('No se encontró la relación convoy-beneficiario para el titular')
        
        # Procesamos servicios del titular
        if self.servicio_ids:
            for servicio in self.servicio_ids:
                try:
                    # Creamos una clave única para esta combinación
                    clave = ('titular', beneficiario.id, servicio.id, False, False)
                    
                    # Verificamos si ya procesamos esta combinación
                    if clave in combinaciones_unicas:
                        continue
                    
                    # Verificamos si ya existe una asistencia pendiente
                    existe_asistencia = AgendaServicioAsistencia.search([
                        ('beneficiario_id', '=', beneficiario.id),
                        ('tipo_beneficiario', '=', 'titular'),
                        ('asistio', '=', 'pendiente'),
                        ('servicio_id', '=', servicio.id)
                    ], limit=1)
                    
                    if existe_asistencia:
                        continue  # Saltamos esta combinación
                    
                    # Verificamos si es un servicio médico
                    es_servicio_medico = servicio.servicio_id.if_consulta_medica if servicio.servicio_id else False
                    
                    # Aquí determinamos qué método usar para obtener el personal
                    if es_servicio_medico and self.atencion_medica_especial:
                        # Usamos el método específico para atención médica especial
                        personal = self._obtener_personal_atencion_especial(servicio)
                        # Si no hay médicos especiales disponibles, usamos el método normal
                        if not personal:
                            personal = self._obtener_siguiente_personal(servicio)
                    else:
                        # Método normal para distribución regular
                        personal = self._obtener_siguiente_personal(servicio)
                    
                    # Si es servicio médico, guardamos el médico para usarlo con dependientes
                    if es_servicio_medico:
                        titulares_medicos[servicio.servicio_id.id] = personal.id
                    
                    # Preparamos los valores para crear la agenda
                    agenda_vals = {
                        'convoy_id': self.convoy_id.id,
                        'programa_id': self.programa_id.id,
                        'beneficiario_id': beneficiario.id,
                        'tipo_beneficiario': 'titular',
                        'servicio_id': servicio.id,
                        'personal_id': personal.id,
                    }
                    
                    # Solo agregamos el campo si existe en el modelo
                    if 'atencion_medica_especial' in self.env['mz.agendar_servicio']._fields:
                        agenda_vals['atencion_medica_especial'] = self.atencion_medica_especial if es_servicio_medico else False
                    
                    # Agregamos a la lista de agendas por crear
                    agendas_por_crear.append(agenda_vals)

                    orden_esperado.append({
                        'beneficiario_id': agenda_vals['beneficiario_id'],
                        'tipo_beneficiario': agenda_vals['tipo_beneficiario'],
                        'dependiente_id': agenda_vals.get('dependiente_id'),
                        'mascota_id': agenda_vals.get('mascota_id'),
                        'servicio_id': agenda_vals['servicio_id']
                    })
                    
                    # Marcamos esta combinación como procesada
                    combinaciones_unicas.add(clave)
                    
                    # Actualizamos servicios del titular
                    convoy_beneficiario_titular.write({
                        'servicio_ids': [(4, servicio.servicio_id.id)]
                    })
                    
                except Exception as e:
                    raise UserError(f'Error al preparar agenda para el servicio del titular: {str(e)}')

        # Procesamos servicios de dependientes (fuera del if del titular)
        for dependiente_wizard in self.dependientes_ids:
            if dependiente_wizard.servicio_ids:
                convoy_dependiente = self.env['mz_convoy.beneficiario'].search([
                    ('convoy_id', '=', self.convoy_id.id),
                    ('beneficiario_id', '=', beneficiario.id),
                    ('dependiente_id', '=', dependiente_wizard.dependiente_id.id),
                    ('tipo_beneficiario', '=', 'dependiente')
                ], limit=1)

                if convoy_dependiente:
                    for servicio in dependiente_wizard.servicio_ids:
                        try:
                            # Creamos una clave única para esta combinación
                            clave = ('dependiente', beneficiario.id, servicio.id, dependiente_wizard.dependiente_id.id, False)
                            
                            # Verificamos si ya procesamos esta combinación
                            if clave in combinaciones_unicas:
                                continue
                                
                            # Verificamos si ya existe una asistencia pendiente
                            existe_asistencia = AgendaServicioAsistencia.search([
                                ('beneficiario_id', '=', beneficiario.id),
                                ('tipo_beneficiario', '=', 'dependiente'),
                                ('dependiente_id', '=', dependiente_wizard.dependiente_id.id),
                                ('asistio', '=', 'pendiente'),
                                ('servicio_id', '=', servicio.id)
                            ], limit=1)
                            
                            if existe_asistencia:
                                continue  # Saltamos esta combinación
                                
                            # Verificamos si es un servicio médico
                            es_servicio_medico = servicio.servicio_id.if_consulta_medica if servicio.servicio_id else False
                            personal = None
                            
                            # Si es servicio médico, verificamos si el titular tiene un médico asignado para este servicio
                            if es_servicio_medico and servicio.servicio_id.id in titulares_medicos:
                                # Si el titular tiene atención médica especial, usamos el mismo médico
                                if self.atencion_medica_especial:
                                    personal = self.env['res.users'].browse(titulares_medicos[servicio.servicio_id.id])
                            
                            # Si todavía no tenemos personal asignado, obtenemos uno según la regla correspondiente
                            if not personal:
                                if es_servicio_medico and self.atencion_medica_especial:
                                    # Usamos distribución de personal especial
                                    personal = self._obtener_personal_atencion_especial(servicio)
                                    if not personal:
                                        personal = self._obtener_siguiente_personal(servicio)
                                else:
                                    # Distribución normal
                                    personal = self._obtener_siguiente_personal(servicio)
                            
                            # Preparamos los valores para crear la agenda
                            agenda_vals = {
                                'convoy_id': self.convoy_id.id,
                                'programa_id': self.programa_id.id,
                                'beneficiario_id': beneficiario.id,
                                'tipo_beneficiario': 'dependiente',
                                'dependiente_id': dependiente_wizard.dependiente_id.id,
                                'servicio_id': servicio.id,
                                'personal_id': personal.id,
                            }
                            
                            # Solo agregamos el campo si existe en el modelo
                            if 'atencion_medica_especial' in self.env['mz.agendar_servicio']._fields:
                                agenda_vals['atencion_medica_especial'] = self.atencion_medica_especial if es_servicio_medico else False
                            
                            # Agregamos a la lista de agendas por crear
                            agendas_por_crear.append(agenda_vals)
                            orden_esperado.append({
                                'beneficiario_id': agenda_vals['beneficiario_id'],
                                'tipo_beneficiario': agenda_vals['tipo_beneficiario'],
                                'dependiente_id': agenda_vals.get('dependiente_id'),
                                'mascota_id': agenda_vals.get('mascota_id'),
                                'servicio_id': agenda_vals['servicio_id']
                            })
                            # Marcamos esta combinación como procesada
                            combinaciones_unicas.add(clave)
                            
                            # Actualizamos servicios del dependiente
                            convoy_dependiente.write({
                                'servicio_ids': [(4, servicio.servicio_id.id)]
                            })
                            
                        except Exception as e:
                            raise UserError(f'Error al preparar agenda para el servicio {servicio.name} del dependiente: {str(e)}')

        # Procesamos servicios de mascotas (fuera del if del titular)
        for mascota_wizard in self.mascota_ids:
            if mascota_wizard.servicio_ids:
                mascota = mascota_wizard.mascota_id or mascota_wizard.mascota_busqueda_id
                
                if not mascota:
                    raise UserError(f'No se encontró la mascota {mascota_wizard.name} para crear las agendas')

                for servicio in mascota_wizard.servicio_ids:
                    try:
                        # Creamos una clave única para esta combinación
                        clave = ('titular', beneficiario.id, servicio.id, False, mascota.id)
                        
                        # Verificamos si ya procesamos esta combinación
                        if clave in combinaciones_unicas:
                            continue
                            
                        # Verificamos si ya existe una asistencia pendiente
                        existe_asistencia = AgendaServicioAsistencia.search([
                            ('beneficiario_id', '=', beneficiario.id),
                            ('tipo_beneficiario', '=', 'titular'),
                            ('mascota_id', '=', mascota.id),
                            ('asistio', '=', 'pendiente'),
                            ('servicio_id', '=', servicio.id)
                        ], limit=1)
                        
                        if existe_asistencia:
                            continue  # Saltamos esta combinación
                            
                        # Para mascotas siempre usamos la lógica normal
                        personal = self._obtener_siguiente_personal(servicio)
                        
                        # Preparamos los valores para crear la agenda
                        agenda_vals = {
                            'convoy_id': self.convoy_id.id,
                            'programa_id': self.programa_id.id,
                            'beneficiario_id': beneficiario.id,
                            'tipo_beneficiario': 'titular',
                            'mascota_id': mascota.id,
                            'servicio_id': servicio.id,
                            'personal_id': personal.id,
                        }
                        
                        # Agregamos a la lista de agendas por crear
                        agendas_por_crear.append(agenda_vals)
                        orden_esperado.append({
                            'beneficiario_id': agenda_vals['beneficiario_id'],
                            'tipo_beneficiario': agenda_vals['tipo_beneficiario'],
                            'dependiente_id': agenda_vals.get('dependiente_id'),
                            'mascota_id': agenda_vals.get('mascota_id'),
                            'servicio_id': agenda_vals['servicio_id']
                        })
                        # Marcamos esta combinación como procesada
                        combinaciones_unicas.add(clave)
                        
                        convoy_beneficiario = self.env['mz_convoy.beneficiario'].search([
                            ('convoy_id', '=', self.convoy_id.id),
                            ('beneficiario_id', '=', beneficiario.id),
                            ('tipo_beneficiario', '=', 'titular'),
                            ('mascota_id', '=', mascota.id)
                        ], limit=1)
                        
                        if convoy_beneficiario:
                            convoy_beneficiario.write({
                                'servicio_ids': [(4, servicio.servicio_id.id)]
                            })
                            
                    except Exception as e:
                        raise UserError(f'Error al preparar agenda para el servicio {servicio.name} de la mascota {mascota_wizard.name}: {str(e)}')

        # Creamos todas las agendas en una sola operación
        agendas_creadas = self.env['mz.agendar_servicio']
        if agendas_por_crear:
            try:
                agendas_creadas = AgendarServicio.create(agendas_por_crear)                
                # Reordenar según el orden esperado
                agendas_ordenadas = self.env['mz.agendar_servicio']
                
                for orden_info in orden_esperado:
                    # Buscar la agenda correspondiente en las creadas
                    agenda_encontrada = agendas_creadas.filtered(
                        lambda a: a.beneficiario_id.id == orden_info['beneficiario_id'] and
                                a.tipo_beneficiario == orden_info['tipo_beneficiario'] and
                                a.servicio_id.id == orden_info['servicio_id'] and
                                (a.dependiente_id.id if a.dependiente_id else False) == (orden_info.get('dependiente_id') or False) and
                                (a.mascota_id.id if a.mascota_id else False) == (orden_info.get('mascota_id') or False)
                    )                    
                    if agenda_encontrada:
                        agendas_ordenadas |= agenda_encontrada[0]  # Tomamos la primera si hay múltiples
                    else:
                        _logger.error(f"No se encontró agenda para: {orden_info}")
                
                return agendas_ordenadas
                
            except Exception as e:
                self._cr.rollback()
                raise UserError(f'Error al crear las agendas: {str(e)}')

        return agendas_creadas

    def _obtener_personal_atencion_especial(self, servicio_id):
        """
        Obtiene el siguiente personal disponible con atención médica especial 
        para servicios médicos, distribuyendo equitativamente.
        """
        AgendarServicio = self.env['mz.agendar_servicio']
        
        # Obtener solo el personal del servicio actual
        personal_ids = servicio_id.personal_ids
        if not personal_ids:
            return None
        
        # Buscar planificaciones médicas con atención especial
        planificaciones_especiales = self.env['mz.genera.planificacion.servicio'].search([
            ('convoy_id', '=', self.convoy_id.id),
            ('if_consulta_medica', '=', True),
            ('atencion_medica_especial', '=', True)
        ])
        # Obtener personal de estas planificaciones
        personal_especial_ids = planificaciones_especiales.mapped('personal_id')
        
        # Filtrar personal actual que esté en la lista de especiales
        personal_filtrado = personal_ids.filtered(lambda p: p.id in personal_especial_ids.ids)
        
        # Si no hay personal especializado, retornamos None
        if not personal_filtrado:
            return None
        
        # Buscamos las últimas agendas creadas para este servicio con personal filtrado
        ultimas_agendas = AgendarServicio.search([
            ('servicio_id.servicio_id', '=', servicio_id.servicio_id.id),
            ('convoy_id', '=', self.convoy_id.id),
            ('personal_id', 'in', personal_filtrado.ids)
        ], order='create_date desc')
        
        # Si no hay agendas previas, comenzamos con el primer personal
        if not ultimas_agendas:
            return personal_filtrado[0]
        
        # Obtenemos el último personal asignado
        ultimo_personal = ultimas_agendas[0].personal_id
        # raise UserError(ultimo_personal)
        # Encontramos su posición en la lista
        try:
            indice_actual = list(personal_filtrado).index(ultimo_personal)
            # Retornamos el siguiente, o volvemos al principio si estamos al final
            siguiente_indice = (indice_actual + 1) % len(personal_filtrado)
            return personal_filtrado[siguiente_indice]
        except ValueError:
            # Si el último personal ya no está en la lista, comenzamos con el primero
            return personal_filtrado[0]

    def _obtener_siguiente_personal(self, servicio_id):
        """
        Obtiene el siguiente personal disponible para el servicio usando un sistema rotativo.
        """
        AgendarServicio = self.env['mz.agendar_servicio']
        
        # Obtenemos todo el personal disponible para este servicio
        personal_ids = servicio_id.personal_ids
        if not personal_ids:
            raise UserError(f'No hay personal asignado al servicio {servicio_id.name}')
        
        # Verificamos si es un servicio médico
        es_servicio_medico = servicio_id.servicio_id.if_consulta_medica if servicio_id.servicio_id else False
        
        # Solo aplicamos filtrado para servicios médicos
        personal_a_usar = personal_ids
        if es_servicio_medico:
            # Identificamos el personal que está en planificaciones especiales para excluirlo
            planificaciones_especiales = self.env['mz.genera.planificacion.servicio'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('if_consulta_medica', '=', True),
                ('atencion_medica_especial', '=', True)
            ])
            
            # Obtener IDs del personal en planificaciones especiales
            personal_especial_ids = planificaciones_especiales.mapped('personal_id').ids
            
            # Filtrar el personal para excluir a los que están en planificaciones especiales
            personal_regular = personal_ids.filtered(lambda p: p.id not in personal_especial_ids)    
            if personal_regular:       
                personal_a_usar = personal_regular
            else:
                raise UserError("Problema al encontrar personal disponible")
        
        
        # Buscamos las últimas agendas creadas para este servicio con el personal a usar
        ultimas_agendas = AgendarServicio.search([
            ('servicio_id', '=', servicio_id.id),
            ('convoy_id', '=', self.convoy_id.id),
            ('personal_id', 'in', personal_a_usar.ids)
        ], order='create_date desc')

        # Si no hay agendas previas, comenzamos con el primer personal
        if not ultimas_agendas:
            return personal_a_usar[0]

        # Obtenemos el último personal asignado
        ultimo_personal = ultimas_agendas[0].personal_id
        
        # Encontramos su posición en la lista
        try:
            indice_actual = list(personal_a_usar).index(ultimo_personal)
            # Retornamos el siguiente, o volvemos al principio si estamos al final
            siguiente_indice = (indice_actual + 1) % len(personal_a_usar)
            return personal_a_usar[siguiente_indice]
        except ValueError:
            # Si el último personal ya no está en la lista, comenzamos con el primero
            return personal_a_usar[0]