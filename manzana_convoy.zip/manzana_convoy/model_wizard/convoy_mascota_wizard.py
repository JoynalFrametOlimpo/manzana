from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta
from datetime import date
from odoo.exceptions import UserError # type: ignore



class ConvoyMascotaWizard(models.TransientModel):
    _name = 'mz_convoy.mascota_wizard'
    _description = 'Mascota en Wizard de Beneficiario'


    @api.depends('name', 'wizard_id.beneficiario_id.apellido_paterno', 'wizard_id.beneficiario_id.apellido_materno')
    def _compute_codigo(self):
        for record in self:
            if record.name and record.wizard_id.beneficiario_id:
                name = record.name.replace(' ', '_')
                letra_apellido_paterno = record.wizard_id.beneficiario_id.apellido_paterno[0].upper() if record.wizard_id.beneficiario_id.apellido_paterno else 'X'
                letra_apellido_materno = record.wizard_id.beneficiario_id.apellido_materno[0].upper() if record.wizard_id.beneficiario_id.apellido_materno else 'X'
                record.codigo = f"{name}-{letra_apellido_paterno}{letra_apellido_materno}"
            else:
                record.codigo = False
    
    @api.model
    def _get_especie_domain(self):
        catalogo_id = self.env.ref('prefectura_base.catalogo_especie').id
        return [('catalogo_id', '=', catalogo_id)]

    # Relación con el wizard principal
    wizard_id = fields.Many2one('mz_convoy.beneficiario_wizard', string='Wizard')
    programa_id = fields.Many2one('pf.programas', string="Programas", related='wizard_id.programa_id', readonly=True, store=True)
    beneficiario_id = fields.Many2one('mz.beneficiario', string='Beneficiario')

    mascota_id = fields.Many2one('mz.mascota', string='Mascota')
    # Campos de identificación
    name = fields.Char(string='Nombre de la Mascota', required=True)
    codigo = fields.Char( string='Código de Identificación', compute='_compute_codigo', store=True)
    mascota_busqueda_domain = fields.Char(compute="_compute_mascota_busqueda_domain", readonly=True, store=False)
    mascota_busqueda_id = fields.Many2one('mz.mascota', string='Buscar Mascota',domain="[('beneficiario_id', '=', beneficiario_id)]")
    is_new_mascota = fields.Boolean('Es nueva mascota', default=True)
    # Información básica
    especie_id = fields.Many2one('pf.items', string='Especie', domain=_get_especie_domain, required=True)
    raza = fields.Char(string='Raza')
    sexo = fields.Selection([('macho', 'Macho'), ('hembra', 'Hembra')], string='Sexo', required=True)
    fecha_nacimiento = fields.Date(string='Fecha de Nacimiento')
    edad_aproximada = fields.Float(string='Edad Aproximada (Años)')
    color = fields.Char(string='Color/Señas Particulares')
    peso = fields.Float(string='Peso (kg)')
    # Estado reproductivo
    esterilizado = fields.Boolean(string='Esterilizado')
    fecha_esterilizacion = fields.Date(string='Fecha de Esterilización')
    # Estado de salud
    estado = fields.Selection([('activo', 'Activo'), ('fallecido', 'Fallecido'), ('extraviado', 'Extraviado')], string='Estado', default='activo')
    condicion_especial = fields.Text(string='Condiciones Especiales', help="Alergias, enfermedades crónicas, etc.")
    # Historial de vacunación
    ultima_vacunacion = fields.Date(string='Última Vacunación')
    ultima_desparasitacion = fields.Date(string='Última Desparasitación')
    notas = fields.Text(string='Notas Adicionales')
    servicio_ids = fields.Many2many('mz.asignacion.servicio', 'mz_convoy_wizard_mascota_servicio_rel', 'mascota_wizard_id', 'servicio_id', string='Servicios a Recibir',
                                    domain="[('programa_id', '=', programa_id), ('servicio_id.tipo_servicio', '=', 'mascota')]")
    

    @api.depends('wizard_id.mascota_ids', 'beneficiario_id')
    def _compute_mascota_busqueda_domain(self):
        for record in self:
            if record.beneficiario_id:
                # Obtener los IDs de mascotas ya agregadas al wizard
                mascotas_wizard = record.wizard_id.mascota_ids.mapped('mascota_id').ids
                
                if mascotas_wizard:
                    # Si hay mascotas en el wizard, mostrar solo las que no están agregadas
                    record.mascota_busqueda_domain = f"[('beneficiario_id', '=', {record.beneficiario_id.id}), ('id', 'not in', {mascotas_wizard})]"
                else:
                    # Si no hay mascotas en el wizard, mostrar todas las del beneficiario
                    record.mascota_busqueda_domain = f"[('beneficiario_id', '=', {record.beneficiario_id.id})]"
            else:
                record.mascota_busqueda_domain = "[('id', 'in', [])]"


    @api.onchange('fecha_nacimiento', 'fecha_esterilizacion')
    def _onchange_fecha_esterilizacion(self):
        for record in self:
            if record.fecha_nacimiento and record.fecha_esterilizacion:
                if record.fecha_esterilizacion < record.fecha_nacimiento:
                    raise UserError('La fecha de esterilización no puede ser anterior a la fecha de nacimiento.')
                if record.fecha_esterilizacion > date.today():
                    raise UserError('La fecha de esterilización no puede ser posterior a la fecha actual.')

    @api.onchange('fecha_nacimiento')
    def _onchange_fecha_nacimiento(self):
        for record in self:
            if record.fecha_nacimiento:
                if record.fecha_nacimiento > date.today():
                    raise UserError('La fecha de nacimiento no puede ser posterior a la fecha actual.')
                record.edad_aproximada = relativedelta(date.today(), record.fecha_nacimiento).years

    @api.onchange('mascota_busqueda_id')
    def _onchange_mascota_busqueda(self):
        if self.mascota_busqueda_id:
            self.is_new_mascota = False
            self._cargar_mascota(self.mascota_busqueda_id)
        else:
            self.is_new_mascota = True
            self._limpiar_campos()

    def _limpiar_campos(self):
        """Limpia todos los campos cuando se está creando una nueva mascota"""
        self.update({
            'mascota_id': False,
            'name': False,
            'especie_id': False,
            'raza': False,
            'sexo': False,
            'fecha_nacimiento': False,
            'edad_aproximada': False,
            'color': False,
            'peso': False,
            'esterilizado': False,
            'fecha_esterilizacion': False,
            'estado': 'activo',
            'condicion_especial': False,
            'ultima_vacunacion': False,
            'ultima_desparasitacion': False,
            'notas': False,
        })

    def _cargar_mascota(self, mascota):
        """Carga los datos de la mascota encontrada"""
        self.update({
            'mascota_id': mascota.id,
            'name': mascota.name,
            'especie_id': mascota.especie_id.id,
            'raza': mascota.raza,
            'sexo': mascota.sexo,
            'fecha_nacimiento': mascota.fecha_nacimiento,
            'edad_aproximada': mascota.edad_aproximada,
            'color': mascota.color,
            'peso': mascota.peso,
            'esterilizado': mascota.esterilizado,
            'fecha_esterilizacion': mascota.fecha_esterilizacion,
            'estado': mascota.estado,
            'condicion_especial': mascota.condicion_especial,
            'ultima_vacunacion': mascota.ultima_vacunacion,
            'ultima_desparasitacion': mascota.ultima_desparasitacion,
            'notas': mascota.notas            
        })

    def _prepare_mascota_values(self):
        """Prepara los valores para crear/actualizar la mascota"""
        return {
            'name': self.name,
            'codigo': self.codigo,  # Incluimos el código computado
            'especie_id': self.especie_id.id,
            'raza': self.raza,
            'sexo': self.sexo,
            'fecha_nacimiento': self.fecha_nacimiento,
            'edad_aproximada': self.edad_aproximada,
            'color': self.color,
            'peso': self.peso,
            'esterilizado': self.esterilizado,
            'fecha_esterilizacion': self.fecha_esterilizacion,
            'estado': self.estado,
            'condicion_especial': self.condicion_especial,
            'ultima_vacunacion': self.ultima_vacunacion,
            'ultima_desparasitacion': self.ultima_desparasitacion,
            'notas': self.notas,
            'beneficiario_id': self.wizard_id.beneficiario_id.id,
        }