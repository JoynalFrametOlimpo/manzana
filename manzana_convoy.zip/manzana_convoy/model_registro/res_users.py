# manzana_convoy/models/res_users.py
from odoo import models, api, _
from odoo.exceptions import ValidationError

class ResUsers(models.Model):
    _inherit = 'res.users'

    @api.constrains('groups_id')
    def _check_exclusive_module_groups(self):
        """Validar que un usuario no tenga permisos de Manzana de Cuidados y Convoy simultáneamente"""
        for user in self:
            # Obtener las categorías de los módulos
            manzana_category = self.env.ref('manzana_de_cuidados.module_category_manzana_cuidados', raise_if_not_found=False)
            convoy_category = self.env.ref('manzana_convoy.module_category_mz_convoy', raise_if_not_found=False)
            
            # Si alguna categoría no existe, saltar validación (módulos no instalados)
            if not manzana_category or not convoy_category:
                continue
                
            # Verificar si el usuario tiene grupos de ambas categorías
            user_groups = user.groups_id
            
            has_manzana_groups = any(
                group.category_id == manzana_category 
                for group in user_groups 
                if group.category_id
            )
            
            has_convoy_groups = any(
                group.category_id == convoy_category 
                for group in user_groups 
                if group.category_id
            )
            
            # Si tiene grupos de ambas categorías, lanzar error
            if has_manzana_groups and has_convoy_groups:
                raise ValidationError(_(
                    "Un usuario no puede tener permisos simultáneamente en los módulos "
                    "'Manzana de Cuidados' y 'Convoy' debido a que comparten tablas. "
                    "Por favor, asigne permisos de solo uno de los módulos."
                ))