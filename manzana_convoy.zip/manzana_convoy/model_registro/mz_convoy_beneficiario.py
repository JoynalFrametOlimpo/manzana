from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ConvoyBeneficiarioRel(models.Model):
    _name = 'mz_convoy.beneficiario'
    _description = 'Relación Convoy Beneficiario'
    _rec_name = 'beneficiario_id'
    _order = 'id'

    # Campos de Relación
    convoy_id = fields.Many2one('mz.convoy', string='Convoy', required=True, ondelete='restrict')
    beneficiario_id = fields.Many2one('mz.beneficiario', string='Beneficiario', required=True, ondelete='restrict')
    # Campos de Control
    tipo_registro = fields.Selection([('masivo', 'Registro Masivo'), ('asistencia', 'Registro por Asistencia'), ('socioeconomico', 'Registro Socioeconómico')],
                                     string='Tipo de Registro', required=False)
    fecha_registro = fields.Datetime(string='Fecha de Registro', default=fields.Datetime.now, required=True)
    user_id = fields.Many2one('res.users', string='Registrado por', default=lambda self: self.env.user,  required=True, readonly=True)
    # Campos de Servicio
    servicio_id = fields.Many2one('mz.servicio', string='Servicio', domain="[('convoy_id', '=', convoy_id)]")
    estado = fields.Selection([('pendiente', 'Pendiente'), ('atendido', 'Atendido')], string='Estado', default='pendiente', required=True)
    # Campos relacionados para información rápida
    numero_documento = fields.Char(related='beneficiario_id.numero_documento', string='Número de Documento', store=True)
    nombres_completos = fields.Char(compute='_compute_nombres_completos', store=True, string='Beneficiario')
    tipo_beneficiario = fields.Selection([('titular', 'Titular'),('dependiente', 'Dependiente')], string='Tipo de Beneficiario', default='titular', required=True, tracking=True)    
    dependiente_id = fields.Many2one('mz.dependiente',string='Dependiente',tracking=True,domain="[('beneficiario_id', '=', beneficiario_id)]",ondelete='restrict')
    mascota_id = fields.Many2one('mz.mascota',string='Mascota',tracking=True,domain="[('beneficiario_id', '=', beneficiario_id)]",ondelete='restrict')
    servicio_ids = fields.Many2many('mz.servicio', 'mz_convoy_beneficiario_servicio_recibido_rel', 'convoy_beneficiario_id', 'servicio_id', string='Servicios Solicitados')
    fecha_nacimiento = fields.Date(string='Fecha de Nacimiento')

    _sql_constraints = [
        ('unique_beneficiario_convoy', 
         'UNIQUE(convoy_id, beneficiario_id, tipo_beneficiario, dependiente_id)', 
         'Ya existe un registro con esta combinación de convoy, beneficiario y tipo!')
    ]

    @api.depends('beneficiario_id', 'beneficiario_id.apellido_paterno', 
             'beneficiario_id.apellido_materno', 'beneficiario_id.primer_nombre', 
             'beneficiario_id.segundo_nombre')
    def _compute_nombres_completos(self):
        for record in self:
            if record.beneficiario_id:
                nombres = [
                    record.beneficiario_id.apellido_paterno,
                    record.beneficiario_id.apellido_materno,
                    record.beneficiario_id.primer_nombre,
                    record.beneficiario_id.segundo_nombre
                ]
                record.nombres_completos = ' '.join(filter(None, nombres))
            else:
                record.nombres_completos = False

    @api.constrains('tipo_beneficiario', 'beneficiario_id', 'dependiente_id')
    def _check_beneficiario_dependiente(self):
        for record in self:
            if record.tipo_beneficiario == 'titular' and not record.beneficiario_id:
                raise UserError('Debe seleccionar un beneficiario titular')
            if record.tipo_beneficiario == 'dependiente' and not record.dependiente_id:
                raise UserError('Debe seleccionar un dependiente')
    
    def action_promover_asistencia(self):
        self.ensure_one()
        if self.tipo_registro != 'masivo':
            raise UserError(_('Solo los registros masivos pueden ser promovidos a asistencia.'))
        
        # Si es titular, vamos a buscar todos sus dependientes en el mismo convoy
        registros_a_promover = self
        if self.tipo_beneficiario == 'titular':
            # Buscar todos los dependientes del mismo titular en el mismo convoy
            dependientes = self.env['mz_convoy.beneficiario'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('beneficiario_id', '=', self.beneficiario_id.id),
                ('tipo_beneficiario', '=', 'dependiente'),
                ('tipo_registro', '=', 'masivo')
            ])
            mascotas = self.env['mz_convoy.beneficiario'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('beneficiario_id', '=', self.beneficiario_id.id),
                ('mascota_id', '!=', False),
                ('tipo_registro', '=', 'masivo')
            ])
            if dependientes:
                registros_a_promover += dependientes
            if mascotas:
                registros_a_promover += mascotas
        # raise UserError(registros_a_promover)
        # Crear contexto base
        context = {
            'default_tipo_registro': 'asistencia',
            'default_convoy_id': self.convoy_id.id,
            'default_numero_documento': self.numero_documento,
            'promover_registro': True,
            'hide_dependientes': True,
            'registros_ids': registros_a_promover.ids,  # Pasamos todos los IDs a promover
            'skip_onchange': True,
        }
        
        return {
            'name': _('Promover a Asistencia'),
            'type': 'ir.actions.act_window',
            'res_model': 'mz_convoy.beneficiario_wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': context
        }

    def action_promover_socioeconomico(self):
        self.ensure_one()
        if self.tipo_registro not in ['masivo', 'asistencia']:
            raise UserError(_('Solo los registros masivos o de asistencia pueden ser promovidos a socioeconómico.'))
        
        # Si es titular, vamos a buscar todos sus dependientes en el mismo convoy
        registros_a_promover = self
        if self.tipo_beneficiario == 'titular':
            # Buscar todos los dependientes del mismo titular en el mismo convoy con el mismo tipo de registro
            dependientes = self.env['mz_convoy.beneficiario'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('beneficiario_id', '=', self.beneficiario_id.id),
                ('tipo_beneficiario', '=', 'dependiente'),
                ('tipo_registro', 'in', ['masivo', 'asistencia'])
            ])
            mascotas = self.env['mz_convoy.beneficiario'].search([
                ('convoy_id', '=', self.convoy_id.id),
                ('beneficiario_id', '=', self.beneficiario_id.id),
                ('mascota_id', '!=', False),
                ('tipo_registro', 'in', ['masivo', 'asistencia'])
            ])

            if dependientes:
                registros_a_promover += dependientes
            if mascotas:
                registros_a_promover += mascotas
        
        # Crear contexto base
        context = {
            'default_tipo_registro': 'socioeconomico',
            'default_convoy_id': self.convoy_id.id,
            'default_numero_documento': self.numero_documento,
            'promover_registro': True,
            'hide_dependientes': True,
            'registros_ids': registros_a_promover.ids  # Pasamos todos los IDs a promover
        }
        
        return {
            'name': _('Promover a Socioeconómico'),
            'type': 'ir.actions.act_window',
            'res_model': 'mz_convoy.beneficiario_wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': context
        }

   

    def name_get(self):
        result = []
        for record in self:
            name = f"{record.beneficiario_id.numero_documento} - {record.nombres_completos}"
            result.append((record.id, name))
        return result