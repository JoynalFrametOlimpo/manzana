from odoo import models, fields, api
from datetime import date, datetime, timedelta
from odoo.exceptions import UserError
from odoo.osv import expression
import logging
import pytz


class Convoy(models.Model):
    _name = 'mz.convoy'
    _description = 'Ficha de Evento'
    _inherits = {'pf.programas': 'programa_id'} 
    _inherit = ['mail.thread', 'mail.activity.mixin'] 

    
    def _get_hour_selection(self):
        hours = []
        for hour in range(24):
            for minute in [0, 30]:
                time_str = f"{hour:02d}:{minute:02d}"
                hours.append((time_str, time_str))
        return hours   

    @api.depends('fecha_inicio_evento')
    def _compute_fecha_hasta(self):
        for record in self:
            if record.fecha_inicio_evento:
                record.fecha_hasta_evento = record.fecha_inicio_evento 

    

    tipo_zona = fields.Selection(selection=[('urbano', 'Urbano'), ('rural', 'Rural')],required=True, string='Tipo de Zona',tracking=True)    
    tipo_convoy = fields.Selection(selection=[('brigada', 'Brigada Médica'), ('convoy', 'Convoy')], string="Tipo",default='convoy',required=True)
    sigla_convoy = fields.Char(string='Sigla', tracking=True, required=True,size=30) 
    # Corrección del campo programa_id para apuntar al modelo correcto
    programa_id = fields.Many2one('pf.programas', string='Programa', ondelete='restrict',  required=True, auto_join=True, tracking=True)
    institucion_anfitriona = fields.Char(string='Institución Anfitriona', tracking=True) 
    director_coordinador = fields.Many2one(string='Coordinador Responsable (*)', tracking=True, comodel_name='hr.employee', ondelete='restrict', required=True)       
    bodeguero = fields.Many2one(string='General (*)', tracking=True, comodel_name='hr.employee', ondelete='restrict', required=True)      
    bodeguero_medico_id = fields.Many2one(string='Médico (*)', tracking=True, comodel_name='hr.employee', ondelete='restrict', required=True)      
    bodeguero_veterinario_id = fields.Many2one(string='Veterinaria (*)', tracking=True, comodel_name='hr.employee', ondelete='restrict', required=True)      
    bodeguero_insumos_id = fields.Many2one(string='Insumos (*)', tracking=True, comodel_name='hr.employee', ondelete='restrict', required=True)       
    # El resto de los campos permanecen igual
    fecha_inicio_evento = fields.Date(string='Fecha Inicio (*)',required=True, tracking=True)
    fecha_hasta_evento = fields.Date(string='Fecha Fin', required=True, tracking=True, compute='_compute_fecha_hasta', store=True, readonly=False)
    esta_vigente = fields.Boolean(string='Está Vigente', compute='_compute_esta_vigente')
    dia_semana = fields.Char(string='Día', compute='_compute_dia_semana', store=True, tracking=True)   
    hora_inicio = fields.Selection(selection='_get_hour_selection', string='Hora Inicio (*)',required=True, tracking=True)
    hora_fin = fields.Selection(selection='_get_hour_selection', string='Hora Fin (*)', required=True, tracking=True)
    duracion = fields.Char(string='Duración', compute='_compute_duracion', store=True, tracking=True)    
    tipo_evento = fields.Many2one('pf.items', string='Tipo Evento', tracking=True, domain=lambda self: [('catalogo_id', '=', self.env.ref('manzana_convoy.catalogo_tipo_evento').id)])
    formato_evento = fields.Char(string='Formato de Evento', tracking=True)
    numero_asistentes = fields.Integer(string='Número de Asistentes', tracking=True)
    codigo_vestimenta = fields.Char(string='Código de Vestimenta', tracking=True)   
    participacion_prefecta = fields.Many2one('pf.items', tracking=True, string='Participación  Prefecta', domain=lambda self: [('catalogo_id', '=', self.env.ref('manzana_convoy.catalogo_participacion_especifica').id)])
    tiempo_intervencion = fields.Float(string='Tiempo de Intervención', tracking=True)    
    data_politica = fields.Char(string='Data Política', tracking=True)    
    mesa_tecnica_ids = fields.One2many('mz_convoy.mesa_tecnica', 'evento_id', string='Miembros Mesa Técnica')    
    sillas_requeridas = fields.Integer(string='Sillas Requeridas', tracking=True)
    carpas_requeridas = fields.Integer(string='Carpas Requeridas', tracking=True)
    responsable_convoy = fields.Many2one(string='Responsable del Convoy', tracking=True, comodel_name='hr.employee', ondelete='restrict')
    responsables_avanzada = fields.Many2many('hr.employee', tracking=True, string='Responsables de Avanzada')
    responsable_socializacion = fields.Many2one(string='Responsable de Socialización', tracking=True, comodel_name='hr.employee', ondelete='restrict')
    responsable_mesa_tecnica = fields.Many2one(string='Responsable de Mesa Técnica', tracking=True, comodel_name='hr.employee', ondelete='restrict')
    responsable_convocatoria = fields.Many2one(string='Responsable de Convocatoria del Cantón', tracking=True, comodel_name='hr.employee', ondelete='restrict')
    autoridades_externa_ids = fields.One2many('mz_convoy.autoridades', 'convoy_id', string='Autoridades')
    alertas_quejas_ids = fields.One2many('mz_convoy.alertas_quejas', 'convoy_id', tracking=True, string='Alertas/Quejas')
    mostrar_boton_publicar = fields.Boolean(compute='_compute_mostrar_boton_publicar', compute_sudo=True)
    mostrar_bot_retirar_public = fields.Boolean(compute='_compute_mostrar_bot_retirar_public', compute_sudo=True)
    can_edit_services = fields.Boolean(compute='_compute_can_edit_services')    
    state = fields.Selection([('borrador', 'Borrador'),('aprobado', 'Aprobado'),('ejecutando', 'Ejecutando'),('fin', 'Finalizado'),('suspendido', 'Suspendido')], tracking=True, string='Estado', default='borrador')  
    operadores_ids = fields.Many2many(string='Operadores', comodel_name='hr.employee', relation='convoy_operador_rel', 
                                      column1='convoy_id', column2='employee_id',domain="[('user_id','!=',False)]")
    colaboradores_ids = fields.Many2many(string='Colaboradores', comodel_name='hr.employee', relation='mz_convoy_colaborador_rel', 
                                      column1='convoy_id', column2='colaborador_id') 
    permisos_ids = fields.One2many('mz_convoy.permisos', 'convoy_id', string='Permisos Personal Convoy')
   
    ficha_evento_legalizada = fields.Binary(string="Ficha Evento Legalizada", attachment=True)
    ficha_evento_legalizada_name = fields.Char(string="Nombre Ficha Evento", tracking=True)

    ficha_implantacion_legalizada = fields.Binary(string="Ficha Implantación Legalizada", attachment=True)
    ficha_implantacion_legalizada_name = fields.Char(string="Nombre Ficha Implantación", tracking=True)

    flayer = fields.Binary(string="Flayer digital", attachment=True)
    flayer_name = fields.Char(string="Nombre Flayer digital", tracking=True)

    beneficiario_ids = fields.One2many('mz_convoy.beneficiario', 'convoy_id', string='Beneficiarios')
    beneficiario_count = fields.Integer( string='Número de Beneficiarios', compute='_compute_beneficiario_count')
    beneficiarios_masivo_count = fields.Integer(string='Masivo', compute='_compute_beneficiarios_count')
    beneficiarios_asistencia_count = fields.Integer(string='Asistencia', compute='_compute_beneficiarios_count')
    beneficiarios_socioeconomico_count = fields.Integer(string='Socioeconómico', compute='_compute_beneficiarios_count')
    
    servicios_solicitados_count = fields.Integer(string='Servicios Solicitados', compute='_compute_servicios_count')
    servicios_atendidos_count = fields.Integer(string='Servicios Atendidos', compute='_compute_servicios_count')
    servicios_faltos = fields.Integer(string='Servicios Ausentes', compute='_compute_servicios_count')
    servicios_count = fields.Integer(string='Total Servicios', compute='_compute_servicios_count')

    observacion = fields.Text(string='Observación')
    documento_suspencion = fields.Binary(string="Documento Suspención", attachment=True)
    documento_suspencion_name = fields.Char(string="Nombre Documento Suspención", tracking=True)


    def _search(self, args, offset=0, limit=None, order=None, access_rights_uid=None):
        """
        Método _search personalizado para filtrar registros según el grupo del usuario
        cuando se recibe el contexto 'filtrar_convoy'
        """
        if self._context.get('filtrar_convoy'):
            args = args or []
            user = self.env.user
            
            # Administrador: ve todos los registros
            if user.has_group('manzana_convoy.group_mz_convoy_administrador'):
                # No modificamos args para que vea todo
                pass
            # Coordinador: ve solo convoyes donde es director
            elif user.has_group('manzana_convoy.group_mz_convoy_coordinador'):
                # Verificamos si el usuario tiene un empleado asociado
                if user.employee_id:
                    args = expression.AND([args, [('director_coordinador', '=', user.employee_id.id)]])
                else:
                    args = [('id', '=', -1)]  # No mostrar nada si no tiene empleado
            # Operador: ve solo convoyes en estado ejecutando donde está asignado
            elif user.has_group('manzana_convoy.group_mz_convoy_operador'):
                # Verificamos si el usuario tiene un empleado asociado
                if user.employee_id:
                    args = expression.AND([
                        args,
                        [
                            ('state', '=', 'ejecutando'),
                            ('operadores_ids', 'in', user.employee_id.id)
                        ]
                    ])
                else:
                    args = [('id', '=', -1)]  # No mostrar nada si no tiene empleado
            # Cualquier otro grupo: no ve nada
            else:
                args = [('id', '=', -1)]
                
        return super(Convoy, self)._search(
            args,
            offset=offset,
            limit=limit,
            order=order,
            access_rights_uid=access_rights_uid
        )


    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        """
        Método read_group personalizado para filtrar registros según el grupo del usuario
        cuando se recibe el contexto 'filtrar_convoy'
        """
        if self._context.get('filtrar_convoy'):
            domain = domain or []
            user = self.env.user
            
            # Administrador: ve todos los registros
            if user.has_group('manzana_convoy.group_mz_convoy_administrador'):
                # No modificamos domain para que vea todo
                pass
            # Coordinador: ve solo convoyes donde es director
            elif user.has_group('manzana_convoy.group_mz_convoy_coordinador'):
                # Verificamos si el usuario tiene un empleado asociado
                if user.employee_id:
                    domain = expression.AND([domain, [('director_coordinador', '=', user.employee_id.id)]])
                else:
                    domain = [('id', '=', -1)]  # No mostrar nada si no tiene empleado
            # Operador: ve solo convoyes en estado ejecutando donde está asignado
            elif user.has_group('manzana_convoy.group_mz_convoy_operador'):
                # Verificamos si el usuario tiene un empleado asociado
                if user.employee_id:
                    domain = expression.AND([
                        domain,
                        [
                            ('state', '=', 'ejecutando'),
                            ('operadores_ids', 'in', user.employee_id.id)
                        ]
                    ])
                else:
                    domain = [('id', '=', -1)]  # No mostrar nada si no tiene empleado
            # Cualquier otro grupo: no ve nada
            else:
                domain = [('id', '=', -1)]
                
        return super(Convoy, self).read_group(
            domain, 
            fields, 
            groupby, 
            offset=offset, 
            limit=limit, 
            orderby=orderby, 
            lazy=lazy
        )
            
    @api.depends('fecha_inicio_evento')
    def _compute_esta_vigente(self):
        user_tz = self.env.user.tz or self.env.company.timezone or 'UTC'
        today = datetime.now(pytz.timezone(user_tz)).date()        
        for record in self:
            record.esta_vigente = record.fecha_inicio_evento == today if record.fecha_inicio_evento else False


    @api.onchange('tipo_convoy', 'sector_id', 'fecha_inicio_evento')
    def _onchange_name_fields(self):
        # Verificar si estamos en el contexto de filtrar_convoy
        if self.env.context.get('filtrar_convoy'):
            if self.tipo_convoy and self.sector_id and self.fecha_inicio_evento:
                # Mapeo para mostrar el valor descriptivo en lugar del valor técnico
                tipo_convoy_display = dict(self._fields['tipo_convoy'].selection).get(self.tipo_convoy, '')
                
                # Obtener el sector y formatear la fecha
                sector_nombre = self.sector_id.name or ''
                fecha_formateada = self.fecha_inicio_evento.strftime('%d-%m-%Y')
                
                # Construir el nombre y convertirlo a mayúsculas
                self.name = f"{tipo_convoy_display}-{sector_nombre} - {fecha_formateada}".upper()                
               
    
    @api.onchange('tipo_convoy','sigla_convoy','fecha_inicio_evento')
    def _onchange_sigla(self):
        # Verificar si estamos en el contexto de filtrar_convoy
        if self.env.context.get('filtrar_convoy'):
            if self.sigla_convoy and self.tipo_convoy and self.fecha_inicio_evento:               
                sigla_prefix = ''
                if self.tipo_convoy == 'convoy':
                    sigla_prefix = 'CV'
                elif self.tipo_convoy == 'brigada':
                    sigla_prefix = 'BM'                
                # Construir la sigla completa
                if sigla_prefix:                   
                    fecha_corta = self.fecha_inicio_evento.strftime('%d-%m-%y')
                    self.sigla = f"{sigla_prefix}-{self.sigla_convoy}-{fecha_corta}".upper()

    @api.constrains('hora_inicio', 'hora_fin')
    def _check_horas(self):
        for record in self:
            if record.hora_inicio and record.hora_fin:
                # Convertimos las horas a enteros para poder compararlas
                inicio = int(record.hora_inicio.split(':')[0])
                fin = int(record.hora_fin.split(':')[0])
                
                if inicio >= fin:
                    raise UserError('La hora fin debe ser mayor a la hora de inicio')
                
    @api.constrains('fecha_inicio_evento', 'fecha_hasta_evento')
    def _check_fechas(self):
        for record in self:
            if record.fecha_inicio_evento and record.fecha_hasta_evento:
                if record.fecha_inicio_evento > record.fecha_hasta_evento:
                    raise UserError('La fecha fin no puede ser menor a la fecha de inicio')

    

    
    @api.depends('beneficiario_ids', 'beneficiario_ids.servicio_ids')
    def _compute_servicios_count(self):
        for record in self:
            servicios = self.env['mz.agendar_servicio']
            domain_base = [('convoy_id', '=', record.id)]            
            # Contar por estado
            record.servicios_solicitados_count = servicios.search_count(domain_base + [('state', '=', 'solicitud')])
            record.servicios_atendidos_count = servicios.search_count(domain_base + [('state', '=', 'atendido')])
            record.servicios_faltos = servicios.search_count(domain_base + [('state', '=', 'cancelado_por_falta')])
            record.servicios_count = record.servicios_solicitados_count + record.servicios_atendidos_count + record.servicios_faltos

    @api.depends('beneficiario_ids', 'beneficiario_ids.tipo_registro')
    def _compute_beneficiarios_count(self):
        for record in self:
            beneficiarios = record.beneficiario_ids
            record.beneficiarios_masivo_count = len(beneficiarios.filtered(lambda b: b.tipo_registro == 'masivo'))
            record.beneficiarios_asistencia_count = len(beneficiarios.filtered(lambda b: b.tipo_registro == 'asistencia'))
            record.beneficiarios_socioeconomico_count = len(beneficiarios.filtered(lambda b: b.tipo_registro == 'socioeconomico'))

    def action_view_beneficiarios_masivo(self):
        self.ensure_one()
        return {
            'name': 'Beneficiarios Masivos',
            'view_mode': 'tree,form',
            'res_model': 'mz_convoy.beneficiario',
            'type': 'ir.actions.act_window',
            'domain': [('convoy_id', '=', self.id), ('tipo_registro', '=', 'masivo')],
            'context': {
                'default_convoy_id': self.id,
                'default_tipo_registro': 'masivo',
                'form_view_initial_mode': 'readonly',  # Formulario en modo lectura
                'create': False,  # Deshabilita creación
                'edit': False,    # Deshabilita edición
                'delete': False   # Deshabilita eliminación
            },
            'target': 'current',
        }

    def action_view_beneficiarios_asistencia(self):
        self.ensure_one()
        return {
            'name': 'Beneficiarios por Asistencia',
            'view_mode': 'tree,form',
            'res_model': 'mz_convoy.beneficiario',
            'type': 'ir.actions.act_window',
            'domain': [('convoy_id', '=', self.id), ('tipo_registro', '=', 'asistencia')],
            'context': {
                'default_convoy_id': self.id,
                'default_tipo_registro': 'asistencia',
                'form_view_initial_mode': 'readonly',
                'create': False,
                'edit': False,
                'delete': False
            },
            'target': 'current',
        }

    def action_view_beneficiarios_socioeconomico(self):
        self.ensure_one()
        return {
            'name': 'Beneficiarios Socioeconómico',
            'view_mode': 'tree,form',
            'res_model': 'mz_convoy.beneficiario',
            'type': 'ir.actions.act_window',
            'domain': [('convoy_id', '=', self.id), ('tipo_registro', '=', 'socioeconomico')],
            'context': {
                'default_convoy_id': self.id,
                'default_tipo_registro': 'socioeconomico',
                'form_view_initial_mode': 'readonly',
                'create': False,
                'edit': False,
                'delete': False
            },
            'target': 'current',
        }
        
    @api.depends('beneficiario_ids')
    def _compute_beneficiario_count(self):
        for record in self:
            record.beneficiario_count = len(record.beneficiario_ids)   
 
    @api.depends('programa_id')
    def _compute_can_edit_services(self):
        for record in self:
            record.can_edit_services = bool(record.id)

    @api.depends('programa_id.if_publicado', 'programa_id.active')
    def _compute_mostrar_boton_publicar(self):
        for record in self:
            record.mostrar_boton_publicar = (
                record.programa_id.active and 
                not record.programa_id.if_publicado)

    @api.depends('programa_id.if_publicado', 'programa_id.active')
    def _compute_mostrar_bot_retirar_public(self):
        for record in self:
            record.mostrar_bot_retirar_public = (
                record.programa_id.active and 
                record.programa_id.if_publicado)

    # Opción 1: Redirigir al registro padre
    def action_activar(self):
        return self.programa_id.action_activar()

    def action_publish(self):
        return self.programa_id.action_publish()

    def action_unpublish_wizard(self):
        return self.programa_id.action_unpublish_wizard()

    @api.depends('hora_inicio', 'hora_fin')
    def _compute_duracion(self):
        for record in self:
            if not record.hora_inicio or not record.hora_fin:
                record.duracion = '0 horas'
                continue
                
            # Convertir las horas de formato "HH:MM" a minutos
            def hora_a_minutos(hora_str):
                horas, minutos = map(int, hora_str.split(':'))
                return horas * 60 + minutos
                
            inicio_minutos = hora_a_minutos(record.hora_inicio)
            fin_minutos = hora_a_minutos(record.hora_fin)
            
            # Calcular la diferencia en minutos
            diferencia_minutos = fin_minutos - inicio_minutos
            
            if diferencia_minutos <= 0:
                record.duracion = '0 horas'
                continue
                
            # Convertir a horas y minutos
            horas_enteras = diferencia_minutos // 60
            minutos_restantes = diferencia_minutos % 60
            
            # Formar el string de duración
            if minutos_restantes == 0:
                record.duracion = f'{horas_enteras} horas'
            elif minutos_restantes == 30:
                record.duracion = f'{horas_enteras} horas y media'
            else:
                record.duracion = f'{horas_enteras} horas y {minutos_restantes} minutos'
    
    
   
    
    

    @api.depends('fecha_inicio_evento', 'fecha_hasta_evento')
    def _compute_dia_semana(self):
        for record in self:
            if record.fecha_inicio_evento and record.fecha_hasta_evento:
                dias_semana = {
                    0: 'Lunes',
                    1: 'Martes',
                    2: 'Miércoles',
                    3: 'Jueves',
                    4: 'Viernes',
                    5: 'Sábado',
                    6: 'Domingo'
                }                
                # Si las fechas son iguales, solo mostrar el día
                if record.fecha_inicio_evento == record.fecha_hasta_evento:
                    record.dia_semana = dias_semana[record.fecha_inicio_evento.weekday()]
                else:
                    # Si son diferentes, mostrar el rango
                    dia_inicio = dias_semana[record.fecha_inicio_evento.weekday()]
                    dia_fin = dias_semana[record.fecha_hasta_evento.weekday()]
                    record.dia_semana = f'De {dia_inicio} a {dia_fin}'
            else:
                record.dia_semana = False

    def action_aprobar_convoy(self):
        """Método para aprobar convoy y gestionar permisos de coordinador y bodeguero"""
        self.ensure_one()        
        self._validar_aprobacion()
        
        try:
            grupos = self._obtener_grupos_aprobacion()            
            self._guardar_y_asignar_permisos_aprobacion(grupos)
            self._actualizar_estado_y_notificar()
            
            # Crear el almacén asociado al convoy
            self.crear_almacen_convoy()
            
            # Enviar correos de notificación
            self.enviar_correo_coordinador()
            
            self.enviar_correo_bodeguero()            
            self.enviar_correo_bodeguero_medico()  # Nuevo método
            self.enviar_correo_bodeguero_veterinario()
            self.enviar_correo_bodeguero_insumos()
        except Exception as e:
            raise UserError(f"Error al aprobar convoy: {str(e)}")

    def crear_almacen_convoy(self):
        """
        Método para crear un almacén asociado al convoy.
        El almacén utilizará 'Almacén' + nombre del convoy como nombre,
        el programa_id del convoy, y la sigla del programa como código.
        Asigna responsables a las ubicaciones correspondientes.
        """
        self.ensure_one()
        
        # Verificar si ya existe un almacén para este programa
        almacen_existente = self.env['stock.warehouse'].search([
            ('programa_id', '=', self.programa_id.id)
        ], limit=1)
        
        if almacen_existente:
            # Si ya existe un almacén, solo asignamos responsables
            self._asignar_responsables_ubicaciones(almacen_existente)
            return almacen_existente
        
        try:
            # Crear el nuevo almacén
            nuevo_almacen = self.env['stock.warehouse'].create({
                'name': f"Almacén {self.name}",  # Prefijo 'Almacén' + nombre del convoy
                'programa_id': self.programa_id.id,  # ID del programa asociado
                'code': self.sigla,  # Sigla del programa (heredado de pf.programas)
                'company_id': self.env.company.id,  # Compañía actual
            })
            
            # Asignar responsables a las ubicaciones
            self._asignar_responsables_ubicaciones(nuevo_almacen)
            
            return nuevo_almacen
        except Exception as e:
            raise UserError(f"Error al crear almacén para el convoy: {str(e)}")

    def _asignar_responsables_ubicaciones(self, almacen):
        """
        Método auxiliar para asignar responsables a las ubicaciones de un almacén
        """
        # Asignar bodeguero general SOLO a la ubicación de existencias
        if self.bodeguero:
            ubicacion_existencias = self.env['stock.location'].search([
                ('warehouse_id', '=', almacen.id),
                ('name', '=', 'Existencias')
            ], limit=1)
            
            if not ubicacion_existencias:
                ubicacion_existencias = self.env['stock.location'].search([
                    ('warehouse_id', '=', almacen.id),
                    ('usage', '=', 'view')
                ], limit=1)
            
            if ubicacion_existencias:
                ubicacion_existencias.with_context(creating_convoy_warehouse=True).write({
                    'reponsable_ids': [(6, 0, [self.bodeguero.id])]
                })
        
        # Asignar bodeguero médico
        if self.bodeguero_medico_id:
            ubicacion_medico = self.env['stock.location'].search([
                ('warehouse_id', '=', almacen.id),
                ('name', '=', 'Médico')
            ], limit=1)
            
            if ubicacion_medico:
                ubicacion_medico.with_context(creating_convoy_warehouse=True).write({
                    'reponsable_ids': [(6, 0, [self.bodeguero_medico_id.id])]
                })
        
        # Asignar bodeguero veterinario
        if self.bodeguero_veterinario_id:
            ubicacion_vet = self.env['stock.location'].search([
                ('warehouse_id', '=', almacen.id),
                ('name', '=', 'Veterinario')
            ], limit=1)
            
            if ubicacion_vet:
                ubicacion_vet.with_context(creating_convoy_warehouse=True).write({
                    'reponsable_ids': [(6, 0, [self.bodeguero_veterinario_id.id])]
                })
        
        # Asignar bodeguero de insumos
        if self.bodeguero_insumos_id:
            ubicacion_insumos = self.env['stock.location'].search([
                ('warehouse_id', '=', almacen.id),
                ('name', '=', 'Insumos')
            ], limit=1)
            
            if ubicacion_insumos:
                ubicacion_insumos.with_context(creating_convoy_warehouse=True).write({
                    'reponsable_ids': [(6, 0, [self.bodeguero_insumos_id.id])]
                })

    def enviar_correo_coordinador(self):
        # Obtener el correo del coordinador
        correo_coordinador = self.director_coordinador.work_email

        if not correo_coordinador:
            raise UserError("El coordinador no tiene un correo electrónico registrado.")

        # Crear el cuerpo del mensaje
        subject = f'Asignación como Coordinador de Convoy: {self.programa_id.name}'
        body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {self.director_coordinador.name},</p>

                <p>Se le informa que ha sido asignado(a) como <strong>Coordinador Responsable</strong> para el siguiente convoy. Por favor, acceda al sistema para que proceda con la administración</p>

                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p>Por favor, revise los detalles del convoy y prepare lo necesario para su coordinación.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

        # Crear el mensaje de correo
        mail_vals = {
            'subject': subject,
            'body_html': body,
            'email_to': correo_coordinador,
        }

        # Crear y enviar el correo
        mail = self.env['mail.mail'].create(mail_vals)
        mail.send()

    def enviar_correo_bodeguero(self):
        # Obtener el correo del bodeguero general
        correo_bodeguero = self.bodeguero.work_email

        if not correo_bodeguero:
            raise UserError("El encargado general de inventario no tiene un correo electrónico registrado.")

        # Crear el cuerpo del mensaje
        subject = f'Asignación como Encargado General de Inventario - Convoy: {self.programa_id.name}'
        body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {self.bodeguero.name},</p>
                <p>Se le informa que ha sido asignado(a) como <strong>Encargado General de Inventario</strong> para el siguiente convoy. Por favor, acceda al sistema para que proceda con la gestión del inventario:</p>
                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p>Por favor, revise los detalles del convoy y prepare lo necesario para su gestión general de inventario.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

        # Crear el mensaje de correo
        mail_vals = {
            'subject': subject,
            'body_html': body,
            'email_to': correo_bodeguero,
        }

        # Crear y enviar el correo
        mail = self.env['mail.mail'].create(mail_vals)
        mail.send()

    def enviar_correo_bodeguero_medico(self):
        # Obtener el correo del bodeguero médico
        correo_bodeguero = self.bodeguero_medico_id.work_email

        if not correo_bodeguero:
            raise UserError("El encargado de inventario médico no tiene un correo electrónico registrado.")

        # Crear el cuerpo del mensaje
        subject = f'Asignación como Encargado de Inventario Médico - Convoy: {self.programa_id.name}'
        body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {self.bodeguero_medico_id.name},</p>
                <p>Se le informa que ha sido asignado(a) como <strong>Encargado de Inventario Médico</strong> para el siguiente convoy. Por favor, acceda al sistema para que proceda con la gestión del inventario médico:</p>
                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p>Por favor, revise los detalles del convoy y prepare lo necesario para su gestión de inventario médico.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

        # Crear el mensaje de correo
        mail_vals = {
            'subject': subject,
            'body_html': body,
            'email_to': correo_bodeguero,
        }

        # Crear y enviar el correo
        mail = self.env['mail.mail'].create(mail_vals)
        mail.send()

    def enviar_correo_bodeguero_veterinario(self):
        # Obtener el correo del bodeguero veterinario
        correo_bodeguero = self.bodeguero_veterinario_id.work_email

        if not correo_bodeguero:
            raise UserError("El encargado de inventario veterinario no tiene un correo electrónico registrado.")

        # Crear el cuerpo del mensaje
        subject = f'Asignación como Encargado de Inventario Veterinario - Convoy: {self.programa_id.name}'
        body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {self.bodeguero_veterinario_id.name},</p>

                <p>Se le informa que ha sido asignado(a) como <strong>Encargado de Inventario Veterinario</strong> para el siguiente convoy. Por favor, acceda al sistema para que proceda con la gestión del inventario veterinario:</p>

                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p>Por favor, revise los detalles del convoy y prepare lo necesario para su gestión de inventario veterinario.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

        # Crear el mensaje de correo
        mail_vals = {
            'subject': subject,
            'body_html': body,
            'email_to': correo_bodeguero,
        }

        # Crear y enviar el correo
        mail = self.env['mail.mail'].create(mail_vals)
        mail.send()

    def enviar_correo_bodeguero_insumos(self):
        # Obtener el correo del bodeguero de insumos
        correo_bodeguero = self.bodeguero_insumos_id.work_email

        if not correo_bodeguero:
            raise UserError("El encargado de inventario de insumos no tiene un correo electrónico registrado.")

        # Crear el cuerpo del mensaje
        subject = f'Asignación como Encargado de Inventario de Insumos - Convoy: {self.programa_id.name}'
        body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {self.bodeguero_insumos_id.name},</p>

                <p>Se le informa que ha sido asignado(a) como <strong>Encargado de Inventario de Insumos</strong> para el siguiente convoy. Por favor, acceda al sistema para que proceda con la gestión del inventario de insumos:</p>

                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p>Por favor, revise los detalles del convoy y prepare lo necesario para su gestión de inventario de insumos.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

        # Crear el mensaje de correo
        mail_vals = {
            'subject': subject,
            'body_html': body,
            'email_to': correo_bodeguero,
        }

        # Crear y enviar el correo
        mail = self.env['mail.mail'].create(mail_vals)
        mail.send()

    def _validar_aprobacion(self):
        """Validar requisitos para aprobación del convoy"""
        fecha_actual = (fields.Datetime.now() - timedelta(hours=5)).date()
        if self.fecha_inicio_evento < fecha_actual:
            raise UserError("No se puede aprobar el convoy. La fecha de inicio debe ser mayor a la fecha actual.")
            
        if not self.director_coordinador:
            raise UserError("No se puede aprobar el convoy sin un coordinador asignado")
            
        if not self.director_coordinador.user_id:
            raise UserError(f"El coordinador {self.director_coordinador.name} no tiene un usuario del sistema asignado")
            
        if not self.bodeguero or not self.bodeguero.user_id:
            raise UserError("El bodeguero de medicamentos no está asignado o no tiene usuario del sistema")
    
        if not self.bodeguero_veterinario_id or not self.bodeguero_veterinario_id.user_id:
            raise UserError("El bodeguero veterinario no está asignado o no tiene usuario del sistema")
        
        if not self.bodeguero_insumos_id or not self.bodeguero_insumos_id.user_id:
            raise UserError("El bodeguero de insumos no está asignado o no tiene usuario del sistema")


    def _obtener_grupos_aprobacion(self):
        """Obtener grupos necesarios para la aprobación"""
        return {
            'coordinador': self.env.ref('manzana_convoy.group_mz_convoy_coordinador'),
            'bodeguero': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero'),
            'bodeguero_medico': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero_medicina'),
            'bodeguero_veterinario': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero_veterinario'),
            'bodeguero_insumos': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero_insumos')

        }

    def _guardar_y_asignar_permisos_aprobacion(self, grupos):
        """Guardar permisos originales y asignar nuevos permisos"""
        grupo_base = self.env.ref('base.group_user')
        
        # Diccionario para rastrear usuarios procesados y sus grupos asignados
        usuarios_procesados = {}
        
        # Procesar coordinador
        if self.director_coordinador and self.director_coordinador.user_id:
            user_id = self.director_coordinador.user_id.id
            if user_id not in usuarios_procesados:
                self.env['mz_convoy.permisos'].create({
                    'convoy_id': self.id,
                    'user_id': user_id,
                    'permisos_originales': [(6, 0, self.director_coordinador.user_id.groups_id.ids)]
                })
                usuarios_procesados[user_id] = [grupos['coordinador'].id]
        
        # Procesar bodeguero general
        if self.bodeguero and self.bodeguero.user_id:
            user_id = self.bodeguero.user_id.id
            if user_id not in usuarios_procesados:
                self.env['mz_convoy.permisos'].create({
                    'convoy_id': self.id,
                    'user_id': user_id,
                    'permisos_originales': [(6, 0, self.bodeguero.user_id.groups_id.ids)]
                })
                usuarios_procesados[user_id] = [grupos['bodeguero'].id]
            else:
                # Si ya está procesado, añadir este grupo a su lista
                usuarios_procesados[user_id].append(grupos['bodeguero'].id)
        
        # Procesar bodeguero médico
        if self.bodeguero_medico_id and self.bodeguero_medico_id.user_id:
            user_id = self.bodeguero_medico_id.user_id.id
            if user_id not in usuarios_procesados:
                self.env['mz_convoy.permisos'].create({
                    'convoy_id': self.id,
                    'user_id': user_id,
                    'permisos_originales': [(6, 0, self.bodeguero_medico_id.user_id.groups_id.ids)]
                })
                usuarios_procesados[user_id] = [grupos['bodeguero_medico'].id]
            else:
                # Si ya está procesado, añadir este grupo a su lista
                usuarios_procesados[user_id].append(grupos['bodeguero_medico'].id)
        
        # Procesar bodeguero veterinario
        if self.bodeguero_veterinario_id and self.bodeguero_veterinario_id.user_id:
            user_id = self.bodeguero_veterinario_id.user_id.id
            if user_id not in usuarios_procesados:
                self.env['mz_convoy.permisos'].create({
                    'convoy_id': self.id,
                    'user_id': user_id,
                    'permisos_originales': [(6, 0, self.bodeguero_veterinario_id.user_id.groups_id.ids)]
                })
                usuarios_procesados[user_id] = [grupos['bodeguero_veterinario'].id]
            else:
                # Si ya está procesado, añadir este grupo a su lista
                usuarios_procesados[user_id].append(grupos['bodeguero_veterinario'].id)
        
        # Procesar bodeguero de insumos
        if self.bodeguero_insumos_id and self.bodeguero_insumos_id.user_id:
            user_id = self.bodeguero_insumos_id.user_id.id
            if user_id not in usuarios_procesados:
                self.env['mz_convoy.permisos'].create({
                    'convoy_id': self.id,
                    'user_id': user_id,
                    'permisos_originales': [(6, 0, self.bodeguero_insumos_id.user_id.groups_id.ids)]
                })
                usuarios_procesados[user_id] = [grupos['bodeguero_insumos'].id]
            else:
                # Si ya está procesado, añadir este grupo a su lista
                usuarios_procesados[user_id].append(grupos['bodeguero_insumos'].id)
        
        # Ahora asignar todos los grupos acumulados a cada usuario
        for user_id, grupos_a_asignar in usuarios_procesados.items():
            usuario = self.env['res.users'].browse(user_id)
            
            # Primero, asignar el grupo base
            commands = [(6, 0, [grupo_base.id])]
            
            # Luego, añadir cada grupo adicional
            for grupo_id in grupos_a_asignar:
                commands.append((4, grupo_id))
            
            # Escribir los comandos
            usuario.write({
                'groups_id': commands
            })

    def _actualizar_estado_y_notificar(self):
        """Actualizar estado del convoy y enviar notificación"""
        self.write({'state': 'aprobado'})
        
        mensaje = f"""
        ✅ Convoy Aprobado
        - Fecha de aprobación: {fields.Datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
        - Fecha inicio evento: {self.fecha_inicio_evento.strftime('%d/%m/%Y')}
        - Fecha fin evento: {self.fecha_hasta_evento.strftime('%d/%m/%Y')}
        - Coordinador asignado: {self.director_coordinador.name}
        - Bodeguero (Medicamentos): {self.bodeguero.name}
        - Bodeguero (Veterinario): {self.bodeguero_veterinario_id.name}
        - Bodeguero (Insumos): {self.bodeguero_insumos_id.name}
        """
        
        self.message_post(
            body=mensaje,
            message_type='notification',
            subtype_xmlid='mail.mt_note'
        )

    def _verificar_y_restaurar_permisos_basicos(self):
        """
        Verifica que todos los usuarios tengan los permisos básicos según su rol en el convoy.
        Si algún permiso falta (porque fue modificado manualmente), lo restaura.
        """
        grupos = self._obtener_grupos_requeridos()
        
        # Verificar coordinador
        if self.director_coordinador and self.director_coordinador.user_id and grupos.get('coordinador'):
            if grupos['coordinador'].id not in self.director_coordinador.user_id.groups_id.ids:
                self.director_coordinador.user_id.write({
                    'groups_id': [(4, grupos['coordinador'].id)]
                })
        
        # Verificar bodeguero general
        if self.bodeguero and self.bodeguero.user_id and grupos.get('bodeguero'):
            if grupos['bodeguero'].id not in self.bodeguero.user_id.groups_id.ids:
                self.bodeguero.user_id.write({
                    'groups_id': [(4, grupos['bodeguero'].id)]
                })
        
        # Verificar bodeguero médico
        if self.bodeguero_medico_id and self.bodeguero_medico_id.user_id and grupos.get('bodeguero_medico'):
            if grupos['bodeguero_medico'].id not in self.bodeguero_medico_id.user_id.groups_id.ids:
                self.bodeguero_medico_id.user_id.write({
                    'groups_id': [(4, grupos['bodeguero_medico'].id)]
                })
        
        # Verificar bodeguero veterinario
        if self.bodeguero_veterinario_id and self.bodeguero_veterinario_id.user_id and grupos.get('bodeguero_veterinario'):
            if grupos['bodeguero_veterinario'].id not in self.bodeguero_veterinario_id.user_id.groups_id.ids:
                self.bodeguero_veterinario_id.user_id.write({
                    'groups_id': [(4, grupos['bodeguero_veterinario'].id)]
                })
        
        # Verificar bodeguero de insumos
        if self.bodeguero_insumos_id and self.bodeguero_insumos_id.user_id and grupos.get('bodeguero_insumos'):
            if grupos['bodeguero_insumos'].id not in self.bodeguero_insumos_id.user_id.groups_id.ids:
                self.bodeguero_insumos_id.user_id.write({
                    'groups_id': [(4, grupos['bodeguero_insumos'].id)]
                })
                
    def _actualizar_almacen_convoy(self):
        """
        Método para actualizar la información del almacén si ha cambiado la sigla del convoy.
        """
        self.ensure_one()
        # Buscar el almacén asociado al programa
        almacen = self.env['stock.warehouse'].search([
            ('programa_id', '=', self.programa_id.id)
        ], limit=1)
        
        if almacen and almacen.code != self.sigla:
            # Si la sigla ha cambiado, actualizar el código del almacén
            try:
                almacen.write({
                    'code': self.sigla,
                    'name': f"Almacén {self.name}"  # También actualizamos el nombre por si cambió
                })
            except Exception as e:
                raise UserError(f"Error al actualizar la información del almacén: {str(e)}")
    
    def action_ejecutar_convoy(self):
        """
        Ejecuta el convoy y gestiona los permisos para operadores y prestadores de servicio.
        """
        self.ensure_one()
        self._validar_ejecucion_convoy()
        
        try:
            self._verificar_y_restaurar_permisos_basicos()
            grupos = self._obtener_grupos_requeridos()
            
            # Procesar operadores
            for operador in self.operadores_ids.filtered(lambda o: o.user_id):
                # Verificar si ya hay permisos guardados
                if not self.env['mz_convoy.permisos'].search([
                    ('convoy_id', '=', self.id), 
                    ('user_id', '=', operador.user_id.id)
                ]):
                    self._guardar_permisos_originales(operador.user_id)
                
                # Añadir el grupo de operador sin eliminar otros grupos
                if grupos.get('operador'):
                    operador.user_id.write({
                        'groups_id': [(4, grupos['operador'].id)]
                    })
            
            # Procesar prestadores de servicio
            for servicio in self.servicio_ids:
                grupo_especifico = self._obtener_grupo_servicio_especifico(servicio)
                
                for prestador in servicio.personal_ids.filtered(lambda p: p.user_id):
                    # Verificar si ya hay permisos guardados
                    if not self.env['mz_convoy.permisos'].search([
                        ('convoy_id', '=', self.id), 
                        ('user_id', '=', prestador.user_id.id)
                    ]):
                        self._guardar_permisos_originales(prestador.user_id)
                    
                    # Añadir grupos específicos sin eliminar otros
                    if grupo_especifico:
                        prestador.user_id.write({
                            'groups_id': [(4, grupo_especifico.id)]
                        })
                    
                    if servicio.servicio_id.tipo_servicio == 'normal' and grupos.get('prestador'):
                        prestador.user_id.write({
                            'groups_id': [(4, grupos['prestador'].id)]
                        })
            
            self._actualizar_almacen_convoy()
            self._actualizar_horarios_y_estado()
            self._publicar_mensaje_ejecucion()
        except Exception as e:
            raise UserError(f"Error al ejecutar convoy: {str(e)}")

    def _procesar_permisos_operadores(self, grupos, usuarios_procesados):
        """Procesa los permisos para todos los operadores."""
        for operador in self.operadores_ids.filtered(lambda o: o.user_id):
            user_id = operador.user_id.id
            if user_id not in usuarios_procesados:
                self._guardar_permisos_originales(operador.user_id)
                usuarios_procesados[user_id] = [grupos['operador'].id]
            else:
                # Si ya está procesado, añadir este grupo a su lista
                if grupos['operador'].id not in usuarios_procesados[user_id]:
                    usuarios_procesados[user_id].append(grupos['operador'].id)

    def _procesar_permisos_prestadores(self, grupos, usuarios_procesados):
        """Procesa los permisos para todos los prestadores de servicio."""
        for servicio in self.servicio_ids:
            grupo_especifico = self._obtener_grupo_servicio_especifico(servicio)
            
            for prestador in servicio.personal_ids.filtered(lambda p: p.user_id):
                user_id = prestador.user_id.id
                
                if user_id not in usuarios_procesados:
                    self._guardar_permisos_originales(prestador.user_id)
                    usuarios_procesados[user_id] = []
                
                # Añadir grupo específico del servicio si existe
                if grupo_especifico and grupo_especifico.id not in usuarios_procesados[user_id]:
                    usuarios_procesados[user_id].append(grupo_especifico.id)
                
                # Añadir grupo general de prestador si es un servicio normal
                if servicio.servicio_id.tipo_servicio == 'normal' and grupos['prestador'].id not in usuarios_procesados[user_id]:
                    usuarios_procesados[user_id].append(grupos['prestador'].id)   

    def _validar_ejecucion_convoy(self):
        """Valida todos los requisitos para la ejecución del convoy."""
        if not self.servicio_ids:
            raise UserError("Debe existir al menos un servicio asignado al convoy")
        if not self.operadores_ids:
            raise UserError("Debe existir al menos un operador asignado al convoy")
        if self.state != 'aprobado':
            raise UserError("Solo se pueden ejecutar convoyes en estado aprobado")
        
        fecha_actual = (fields.Datetime.now() - timedelta(hours=5)).date()
        if self.fecha_inicio_evento != fecha_actual:
            raise UserError("Solo se pueden ejecutar convoyes en su fecha de inicio programada")
        
        # Obtener todos los registros de planificación médica asociados al convoy
        planificaciones_medicas = self.env['mz.genera.planificacion.servicio'].search([
            ('convoy_id', '=', self.id),
            ('if_consulta_medica', '=', True)])
        
        # Solo validar atención médica especial si existen planificaciones médicas
        if planificaciones_medicas:
            # Validar que todas las planificaciones médicas tengan ubicación
            sin_ubicacion = planificaciones_medicas.filtered(lambda p: not p.ubicacion_id)
            if sin_ubicacion:
                raise UserError("No es posible ejecutar el convoy. Existen servicios médicos sin ubicación asignada. Diríjase a Planificación de turnos (Planificación)")
            
            # Validar que al menos una tenga atención médica especial
            tiene_atencion_especial = planificaciones_medicas.filtered(lambda p: p.atencion_medica_especial)
            if not tiene_atencion_especial:
                raise UserError("Debe existir al menos una consulta médica con atención médica especial")
    
    def _obtener_grupos_requeridos(self):
        """Obtiene todos los grupos de seguridad requeridos."""
        grupos = {
            'base': self.env.ref('base.group_user', False),
            'operador': self.env.ref('manzana_convoy.group_mz_convoy_operador', False),
            'prestador': self.env.ref('manzana_convoy.group_mz_convoy_prestador_servicio', False),
            'coordinador': self.env.ref('manzana_convoy.group_mz_convoy_coordinador', False),
            'bodeguero': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero', False),
            'bodeguero_medico': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero_medicina', False),
            'bodeguero_veterinario': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero_veterinario', False),
            'bodeguero_insumos': self.env.ref('manzana_convoy.group_mz_convoy_bodeguero_insumos', False),
        }
        
        # Verificar al menos los grupos esenciales
        grupos_esenciales = ['base', 'operador', 'prestador', 'coordinador']
        faltantes = [g for g in grupos_esenciales if not grupos.get(g)]
        if faltantes:
            raise UserError(f"No se encontraron los siguientes grupos esenciales: {', '.join(faltantes)}")
        
        return grupos

    def _guardar_permisos_originales(self, usuario, valores_adicionales=None):
        """Guarda los permisos originales del usuario."""
        valores = {
            'convoy_id': self.id,
            'user_id': usuario.id,
            'permisos_originales': [(6, 0, usuario.groups_id.ids)]
        }
        if valores_adicionales:
            valores.update(valores_adicionales)
        return self.env['mz_convoy.permisos'].create(valores)

    def _obtener_grupo_servicio_especifico(self, servicio):
        """Obtiene el grupo de seguridad específico basado en el tipo de servicio."""
        mapeo_tipos = {
            'cuidado_infantil': 'manzana_convoy.group_mz_convoy_cuidado_infantil',
            'mascota': 'manzana_convoy.group_mz_convoy_veterinaria',
            'asesoria_legal': 'manzana_convoy.group_mz_convoy_aseroria_legal',
            'medico': {
                'consulta_medica': 'manzana_convoy.group_mz_convoy_medicina_general',
                'consulta_psicologica': 'manzana_convoy.group_mz_convoy_psicologia'
            }
        }
        
        tipo_servicio = servicio.servicio_id.tipo_servicio
        if tipo_servicio not in mapeo_tipos:
            return False
            
        if tipo_servicio == 'medico':
            if servicio.servicio_id.if_consulta_medica:
                return self.env.ref(mapeo_tipos[tipo_servicio]['consulta_medica'])
            elif servicio.servicio_id.if_consulta_psicologica:
                return self.env.ref(mapeo_tipos[tipo_servicio]['consulta_psicologica'])
        return self.env.ref(mapeo_tipos[tipo_servicio])

   
   
    
    def _actualizar_horarios_y_estado(self):
        """Actualiza los horarios y el estado del convoy."""
        horarios = self.env['mz.genera.planificacion.servicio'].search([
            ('convoy_id', '=', self.id)
        ])
        if horarios:
            # Actualizar estado de horarios
            horarios.write({'estado': 'confirmado'})
            # Enviar correos a todo el personal
            horarios.enviar_correo_personal_servicio()
            # Actualizar estado del convoy
            self.write({'state': 'ejecutando'})
        self.enviar_correo_operadores()

    def enviar_correo_operadores(self):
        for operador in self.operadores_ids:
            # Verificar que el operador tenga correo
            if not operador.work_email:
                continue

            # Crear el cuerpo del mensaje
            subject = f'Asignación como Operador de Convoy: {self.programa_id.name}'
            body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {operador.name},</p>

                <p>Se le informa que ha sido asignado(a) como <strong>Operador</strong> para el siguiente convoy. 
                Por favor, tenga en cuenta que debe estar presente <strong>15 minutos antes</strong> de la hora de inicio:</p>

                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{self.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p style="color: #e74c3c;"><strong>Importante:</strong> Por favor, asegúrese de estar presente en el lugar 15 minutos antes de la hora de inicio programada.</p>

                <p>Por favor, revise los detalles del convoy y prepare lo necesario para su operación.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

            # Crear el mensaje de correo
            mail_vals = {
                'subject': subject,
                'body_html': body,
                'email_to': operador.work_email,
            }

            # Crear y enviar el correo
            mail = self.env['mail.mail'].create(mail_vals)
            mail.send()

    def _publicar_mensaje_ejecucion(self):
        """Publica el mensaje de notificación de ejecución del convoy."""
        mensaje = f"""
        ▶️ Convoy Iniciado
        - Fecha de inicio: {fields.Datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
        - Fecha programada inicio: {self.fecha_inicio_evento.strftime('%d/%m/%Y')}
        - Fecha programada fin: {self.fecha_hasta_evento.strftime('%d/%m/%Y')}
        - Operadores asignados: {len(self.operadores_ids)}
        - Se han guardado y modificado los permisos de operadores y prestadores de servicio
        """
        self.message_post(body=mensaje, message_type='notification', subtype_xmlid='mail.mt_note')



    def action_finalizar_manual(self, es_automatico=False):
        """Método para finalizar convoy"""
        self.ensure_one()       
        

        if not es_automatico:
            fecha_actual = (fields.Datetime.now() - timedelta(hours=5)).date()
            if self.fecha_hasta_evento > fecha_actual:
                raise UserError("Solo se pueden finalizar convoyes en su fecha de fin programada")

        try:
            for permiso in self.permisos_ids:
                if permiso.user_id:
                    permiso.user_id.write({'groups_id': [(6, 0, permiso.permisos_originales.ids)]})
            self.permisos_ids.unlink()
            self.write({'state': 'fin'})
            fecha_hora_actual = fields.Datetime.now() - timedelta(hours=5)
            titulo = "🔄 Convoy Finalizado Automáticamente" if es_automatico else "✅ Convoy Finalizado Manualmente"
            mensaje = f"""
            {titulo}
            - Fecha de finalización: {fecha_hora_actual.strftime('%d/%m/%Y %H:%M:%S')}
            - Fecha programada fin: {self.fecha_hasta_evento.strftime('%d/%m/%Y')}
            - Se han restaurado los permisos originales de todos los usuarios
            """
            self.message_post(body=mensaje, message_type='notification', subtype_xmlid='mail.mt_note')

        except Exception as e:
            error_msg = f"Error al finalizar convoy: {str(e)}"
            if es_automatico:
                logger.error(error_msg)
                return
            raise UserError(error_msg)
        
    def _cron_verificar_fecha_finalizacion(self):
        """Método para verificar y finalizar convoyes por fecha"""
        fecha_actual = (fields.Datetime.now() - timedelta(hours=5)).date()
        # Buscar convoyes que deben finalizarse
        convoyes_para_finalizar = self.search([
            ('state', '=', 'ejecutando'),
            ('fecha_hasta_evento', '>=', fecha_actual)])            
        for convoy in convoyes_para_finalizar:
            convoy.action_finalizar_manual(es_automatico=True)

    def action_suspender(self):
        """Método para suspender convoy"""
        self.ensure_one()
        try:
            # Revertir permisos
            for permiso in self.permisos_ids:
                if permiso.user_id:
                    permiso.user_id.write({
                        'groups_id': [(6, 0, permiso.permisos_originales.ids)]
                    })
            
            # Actualizar estado y notificar
            self.write({'state': 'suspendido'})
            
            mensaje = f"""
            🚫 Convoy Suspendido
            - Fecha de suspensión: {fields.Datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
            - Observación: {self.observacion}
            - Coordinador: {self.director_coordinador.name}
            - Bodeguero: {self.bodeguero.name}
            """
            self.message_post(
                body=mensaje,
                message_type='notification',
                subtype_xmlid='mail.mt_note'
            )
        except Exception as e:
            raise UserError(f"Error al suspender convoy: {str(e)}")
  
class ConvoyMiembroMesaTecnica(models.Model):
    _name = 'mz_convoy.mesa_tecnica'
    _description = 'Miembro de Mesa Técnica'

    evento_id = fields.Many2one('mz.convoy', string='Evento')
    nombre = fields.Char(string='Nombre', required=True, tracking=True)
    cargo_institucion_id = fields.Many2one('pf.items', string='Cargo/Institución', tracking=True,
                                             domain=lambda self: [('catalogo_id', '=', self.env.ref('manzana_convoy.catalogo_instituciones_publicas').id)])
    contacto = fields.Char(string='Número de Contacto', tracking=True)


class ConvoyAutoriades(models.Model):
    _name = 'mz_convoy.autoridades'
    _description = 'Autoridades'
    
    convoy_id = fields.Many2one(string='Convoy', comodel_name='mz.convoy', ondelete='restrict')    
    nombre = fields.Char(string='Nombre', required=True, tracking=True)

class ConvoyAlertasQuejas(models.Model):
    _name = 'mz_convoy.alertas_quejas'
    _description = 'Alertas/Quejas'
    
    convoy_id = fields.Many2one(string='Convoy', comodel_name='mz.convoy', ondelete='restrict')    
    nombre = fields.Char(string='Nombre', required=True, tracking=True)
    