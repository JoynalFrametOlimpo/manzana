from logging.config import valid_ident
import string
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from babel.dates import format_date
# from datetime import datetime,time, datetime
from datetime import datetime
from datetime import date
import time
import json
global NoTieneHorario
from pytz import timezone
from datetime import timedelta
import logging
_logger = logging.getLogger(__name__)




class ConvoyGenerarHorarios(models.Model):
    _inherit = 'mz.genera.planificacion.servicio'

    
    convoy_id = fields.Many2one('mz.convoy', string='Convoy', tracking=True)
    atencion_medica_especial = fields.Boolean(string='Atención Médica Especial', tracking=True)

    sequence_id = fields.Many2one('ir.sequence', string='Secuencia de Turnos', readonly=True)
    
    @api.model
    def create(self, vals):
        """Al crear una cabecera, creamos también su secuencia dedicada"""
        record = super(ConvoyGenerarHorarios, self).create(vals)
        
        # Crear la secuencia para esta cabecera
        sequence = self.env['ir.sequence'].sudo().create({
            'name': f'Turnos para {record.name or record.id}',
            'code': f'turno.planificacion.{record.id}',
            'implementation': 'standard',
            'number_next': 1,
            'number_increment': 1,
            'padding': 0,
        })
        
        # Asociar la secuencia a la cabecera
        record.write({'sequence_id': sequence.id})        
        return record
    
    def unlink(self):
        """Al eliminar la cabecera, eliminamos también su secuencia"""
        sequences = self.mapped('sequence_id')
        result = super(ConvoyGenerarHorarios, self).unlink()
        if sequences:
            sequences.sudo().unlink()
        return result
    
    # @api.model_create_multi
    # def create(self, vals_list):
    #     """
    #     Método optimizado para crear múltiples registros de planificación de servicios.
    #     Procesa los valores en lote para mejorar el rendimiento en entornos concurrentes.
    #     """
    #     result = self.env['mz.planificacion.servicio']
        
    #     if not vals_list:
    #         return result
        
    #     # Procesamos validaciones comunes en batch
    #     horarios_a_computar = []
        
    #     # Verificamos qué registros necesitarán recomputar el horario después
    #     for vals in vals_list:
    #         if not all(key in vals for key in ['fecha', 'horainicio', 'horafin']):
    #             horarios_a_computar.append(vals)
        
    #     # Usamos un savepoint para toda la operación
    #     self.env.cr.execute("SAVEPOINT create_planificacion_servicio_savepoint")
        
    #     try:
    #         # Creamos todos los registros en una sola operación
    #         # Aquí es donde está el error - usamos super() sin argumentos
    #         records = super().create(vals_list)
            
    #         # Procesamos los registros que necesitan cómputo especial del horario
    #         if horarios_a_computar:
    #             records_to_compute = records.filtered(
    #                 lambda r: not (r.fecha and r.horainicio and r.horafin)
    #             )
    #             # Forzamos el cálculo del horario para estos registros
    #             if records_to_compute:
    #                 for record in records_to_compute:
    #                     record.horario = f"Turno: {record.numero}"
            
    #         result = records
            
    #     except Exception as e:
    #         self.env.cr.execute("ROLLBACK TO SAVEPOINT create_planificacion_servicio_savepoint")
    #         _logger.error(f"Error al crear planificaciones de servicios: {str(e)}")
    #         raise UserError(f"Error al crear las planificaciones de servicio: {str(e)}")
        
    #     self.env.cr.execute("RELEASE SAVEPOINT create_planificacion_servicio_savepoint")
        
    #     return result
    
    
    def get_next_number(self):
        """Obtiene el siguiente número de turno para esta cabecera"""
        self.ensure_one()
        if not self.sequence_id:
            # Si por alguna razón no tiene secuencia, la creamos
            sequence = self.env['ir.sequence'].sudo().create({
                'name': f'Turnos para {self.name or self.id}',
                'code': f'turno.planificacion.{self.id}',
                'implementation': 'standard',
                'number_next': 1,
                'number_increment': 1,
                'padding': 0,
            })
            self.write({'sequence_id': sequence.id})
        
        return int(self.sequence_id.next_by_id())


    def enviar_correo_personal_servicio(self):
        for horario in self:
            # Verificar que el personal tenga correo
            if not horario.personal_id.work_email:
                continue  # Saltamos si no tiene correo

            # Obtener datos del convoy a través del servicio
            convoy = horario.servicio_id.convoy_id

            # Crear el cuerpo del mensaje
            subject = f'Asignación de Servicio en Convoy: {convoy.programa_id.name}'
            body = f'''
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">            
                <p>Estimado(a) {horario.personal_id.name},</p>

                <p>Se le informa que ha sido asignado(a) para brindar el servicio de <strong>{horario.servicio_id.name}</strong> 
                en el siguiente convoy. Por favor, acceda al sistema para revisar los detalles de su asignación:</p>

                <table style="border: 1px solid #dddddd; border-collapse: collapse; width: 100%;">
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Convoy</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.programa_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Servicio Asignado</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{horario.servicio_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Provincia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.provincia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Cantón</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.ciudad_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Parroquia</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.parroquia_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Sector</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.sector_id.name}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.fecha_inicio_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Fecha de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.fecha_hasta_evento.strftime('%d/%m/%Y')}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Inicio</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.hora_inicio}</td>
                        </tr>
                        <tr>
                            <td style="border: 1px solid #dddddd; padding: 8px;"><strong>Hora de Fin</strong></td>
                            <td style="border: 1px solid #dddddd; padding: 8px;">{convoy.hora_fin}</td>
                        </tr>
                    </tbody>
                </table>

                <p>Por favor, revise los detalles de su asignación y asegúrese de estar presente en el lugar y hora indicados.</p>

                <p style="color: #666;">Saludos,<br /></p>
                
                <div style="border-top: 1px solid #dddddd; margin-top: 20px; padding-top: 20px; color: #666; font-size: 12px; text-align: center;">
                    <p>{self.env.company.name}<br/>
                    {self.env.company.street or ''} {self.env.company.street2 or ''}<br/>
                    {self.env.company.email or ''}</p>
                </div>
            </div>
            '''

            # Crear el mensaje de correo
            mail_vals = {
                'subject': subject,
                'body_html': body,
                'email_to': horario.personal_id.work_email,
            }

            # Crear y enviar el correo
            mail = self.env['mail.mail'].create(mail_vals)
            mail.send()




    @api.constrains('servicio_id', 'personal_id')
    def _check_detalle_generahorario(self):
        for record in self:           
            asignacion = self.env['mz.asignacion.servicio'].browse(record.servicio_id.id)                        
            if asignacion.convoy_id:
                continue                
            # Si no es de convoy, aplicamos la validación original
            if not (record.turno_disponibles_ids) and not record.es_replanificacion:
                raise UserError("No se puede guardar AGENDA sino genera detalle de Agenda!!")
            
    def _search(self, args, offset=0, limit=None, order=None, access_rights_uid=None):
        """
        Método _search personalizado para filtrar horarios cuando viene el contexto
        """
        args = args or []
        user = self.env.user
        base_args = []
        if self._context.get('filtrar_convoy'):
            # Verificar grupos
            if user.has_group('manzana_convoy.group_mz_convoy_coordinador'):
                # Para coordinador: ver solo horarios de programas en sus convoyes
                convoyes = self.env['mz.convoy'].search([
                    ('director_coordinador.user_id', '=', user.id)
                ])
                programa_ids = convoyes.mapped('programa_id').ids
                base_args = [('programa_id', 'in', programa_ids)]
            elif user.has_group('manzana_convoy.group_mz_convoy_administrador'):
                # Para admin/asistente: ver horarios con modulo_id = 4
                base_args = [('programa_id.modulo_id', '=', 4)]
            elif user.has_group('manzana_convoy.group_mz_convoy_operador'):
                # Para operador: ver solo horarios de convoyes donde está asignado y están en ejecución
                convoyes = self.env['mz.convoy'].search([
                    ('state', '=', 'ejecutando'),
                    ('operadores_ids', 'in', user.employee_id.id)
                ])
                programa_ids = convoyes.mapped('programa_id').ids
                base_args = [('programa_id', 'in', programa_ids)]
            args = base_args + args
        return super(ConvoyGenerarHorarios, self)._search(
            args,
            offset=offset,
            limit=limit,
            order=order,
            access_rights_uid=access_rights_uid
        )

# Tabla de horarios
class PlanificacionServicio(models.Model):
    _inherit = 'mz.planificacion.servicio'

    numero = fields.Integer(string='Número',)  
    asignacion_id = fields.Many2one('mz.asignacion.servicio', string='Asignación de Servicio', ondelete='restrict')

    @api.depends('fecha', 'horainicio', 'horafin', 'dia')
    def _compute_horario(self):
        # Primero llamamos al método original
        super()._compute_horario()        
        # Luego modificamos solo los registros que necesitamos
        for record in self:           
            if not (record.fecha and record.horainicio and record.horafin):
                record.horario = f"Turno: {record.numero}"