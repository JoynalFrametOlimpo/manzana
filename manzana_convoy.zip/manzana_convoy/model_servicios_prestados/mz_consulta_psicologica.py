from odoo import models, api
from odoo.exceptions import UserError


class ConvoyConsultaPsicologica(models.Model):
    _inherit = 'mz.consulta.psicologica'
    
    
    def _search(self, args, offset=0, limit=None, order=None, access_rights_uid=None):
        args = args or []
        user = self.env.user
        base_args = [('id', 'in', [])]
        
        if not self._context.get('internal_search') and self._context.get('filtrar_convoy_psicologia'):
            convoy_ids = self.env['mz.convoy'].search([
                ('state', '=', 'ejecutando')
            ])
            
            if user.has_group('manzana_convoy.group_mz_convoy_administrador'):
                programa_ids = self.with_context(internal_search=True).search([
                    ('programa_id.modulo_id', '=', 4),
                    ('programa_id', 'in', convoy_ids.mapped('programa_id').ids)
                ]).ids
                base_args = [('id', 'in', programa_ids)]
            elif user.has_group('manzana_convoy.group_mz_convoy_psicologia'):
                employee_id = self.env['hr.employee'].search([('user_id', '=', user.id)], limit=1)
                programa_ids = self.with_context(internal_search=True).search([
                    ('programa_id', 'in', convoy_ids.mapped('programa_id').ids),
                    ('state', '=', 'final'),
                    ('personal_id', '=', employee_id.id)
                ]).ids
                base_args = [('id', 'in', programa_ids)]
            elif user.has_group('manzana_convoy.group_mz_convoy_coordinador'):
                director_convoy_ids = self.env['mz.convoy'].search([
                    ('director_coordinador.user_id', '=', user.id)
                ])
                programa_ids = self.with_context(internal_search=True).search([
                    ('programa_id', 'in', (convoy_ids + director_convoy_ids).mapped('programa_id').ids),
                    ('state', '=', 'final')
                ]).ids
                base_args = [('id', 'in', programa_ids)]
            
            args = base_args + args
            
        return super(ConvoyConsultaPsicologica, self)._search(args, offset=offset, limit=limit, order=order, access_rights_uid=access_rights_uid)

    @api.model 
    def get_view(self, view_id=None, view_type='form', context=None, toolbar=False, submenu=False, **kwargs):
        context = context or {}
        user = self.env.user
        
        if any([
            user.has_group('manzana_convoy.group_mz_convoy_psicologia'),
            user.has_group('manzana_convoy.group_mz_convoy_administrador')]):
            if view_type == 'tree':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_consulta_psicologica_tree').id
            elif view_type == 'form':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_consulta_psicologica_form').id
        else:
            if view_type == 'tree':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_consulta_psicologica_tree_limit').id
            elif view_type == 'form':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_consulta_psicologica_form_limit').id
                
        return super().get_view(view_id=view_id, view_type=view_type, context=context, 
                            toolbar=toolbar, submenu=submenu, **kwargs)
