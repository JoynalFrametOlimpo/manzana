from odoo import models, api
from odoo.exceptions import UserError


class MzConvoyVeterinaria(models.Model):
    _inherit = 'mz.servicio.veterinario'
 
    @api.model
    def get_view(self, view_id=None, view_type='form', context=None, toolbar=False, submenu=False, **kwargs):
        context = context or {}
        user = self.env.user
        
        if any([user.has_group('manzana_convoy.group_mz_convoy_veterinaria'), user.has_group('manzana_convoy.group_mz_convoy_administrador')]):
            # Vistas completas para veterinarios y administradores
            if view_type == 'tree':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_servicio_veterinario_tree').id
            elif view_type == 'form':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_servicio_veterinario_form').id
        else:
            # Vistas limitadas para otros usuarios
            if view_type == 'tree':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_servicio_veterinario_tree').id
            elif view_type == 'form':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_servicio_veterinario_form_read').id
        
        return super().get_view(view_id=view_id, view_type=view_type, context=context, toolbar=toolbar, submenu=submenu, **kwargs)

    