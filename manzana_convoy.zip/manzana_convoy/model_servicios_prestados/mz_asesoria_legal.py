from odoo import models, api
from odoo.exceptions import UserError


class MzConvoyAsesoriaLegal(models.Model):
    _inherit = 'mz.asesoria.legal'
 
    @api.model
    def get_view(self, view_id=None, view_type='form', context=None, toolbar=False, submenu=False, **kwargs):
        context = context or {}
        user = self.env.user
        
        if any([
            user.has_group('manzana_convoy.group_mz_convoy_aseroria_legal'),
            user.has_group('manzana_convoy.group_mz_convoy_administrador')
        ]):
            # Vistas completas para asesores legales y administradores
            if view_type == 'tree':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_asesoria_legal_tree').id
            elif view_type == 'form':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_asesoria_legal_form').id
        else:
            # Vistas limitadas para otros usuarios
            if view_type == 'tree':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_asesoria_legal_tree').id
            elif view_type == 'form':
                view_id = self.env.ref('manzana_de_cuidados.view_mz_asesoria_legal_form_limit').id
                
        return super().get_view(
            view_id=view_id,
            view_type=view_type,
            context=context,
            toolbar=toolbar,
            submenu=submenu,
            **kwargs
        )

    def _search(self, args, offset=0, limit=None, order=None, access_rights_uid=None):
        args = args or []
        user = self.env.user
        base_args = [('id', 'in', [])]
        
        if not self._context.get('disable_custom_search'):
            if self._context.get('filtrar_convoy_asesoria_legal'):
                # Primero obtenemos los convoyes en ejecución
                convoy_ids = self.env['mz.convoy'].search([
                    ('state', '=', 'ejecutando')
                ])
                
                if user.has_group('manzana_convoy.group_mz_convoy_administrador'):
                    programa_ids = self.with_context(disable_custom_search=True).search([
                        ('programa_id.modulo_id', '=', 4),
                        ('programa_id', 'in', convoy_ids.mapped('programa_id').ids)
                    ]).ids
                    base_args = [('id', 'in', programa_ids)]
                elif user.has_group('manzana_convoy.group_mz_convoy_aseroria_legal'):
                    # raise UserError("llegando")
                    employee_id = self.env['hr.employee'].search([('user_id', '=', user.id)], limit=1)
                    programa_ids = self.with_context(disable_custom_search=True).search([                     
                        ('programa_id', 'in', convoy_ids.mapped('programa_id').ids),                       
                        ('state', '=', 'finalizado'),
                        ('asesor_id', '=', employee_id.id)
                    ]).ids
                    # raise UserError(programa_ids)
                    base_args = [('id', 'in', programa_ids)]
                elif user.has_group('manzana_convoy.group_mz_convoy_coordinador'):
                # Obtener convoyes donde es director
                    director_convoy_ids = self.env['mz.convoy'].search([
                        ('director_coordinador.user_id', '=', user.id)
                    ])
                    programa_ids = self.with_context(disable_custom_search=True).search([
                        ('programa_id', 'in', (convoy_ids + director_convoy_ids).mapped('programa_id').ids),
                        ('state', '=', 'finalizado')
                    ]).ids
                    base_args = [('id', 'in', programa_ids)]                
                args = base_args + args               
        return super(MzConvoyAsesoriaLegal, self)._search(
            args,
            offset=offset,
            limit=limit,
            order=order,
            access_rights_uid=access_rights_uid
        )